
window.addEventListener("error",function(ev){
  var b=document.getElementById("error-banner");
  if(b){ b.style.display="block"; b.textContent="JavaScript error: "+(ev && ev.message ? ev.message : "unknown"); }
});

const VIEW_ONLY=false;
const LAYERS_EDIT_ONLY=false;
const IS_LAYOUT_SOURCE=false;
const SHARE_FOLLOW_MAIN=true;
function blockEdit(){
  if(typeof SHARE_FOLLOW_MAIN!=="undefined" && SHARE_FOLLOW_MAIN){
    alert("Share chart — dock layout follows MAIN. Slip status still editable here.");
    return true;
  }
  if(typeof LAYERS_EDIT_ONLY!=="undefined" && LAYERS_EDIT_ONLY){
    alert("Layers-only chart — dock positions are locked. Use the Layers tab to assign slip colors.");
    return true;
  }
  if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){
    alert("This is a view-only chart. You can switch and hide/show layers, but docks and slips stay fixed.");
    return true;
  }
  return false;
}
function walkGeomFromDock(d){
  if(d.type==="ns"){const w=d.sw||40,h=d.sh||15,g=d.gap||3,n=Math.max((d.a||[]).length,(d.b||[]).length);return {x:d.x+w+2,y:d.y-4,w:12,h:n*(h+g)+10};}
  if(d.type==="ew"){const w=d.sw||16,h=d.sh||36,g=d.gap||3,n=Math.max((d.a||[]).length,(d.b||[]).length);return {x:d.x-4,y:d.y+h+2,w:n*(w+g)+10,h:12};}
  const n=(d.a||[]).length,g=d.gap||18,h=d.h||16;return {x:d.x+(d.w||40)+4,y:d.y-2,w:10,h:Math.max(20,n*g-g+h+8)};
}
function generatedSlips(d){
  const out=[];
  if(d.type==="ns"){const w=d.sw||40,h=d.sh||15,g=d.gap||3;(d.a||[]).forEach((num,i)=>out.push({id:String(num),num,x:d.x,y:d.y+i*(h+g),w,h}));(d.b||[]).forEach((num,i)=>out.push({id:String(num),num,x:d.x+w+16,y:d.y+i*(h+g),w,h}));}
  else if(d.type==="ew"){const w=d.sw||16,h=d.sh||36,g=d.gap||3;(d.a||[]).forEach((num,i)=>out.push({id:String(num),num,x:d.x+i*(w+g),y:d.y,w,h}));(d.b||[]).forEach((num,i)=>out.push({id:String(num),num,x:d.x+i*(w+g),y:d.y+h+16,w,h}));}
  else if(d.type==="col"){const w=d.w||40,h=d.h||16,g=d.gap||18;(d.a||[]).forEach((num,i)=>out.push({id:String(num),num,x:d.x,y:d.y+i*g,w,h}));}
  (d.extras||[]).forEach(ex=>out.push({id:String(ex.num),num:ex.num,x:d.x+(ex.dx||0),y:d.y+(ex.dy||0),w:ex.w,h:ex.h,kind:ex.kind,size:ex.size,filter:ex.filter}));
  return out;
}
function applyPlaced(d,s){
  const p=(d.placed||{})[s.id];
  if(!p) return s;
  return Object.assign({},s,{x:p.x,y:p.y,w:p.w!=null?p.w:s.w,h:p.h!=null?p.h:s.h,rot:p.rot||0,fill:p.fill});
}
function setPlaced(d,id,patch){
  d.placed=d.placed||{};
  d.placed[id]=Object.assign({},d.placed[id]||{},patch);
}
function moveDockSlips(d,dx,dy){
  if(!d.placed) return;
  Object.keys(d.placed).forEach(id=>{d.placed[id].x+=dx;d.placed[id].y+=dy;});
}
function findDockForSlipId(slipId){
  const sid=String(slipId);
  return docks.find(d=> generatedSlips(d).some(s=>String(s.id)===sid)) || null;
}
function slipWorldPos(slipId){
  const d=findDockForSlipId(slipId);
  if(!d) return null;
  const base=generatedSlips(d).find(s=>String(s.id)===String(slipId));
  if(!base) return null;
  return {dock:d, slip:applyPlaced(d, base)};
}
function moveSlipById(slipId,dx,dy){
  const info=slipWorldPos(slipId);
  if(!info) return;
  const s=info.slip, d=info.dock;
  setPlaced(d, String(slipId), {
    x:(Number(s.x)||0)+(Number(dx)||0),
    y:(Number(s.y)||0)+(Number(dy)||0),
    w:s.w, h:s.h,
    rot:s.rot||0,
    fill:s.fill
  });
}

const MAP_W=3200, MAP_H=2400; // SVG viewBox -- hard edit working area (v85: aerial none stretches full photo to fill)
const WORLD_W=MAP_W, WORLD_H=MAP_H;
function unionBox(a,b){
  if(!a) return b; if(!b) return a;
  const x=Math.min(a.x,b.x), y=Math.min(a.y,b.y);
  return {x,y,w:Math.max(a.x+a.w,b.x+b.w)-x,h:Math.max(a.y+a.h,b.y+b.h)-y};
}
function dockBBox(d){
  let box=null;
  try{
    const g=walkGeomFromDock(d);
    box=unionBox(box,{x:g.x,y:g.y,w:Math.max(1,g.w),h:Math.max(1,g.h)});
  }catch(e){}
  box=unionBox(box,{x:(Number(d.x)||0)-30,y:(Number(d.y)||0)-28,w:60,h:22});
  try{
    generatedSlips(d).forEach(s=>{
      const p=applyPlaced(d,s);
      box=unionBox(box,{x:Number(p.x)||0,y:Number(p.y)||0,w:Math.max(1,Number(p.w)||10),h:Math.max(1,Number(p.h)||10)});
    });
  }catch(e){}
  return box||{x:Number(d.x)||0,y:Number(d.y)||0,w:10,h:10};
}
function markBBox(m){
  const box=markHitBox(m);
  return box||{x:Number(m.x)||0,y:Number(m.y)||0,w:10,h:10};
}
function slipBBoxFrom(d, slipId, fallback){
  try{
    const s=generatedSlips(d).map(x=>applyPlaced(d,x)).find(x=>String(x.id)===String(slipId));
    if(s) return {x:Number(s.x)||0,y:Number(s.y)||0,w:Math.max(1,Number(s.w)||10),h:Math.max(1,Number(s.h)||10)};
  }catch(e){}
  if(fallback) return {x:fallback.x,y:fallback.y,w:Math.max(1,fallback.w||10),h:Math.max(1,fallback.h||10)};
  return {x:0,y:0,w:10,h:10};
}
function keysBBox(keys){
  let box=null;
  (keys||[]).forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind==="dock"){ const d=docks.find(x=>x.id===id); if(d) box=unionBox(box,dockBBox(d)); }
    else if(kind==="mark"){ const m=marks.find(x=>x.id===id); if(m) box=unionBox(box,markBBox(m)); }
    else if(kind==="slip"){
      const info=slipWorldPos(id);
      if(info && info.slip){
        const s=info.slip;
        box=unionBox(box,{x:Number(s.x)||0,y:Number(s.y)||0,w:Math.max(1,Number(s.w)||10),h:Math.max(1,Number(s.h)||10)});
      }
    }
  });
  return box;
}
/** Clamp a proposed translation so bbox stays inside the map. If already OOB, pulls back in. */
function clampDeltaForBox(box, dx, dy){
  if(!box) return {dx:0,dy:0};
  let ndx=Number(dx)||0, ndy=Number(dy)||0;
  const w=Math.max(1, Number(box.w)||1), h=Math.max(1, Number(box.h)||1);
  const x=Number(box.x)||0, y=Number(box.y)||0;
  if(w>=MAP_W) ndx=-x;
  else{
    if(x+ndx<0) ndx=-x;
    if(x+w+ndx>MAP_W) ndx=MAP_W-(x+w);
  }
  if(h>=MAP_H) ndy=-y;
  else{
    if(y+ndy<0) ndy=-y;
    if(y+h+ndy>MAP_H) ndy=MAP_H-(y+h);
  }
  return {dx:ndx,dy:ndy};
}
function clampLayoutIntoMap(){
  let changed=false;
  docks.forEach(d=>{
    const box=dockBBox(d);
    const {dx,dy}=clampDeltaForBox(box,0,0);
    if(dx||dy){
      if(isLocked(d)) moveDockSlips(d,dx,dy);
      d.x=(Number(d.x)||0)+dx; d.y=(Number(d.y)||0)+dy; changed=true;
    }
    if(d.placed){
      Object.keys(d.placed).forEach(id=>{
        const b=slipBBoxFrom(d,id,d.placed[id]);
        const c=clampDeltaForBox(b,0,0);
        if(c.dx||c.dy){
          const p=d.placed[id];
          setPlaced(d,id,{x:(Number(p.x)||b.x)+c.dx,y:(Number(p.y)||b.y)+c.dy});
          changed=true;
        }
      });
    }
  });
  marks.forEach(m=>{
    const box=markBBox(m);
    const {dx,dy}=clampDeltaForBox(box,0,0);
    if(dx||dy){ m.x=(Number(m.x)||0)+dx; m.y=(Number(m.y)||0)+dy; changed=true; }
  });
  return changed;
}
let mapBoundRect=null;
function syncMapBoundVisual(){
  if(!svg) return;
  if(!mapBoundRect){
    mapBoundRect=el("rect",{
      id:"map-edit-bound",
      x:"0",y:"0",width:String(MAP_W),height:String(MAP_H),
      fill:"none", stroke:"#9ad5d0", "stroke-width":"4",
      "stroke-dasharray":"22 14", opacity:"0.9",
      "pointer-events":"none"
    });
    svg.appendChild(mapBoundRect);
  }
  mapBoundRect.setAttribute("visibility", editing ? "visible" : "hidden");
  // Clip paint to the true chart so letterbox/chrome cannot act as a fake canvas
  svg.setAttribute("overflow", "hidden");
}

function isDockPieceMark(id){ return /^(walk|dlabel)-(7|8|9|10|11|12|13|4|3|2|1|5|sales|fuel|courtesy|cruiser|houseboats)$/.test(id); }
let deepZoom=true;
let photoMax=0.9;
let photoAlign={x:0,y:0,scale:1,scaleX:1,scaleY:1,rot:0}; // overlay registration vs chart
const PHOTO_ALIGN_STORE="laceys-photo-align-v87";

function clampPhotoScale(v){ return Math.max(0.2, Math.min(5, Number(v)||1)); }
/** Normalize saved align: old `scale` → both axes; prefer scaleX/scaleY when present. */
function normalizePhotoAlign(raw){
  if(!raw || typeof raw!=="object") return {x:0,y:0,scale:1,scaleX:1,scaleY:1,rot:0};
  const hasXY = raw.scaleX!=null || raw.scaleY!=null;
  const legacy = clampPhotoScale(raw.scale);
  const scaleX = clampPhotoScale(hasXY ? (raw.scaleX!=null?raw.scaleX:legacy) : legacy);
  const scaleY = clampPhotoScale(hasXY ? (raw.scaleY!=null?raw.scaleY:legacy) : legacy);
  return {
    x:Number(raw.x)||0,
    y:Number(raw.y)||0,
    scaleX, scaleY,
    scale: clampPhotoScale((scaleX+scaleY)/2),
    rot:Number(raw.rot)||0
  };
}
function syncPhotoAlignScaleAvg(){
  photoAlign.scale = clampPhotoScale(((Number(photoAlign.scaleX)||1)+(Number(photoAlign.scaleY)||1))/2);
}
const LABEL_SIZE_STORE="laceys-label-size-v1";
const LABEL_PX={small:8,classic:9,normal:11,large:14,xl:20};
let labelSizeKey="normal";
let photoMoveMode=false;
let dockAlignMode=false;
let gcpMode=false;
let gcpPairs=[]; // {ax,ay,bx,by}
let gcpPending=null; // {ax,ay} waiting for photo point
let gcpDrag=null; // tap vs pan while in GCP mode
const GCP_STORE="laceys-gcp-pairs-v1";
const SCALE_STORE="laceys-scale-v1";
let chartScaleCal={chartUnitsPerFoot:null,feetPerChartUnit:null}; // null = uncalibrated
let scaleMeasureMode=false;
let scaleForceCalibrate=false; // next 2-click pair is a calibration
let scalePts=[]; // [{x,y}, ...] up to 2
let scaleDrag=null;
let scaleLive={x2:null,y2:null}; // rubber-band second point while waiting
var dockEditorMore=false;
var stretchToolsOpen=false;
let scaleLastRecipe=null; // last calculate() result
let scale=1,tx=0,ty=0; // view transform — must exist before first redraw/label sizing
const chart=document.getElementById("chart"); // must exist before first redraw → applyDeepZoomLod → chartSize
let photoDrag=null;
let dockAlignDrag=null;
const photoPointers=new Map(); // pinch while moving photo
const dockAlignPointers=new Map();

function loadPhotoAlign(){
  try{
    const raw=JSON.parse(localStorage.getItem(PHOTO_ALIGN_STORE)||"null");
    if(raw && typeof raw==="object"){
      photoAlign=normalizePhotoAlign(raw);
    }
  }catch(e){}
}
function savePhotoAlign(){
  try{
    syncPhotoAlignScaleAvg();
    localStorage.setItem(PHOTO_ALIGN_STORE, JSON.stringify(photoAlign));
  }catch(e){}
}
function loadLabelSize(){
  try{
    const raw=localStorage.getItem(LABEL_SIZE_STORE);
    if(raw && LABEL_PX[raw]!=null) labelSizeKey=raw;
  }catch(e){}
}
function saveLabelSize(){
  try{ localStorage.setItem(LABEL_SIZE_STORE, labelSizeKey); }catch(e){}
}
function targetLabelPx(){ return LABEL_PX[labelSizeKey]||10; }
/** Label size control sets world-unit slip fonts (not zoom-boosted). */
function screenAwareFontSize(worldBase){
  // Prefer the Label size setting; fall back to designed world base
  const fromUi=LABEL_PX[labelSizeKey];
  if(fromUi!=null) return fromUi;
  return Number(worldBase)||9;
}
function labelStrokeWidth(fs){ return 0; }
function slipLabelAttrs(x,y,worldBase){
  const fs=screenAwareFontSize(worldBase);
  return {
    x, y, "text-anchor":"middle",
    fill:"#1b2423", "font-size":String(fs), "font-weight":"700",
    style:"font-size:"+fs+"px",
    class:"slip-num"
  };
}
function dockNameLabelAttrs(x,y,worldBase){
  const slipFs=screenAwareFontSize(9);
  const fs=Math.round((Number(worldBase)||14) * (slipFs/9));
  return {
    x, y, fill:"#d7eceb", "font-size":String(fs), "font-weight":"700",
    class:"dock-name-label"
  };
}
function syncLabelFonts(){
  try{
    const slipFs=screenAwareFontSize(9);
    svg.querySelectorAll("text.slip-num").forEach(t=>{
      t.setAttribute("font-size", String(slipFs));
      t.style.fontSize=slipFs+"px";
    });
    const dockFs=Math.round(14*(slipFs/9));
    svg.querySelectorAll("text.dock-name-label").forEach(t=>{
      t.setAttribute("font-size", String(dockFs));
      t.style.fontSize=dockFs+"px";
    });
  }catch(e){}
}
loadLabelSize();
function applyPhotoAlign(){
  if(!bgImg) return;
  const sx=clampPhotoScale(photoAlign.scaleX!=null?photoAlign.scaleX:photoAlign.scale);
  const sy=clampPhotoScale(photoAlign.scaleY!=null?photoAlign.scaleY:photoAlign.scale);
  photoAlign.scaleX=sx; photoAlign.scaleY=sy; syncPhotoAlignScaleAvg();
  const cx=MAP_W/2, cy=MAP_H/2; // chart working-area center
  const W=MAP_W, H=MAP_H;
  const rot=Number(photoAlign.rot)||0;
  // Base image rect fills MAP_W×MAP_H with preserveAspectRatio none (whole aerial, no crop — v85/v87).
  // WORKFLOW to line docks ↔ aerial:
  //   A) Fill work area → Move photo + Stretch width/height + Rotate until aerial roughly matches docks, OR
  //   B) GCP align: tap dock corner (A) then matching aerial spot (B), 2+ pairs → Apply (moves/scales docks onto photo).
  // Photo transform and dock GCP are independent spaces: move the photo OR transform the docks — do not fight both at once.
  // Non-uniform scaleX/scaleY via transform so Stretch width pulls independently of height.
  const dx=Number(photoAlign.x)||0;
  const dy=Number(photoAlign.y)||0;
  bgImg.setAttribute("x", "0");
  bgImg.setAttribute("y", "0");
  bgImg.setAttribute("width", String(W));
  bgImg.setAttribute("height", String(H));
  bgImg.setAttribute("preserveAspectRatio", "none");
  // Center of photo working area after pan is (cx+dx, cy+dy); scale/rotate about that.
  const px=cx+dx, py=cy+dy;
  if(dx||dy||rot||Math.abs(sx-1)>1e-6||Math.abs(sy-1)>1e-6){
    const parts=[`translate(${px} ${py})`];
    if(rot) parts.push(`rotate(${rot})`);
    if(Math.abs(sx-1)>1e-6||Math.abs(sy-1)>1e-6) parts.push(`scale(${sx} ${sy})`);
    parts.push(`translate(${-cx} ${-cy})`);
    bgImg.setAttribute("transform", parts.join(" "));
  }else{
    bgImg.removeAttribute("transform");
  }
  const sxEl=document.getElementById("photo-scale-x");
  const syEl=document.getElementById("photo-scale-y");
  const sxv=document.getElementById("photo-scale-x-val");
  const syv=document.getElementById("photo-scale-y-val");
  const rv=document.getElementById("photo-rot-val");
  const rr=document.getElementById("photo-rot");
  // UI range 20–500%; still allow internal values outside via pinch/legacy (min clamp 0.2)
  if(sxEl) sxEl.value=String(Math.round(Math.max(20, Math.min(500, sx*100))));
  if(syEl) syEl.value=String(Math.round(Math.max(20, Math.min(500, sy*100))));
  const sxNum=document.getElementById("photo-scale-x-num");
  const syNum=document.getElementById("photo-scale-y-num");
  if(sxNum) sxNum.value=String(Math.round(sx*100));
  if(syNum) syNum.value=String(Math.round(sy*100));
  if(sxv) sxv.textContent=Math.round(sx*100)+"%";
  if(syv) syv.textContent=Math.round(sy*100)+"%";
  if(rr) rr.value=String(rot);
  if(rv) rv.textContent=(Math.round(rot*10)/10)+"°";
}

function loadLayersStandalone(){
  try{
    const raw=JSON.parse(localStorage.getItem("laceys-layers-v1")||"null");
    if(Array.isArray(raw)&&raw.length) return raw;
  }catch(e){}
  if(typeof DEFAULT_LAYERS!=="undefined"&&Array.isArray(DEFAULT_LAYERS)) return clone(DEFAULT_LAYERS);
  return [];
}
function loadLayout(){
  try{
    const raw=JSON.parse(localStorage.getItem(LAYOUT_STORE)||"null");
    const defaultStack=(typeof DEFAULT_STACK_ORDER!=="undefined"&&Array.isArray(DEFAULT_STACK_ORDER)&&DEFAULT_STACK_ORDER.length)?clone(DEFAULT_STACK_ORDER):[];
    const defaultLayers=(typeof DEFAULT_LAYERS!=="undefined"&&Array.isArray(DEFAULT_LAYERS))?clone(DEFAULT_LAYERS):loadLayersStandalone();
    if(!raw||!Array.isArray(raw.docks)||!raw.docks.length){
      return {docks:clone(DEFAULT_DOCKS),marks:clone(DEFAULT_MARKS),groups:(typeof DEFAULT_GROUPS!=="undefined"&&Array.isArray(DEFAULT_GROUPS))?clone(DEFAULT_GROUPS):[],layers:defaultLayers,stackOrder:defaultStack};
    }
    // Saved layout is authoritative so deletes (parking oval, etc.) and positions stick.
    const docks=clone(raw.docks);
    const marks=clone((raw.marks||[]).filter(m=>m && !isDockPieceMark(m.id)));
    const layers=Array.isArray(raw.layers)?clone(raw.layers):defaultLayers;
    let stackOrder=Array.isArray(raw.stackOrder)?clone(raw.stackOrder):[];
    if(!stackOrder.length) stackOrder=defaultStack;
    // v86 aerial: ignore stale photoAlign embedded in layout JSON (tuned to prior photo).
    // Alignment lives in PHOTO_ALIGN_STORE (bumped key); empty key → default fill 100%/0/0.
    // Do not wipe docks/marks — only skip image registration from layout.
    if(raw.photoMax!=null){ photoMax=Math.max(0, Math.min(1, Number(raw.photoMax))); }
    return {docks,marks,groups:Array.isArray(raw.groups)?clone(raw.groups):[],layers,stackOrder};
  }catch{
    const defaultStack=(typeof DEFAULT_STACK_ORDER!=="undefined"&&Array.isArray(DEFAULT_STACK_ORDER)&&DEFAULT_STACK_ORDER.length)?clone(DEFAULT_STACK_ORDER):[];
    const defaultLayers=(typeof DEFAULT_LAYERS!=="undefined"&&Array.isArray(DEFAULT_LAYERS))?clone(DEFAULT_LAYERS):loadLayersStandalone();
    return {docks:clone(DEFAULT_DOCKS),marks:clone(DEFAULT_MARKS),groups:[],layers:defaultLayers,stackOrder:defaultStack};
  }
}
const hist=[], future=[];
let lastSnap=null;
function snap(){ return JSON.stringify({docks,marks,groups,layers,photoAlign,photoMax,stackOrder}); }
function restoreSnap(s){
  const raw=JSON.parse(s);
  docks=raw.docks; marks=raw.marks; groups=raw.groups||[];
  stackOrder=Array.isArray(raw.stackOrder)?raw.stackOrder:[];
  if(Array.isArray(raw.layers)) layers=raw.layers;
  if(raw.photoAlign){
    photoAlign=normalizePhotoAlign(raw.photoAlign);
    savePhotoAlign();
  }
  if(raw.photoMax!=null) photoMax=Math.max(0, Math.min(1, Number(raw.photoMax)));
  lastSnap=s;
  localStorage.setItem(LAYOUT_STORE, s);
  try{ localStorage.setItem("laceys-layers-v1", JSON.stringify(layers)); }catch(e){}
  selected=null; selectedDock=null; selectedMark=null; multi.clear(); moveWholeChart=false;
  redraw(); applyPhotoAlign(); applyDeepZoomLod(); renderDockEditor(); renderLayersEditor(); updateUndoBtns(); updateSelHint(); ensureMapVisible(); renderLayersEditor(); renderChips();
}
function undo(){ if(!hist.length) return; future.push(snap()); restoreSnap(hist.pop()); }
function redo(){ if(!future.length) return; hist.push(snap()); restoreSnap(future.pop()); }
function updateUndoBtns(){
  const u=document.getElementById("btn-undo"), r=document.getElementById("btn-redo");
  if(u){ u.disabled=!hist.length; u.style.opacity=hist.length?1:.45; }
  if(r){ r.disabled=!future.length; r.style.opacity=future.length?1:.45; }
}
function saveLayout(record){
  if(record!==false){
    if(lastSnap==null) lastSnap=snap();
    hist.push(lastSnap);
    if(hist.length>80) hist.shift();
    future.length=0;
    lastSnap=snap();
  }
  localStorage.setItem(LAYOUT_STORE, snap());
  try{ savePhotoAlign(); }catch(e){}
  updateUndoBtns();
}
let {docks,marks,groups,layers,stackOrder}=loadLayout();
if(!Array.isArray(layers)) layers=[];
if(!Array.isArray(stackOrder)) stackOrder=[];
let activeLayerId=null;
let layerOptFilter="All";
function sanitizeLayout(){
  let changed=false;
  // Hard clamp geometry into the real chart (viewBox 0,0,MAP_W x MAP_H) -- never keep OOB placements.
  if(clampLayoutIntoMap()) changed=true;
  docks.forEach(d=>{
    (d.extras||[]).forEach(ex=>{
      // Only stop absurd cover-the-map sizes -- do NOT shrink intentional tall slips (e.g. 839/840 at 40x300)
      if((ex.w||0)>900 && (ex.h||0)>900){ ex.w=Math.min(ex.w,120); ex.h=Math.min(ex.h,40); changed=true; }
    });
    if(d.placed){
      Object.keys(d.placed).forEach(id=>{
        const p=d.placed[id]; if(!p) return;
        if((p.w||0)>900 && (p.h||0)>900){
          p.w=d.sw||d.w||40; p.h=d.sh||d.h||16; changed=true;
        }
      });
    }
    // Keep dock default slip sizes reasonable, but allow large individual extras/placed above
    if((d.sw||0)>400){ d.sw=40; changed=true; }
    if((d.sh||0)>400){ d.sh=36; changed=true; }
  });
  const before=docks.length;
  docks=docks.filter(d=>{
    const name=(d.name||"").toLowerCase();
    if(name==="loose slips"||name==="extra slips") return false;
    return true;
  });
  if(docks.length!==before) changed=true;
  marks=marks.filter(m=>!((m.w||0)>1800 || (m.h||0)>1600));
  // If a bad save wiped almost everything, restore the baked main layout.
  if(docks.length < Math.min(8, DEFAULT_DOCKS.length)){
    docks=clone(DEFAULT_DOCKS);
    marks=clone(DEFAULT_MARKS);
    groups=[];
    changed=true;
  }
  return changed;
}
if(sanitizeLayout()) saveLayout(false);
lastSnap=snap();
let slips=[], selected=null, selectedDock=null, selectedMark=null, filter="All", editing=false;
const multi=new Set(); // "dock:id" or "mark:id"
let multiPick=false; // tap-to-toggle selection (mobile-friendly)
let moveWholeChart=false;
function updateSelHint(){
  const el=document.getElementById("sel-hint"); if(!el) return;
  document.querySelectorAll("#btn-multi, #btn-multi-hdr").forEach(btn=>{ if(btn) btn.classList.toggle("on", multiPick); });
  document.body.classList.toggle("multipick", !!(editing && multiPick));
  document.body.classList.toggle("sel-active", !!(editing && multi.size>1));
  const countEl=document.getElementById("multi-count");
  if(countEl) countEl.textContent = multi.size ? (multi.size+" selected") : "Tap list or map to pick";
  const moveBtn=document.getElementById("btn-multi-move");
  if(moveBtn){ moveBtn.disabled = multi.size<1; moveBtn.textContent = multiPick ? "Move selected" : "Moving…"; }
  if(multiPick){
    el.textContent = multi.size ? (multi.size+" selected · tick more in the list, or tap Done") : "Tick docks/slips/labels in the list below (or tap the map)";
  }else if(moveWholeChart || multi.size>1){
    el.textContent = (multi.size||"All")+" selected · drag selected to move · tap map to add/remove · Scale −/+ or type Slip W/H · Add/remove for checklist";
  }else{
    el.textContent = "Multi-select opens a checklist — easiest on phones.";
  }
  renderPickList();
  updateSelChip();
  try{ syncMultiGeomInputs(); }catch(e){}
}
function pieceLabel(kind,id){
  if(kind==="slip"){
    const info=slipWorldPos(id);
    if(info && info.slip){
      const num=String(info.slip.num!=null?info.slip.num:id);
      const dockName=info.dock && info.dock.name ? (" · Dock "+info.dock.name) : "";
      return ((/^\d+$/.test(num)?"Slip ":"")+num)+dockName;
    }
    return "Slip "+id;
  }
  if(kind==="dock"){
    const d=docks.find(x=>x.id===id);
    return d ? ("Dock "+(d.name||d.id)) : ("Dock "+id);
  }
  const m=marks.find(x=>x.id===id);
  if(!m) return id;
  if(m.kind==="text") return "Label: "+(m.text||m.id);
  if(m.kind==="box") return "Building: "+(m.t1||m.id);
  if(m.kind==="bar") return "Walkway: "+(m.title||m.id);
  if(m.kind==="pill") return "Sign: "+(m.label||m.text||m.id);
  if(m.kind==="p") return "Parking";
  return (m.kind||"Piece")+": "+(m.title||m.text||m.id);
}
function currentSelectionLabel(){
  if(!editing) return "";
  if(multi.size>1) return multi.size+" selected";
  if(multi.size===1){
    const k=[...multi][0];
    const {kind,id}=parseMemberKey(k);
    return pieceLabel(kind==="mark"?"mark":(kind==="slip"?"slip":"dock"), id);
  }
  if(selected && editing){
    const s=slips.find(x=>x.id===selected);
    if(s){
      const num=String(s.num);
      return (/^\d+$/.test(num)?"Slip ":"")+num+(s.dock?(" · Dock "+s.dock):"");
    }
  }
  if(selectedDock) return pieceLabel("dock", selectedDock);
  if(selectedMark) return pieceLabel("mark", selectedMark);
  if(moveWholeChart) return "Entire map selected";
  return "";
}
function updateSelChip(){
  const label=currentSelectionLabel();
  const chips=[document.getElementById("edit-sel-chip"), document.getElementById("edit-sel-chip-desk")];
  chips.forEach(chip=>{
    if(!chip) return;
    if(!editing || !label){ chip.hidden=true; chip.textContent=""; return; }
    chip.hidden=false;
    chip.textContent=label;
  });
  // Keep mobile chrome height correct when chip appears/disappears
  if(editing){ try{ syncEditChromeHeight(); }catch(e){} }
}
function renderPickList(){
  const box=document.getElementById("pick-list");
  if(!box) return;
  if(!(editing && multiPick)){ box.hidden=true; box.innerHTML=""; return; }
  box.hidden=false;
  const rows=[];
  rows.push('<div class="pick-section">Docks</div>');
  docks.forEach(d=>{
    const k="dock:"+d.id;
    const on=multi.has(k);
    rows.push(`<label class="pick-row${on?" on":""}" data-k="${k}"><input type="checkbox" ${on?"checked":""}/><span>${pieceLabel("dock",d.id)}${isLocked(d)?"":" · unlocked"}</span></label>`);
  });
  rows.push('<div class="pick-section">Dock sides</div>');
  docks.forEach(d=>{
    [["a","Side A (left/top)"],["b","Side B (right/bottom)"]].forEach(([side,label])=>{
      const nums=(d[side]||[]).map(String);
      if(!nums.length) return;
      const slipKeys=nums.map(n=>"slip:"+n);
      const on=slipKeys.every(k=>multi.has(k));
      const sk="side:"+d.id+":"+side;
      rows.push(`<label class="pick-row${on?" on":""}" data-side-keys="${slipKeys.join(",")}" data-k="${sk}"><input type="checkbox" ${on?"checked":""}/><span>${d.name||d.id} · ${label} (${nums.length})</span></label>`);
    });
  });
  rows.push('<div class="pick-section">Slips</div>');
  const slipRows=[];
  docks.forEach(d=>{
    generatedSlips(d).forEach(s=>{
      const id=String(s.id);
      const k="slip:"+id;
      const on=multi.has(k);
      const label=pieceLabel("slip", id)+(isLocked(d)?"":" · free");
      slipRows.push({k,on,label,sort:String(s.num!=null?s.num:id)});
    });
  });
  slipRows.sort((a,b)=>String(a.sort).localeCompare(String(b.sort), undefined, {numeric:true}));
  slipRows.forEach(r=>{
    rows.push(`<label class="pick-row${r.on?" on":""}" data-k="${r.k}"><input type="checkbox" ${r.on?"checked":""}/><span>${r.label}</span></label>`);
  });
  rows.push('<div class="pick-section">Labels & pieces</div>');
  marks.forEach(m=>{
    const k="mark:"+m.id;
    const on=multi.has(k);
    rows.push(`<label class="pick-row${on?" on":""}" data-k="${k}"><input type="checkbox" ${on?"checked":""}/><span>${pieceLabel("mark",m.id)}</span></label>`);
  });
  box.innerHTML=rows.join("");
  box.querySelectorAll(".pick-row").forEach(row=>{
    const inp=row.querySelector("input");
    const apply=()=>{
      const sideKeys=row.getAttribute("data-side-keys");
      if(sideKeys){
        sideKeys.split(",").filter(Boolean).forEach(k=>{
          if(inp.checked) multi.add(k); else multi.delete(k);
        });
        if(multi.size<=1) moveWholeChart=false;
        updateSelHint(); redraw(); renderDockEditor();
        return;
      }
      const k=row.getAttribute("data-k");
      if(inp.checked) multi.add(k); else multi.delete(k);
      if(multi.size<=1) moveWholeChart=false;
      // sync selected for editor
      if(k.startsWith("dock:")){ selectedDock=k.slice(5); selectedMark=null; selected=null; }
      else if(k.startsWith("slip:")){ selected=k.slice(5); selectedDock=null; selectedMark=null; }
      else if(k.startsWith("mark:")){ selectedMark=k.slice(5); selectedDock=null; selected=null; }
      updateSelHint();
      redraw();
      renderDockEditor();
    };
    inp.onchange=apply;
    // whole row already toggles checkbox via label
  });
}
function setMultiPick(on){
  multiPick=!!on;
  if(multiPick){
    if(!editing){ if(blockEdit()) return; document.getElementById("edit-toggle").click(); }
    moveWholeChart=false;
    showTab("layout");
    document.getElementById("hint").textContent="Multi-select · tick docks/slips/labels (or tap the map)";
  }else{
    document.getElementById("hint").textContent = multi.size>1 ? "Drag on the map to move the selection" : "Drag docks/labels · Multi-select to pick several";
  }
  updateSelHint();
  redraw();
}
function memberKey(kind,id){ return kind+":"+id; }
function findGroupFor(kind,id){
  const k=memberKey(kind,id);
  return groups.find(g=> (g.members||[]).includes(k));
}
function parseMemberKey(k){
  const i=String(k).indexOf(":");
  if(i<0) return {kind:"",id:k};
  return {kind:k.slice(0,i), id:k.slice(i+1)};
}
function moveMembersByKeys(keys,dx,dy){
  const dockSet=new Set();
  (keys||[]).forEach(k=>{ const {kind,id}=parseMemberKey(k); if(kind==="dock") dockSet.add(id); });
  (keys||[]).forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind==="dock"){ const d=docks.find(x=>x.id===id); if(d){ if(isLocked(d)) moveDockSlips(d,dx,dy); d.x+=dx; d.y+=dy; } }
    else if(kind==="mark"){ const m=marks.find(x=>x.id===id); if(m){ m.x+=dx; m.y+=dy; } }
    else if(kind==="slip"){
      const d=findDockForSlipId(id);
      if(d && dockSet.has(d.id)) return; // parent dock move already covers geometry
      moveSlipById(id, dx, dy);
    }
  });
}
function moveGroupMembers(g,dx,dy){ moveMembersByKeys(g.members||[], dx, dy); }
function allLayoutKeys(){ return docks.map(d=>"dock:"+d.id).concat(marks.map(m=>"mark:"+m.id)); }
function markLodBucket(m){
  if(!m) return "site";
  if(m.kind==="bar") return "walk";
  if(m.kind==="pill"||m.kind==="text") return "labels";
  return "site";
}
function defaultStackOrder(){
  if(typeof DEFAULT_STACK_ORDER!=="undefined"&&Array.isArray(DEFAULT_STACK_ORDER)&&DEFAULT_STACK_ORDER.length){
    return clone(DEFAULT_STACK_ORDER);
  }
  // Match prior LOD paint order: site marks → walk marks → docks → labels
  const site=[], walk=[], dockKeys=[], labels=[];
  marks.forEach(m=>{
    const k="mark:"+m.id; const b=markLodBucket(m);
    if(b==="labels") labels.push(k); else if(b==="walk") walk.push(k); else site.push(k);
  });
  docks.forEach(d=>dockKeys.push("dock:"+d.id));
  return site.concat(walk, dockKeys, labels);
}
function ensureStackOrder(){
  const want=allLayoutKeys();
  const wantSet=new Set(want);
  const keep=[];
  const seen=new Set();
  const src=(stackOrder&&stackOrder.length)?stackOrder:defaultStackOrder();
  src.forEach(k=>{ if(wantSet.has(k) && !seen.has(k)){ keep.push(k); seen.add(k); } });
  // New pieces append to front (end of list = painted last)
  want.forEach(k=>{ if(!seen.has(k)){ keep.push(k); seen.add(k); } });
  stackOrder=keep;
}
function stackCtrlHtml(){
  return `<p class="hint" style="margin-top:10px">Stack order (what sits in front)</p><div class="st"><button type="button" id="ed-stack-front">Bring to front</button><button type="button" id="ed-stack-forward">Forward</button></div><div class="st"><button type="button" id="ed-stack-back">Send to back</button><button type="button" id="ed-stack-backward">Back</button></div>`;
}
function stackKeysForEditor(){
  if(multi.size>1) return [...multi];
  if(selectedDock) return ["dock:"+selectedDock];
  if(selectedMark) return ["mark:"+selectedMark];
  return [];
}
function stackMove(keys, mode){
  ensureStackOrder();
  const set=new Set(keys||[]);
  if(!set.size) return false;
  const selected=stackOrder.filter(k=>set.has(k));
  if(!selected.length) return false;
  const rest=stackOrder.filter(k=>!set.has(k));
  if(mode==="front") stackOrder=rest.concat(selected);
  else if(mode==="back") stackOrder=selected.concat(rest);
  else if(mode==="forward"){
    const arr=stackOrder.slice();
    for(let i=arr.length-2;i>=0;i--){
      if(set.has(arr[i]) && !set.has(arr[i+1])){ const t=arr[i]; arr[i]=arr[i+1]; arr[i+1]=t; }
    }
    stackOrder=arr;
  }else if(mode==="backward"){
    const arr=stackOrder.slice();
    for(let i=1;i<arr.length;i++){
      if(set.has(arr[i]) && !set.has(arr[i-1])){ const t=arr[i]; arr[i]=arr[i-1]; arr[i-1]=t; }
    }
    stackOrder=arr;
  }else return false;
  return true;
}
function bindStackButtons(){
  const keys=stackKeysForEditor();
  const go=mode=>{ if(!stackMove(keys, mode)) return; saveLayout(); redraw(); renderDockEditor(); };
  const map={front:"ed-stack-front",forward:"ed-stack-forward",back:"ed-stack-back",backward:"ed-stack-backward"};
  Object.keys(map).forEach(mode=>{ const b=document.getElementById(map[mode]); if(b) b.onclick=()=>go(mode); });
}
function clearLayerNudge(){
  [layerBg, layerStack, layerSite, layerWalkMarks, layerDocks, layerSlips, layerLabels, layerMarks].forEach(L=>{ if(L) L.removeAttribute("transform"); });
}
function clearSelectionNudge(){
  try{
    if(svg){
      svg.querySelectorAll("[data-nudge-sel]").forEach(n=>{
        const base=n.getAttribute("data-base-tf");
        if(base!=null && base!=="") n.setAttribute("transform", base);
        else n.removeAttribute("transform");
        n.removeAttribute("data-nudge-sel");
        n.removeAttribute("data-base-tf");
      });
    }
  }catch(_){}
  clearLayerNudge();
}
function cssAttrEscape(id){
  return String(id==null?"":id).replace(/\\/g,"\\\\").replace(/"/g,"\\\"");
}
function keysCoverEntireLayout(keys){
  const all=allLayoutKeys();
  if(!keys || !keys.length || keys.length<all.length) return false;
  const set=new Set(keys);
  return all.every(k=>set.has(k));
}
function nudgeSelectionKeys(keys,dx,dy,scaleF,cx,cy){
  // Partial selection: translate only those pieces so the rest of the map does not jump.
  // Full selection / select-all: keep the cheap whole-layer nudge.
  if(keysCoverEntireLayout(keys) || ((!keys||!keys.length) && moveWholeChart)){
    clearSelectionNudge();
    nudgeLayers(dx,dy,scaleF,cx,cy);
    return;
  }
  clearSelectionNudge();
  if(scaleF!=null && Math.abs(scaleF-1)>1e-6){
    // Pinch-scale still uses layer nudge (dock-align mode); partial scale is applied on pointerup.
    nudgeLayers(dx,dy,scaleF,cx,cy);
    return;
  }
  const keySet=new Set(keys||[]);
  const dockIds=new Set();
  keySet.forEach(k=>{ const {kind,id}=parseMemberKey(k); if(kind==="dock") dockIds.add(id); });
  const applyNode=n=>{
    if(!n||!n.setAttribute) return;
    if(n.getAttribute("data-nudge-sel")==="1") return;
    if(!n.hasAttribute("data-base-tf")) n.setAttribute("data-base-tf", n.getAttribute("transform")||"");
    const base=n.getAttribute("data-base-tf")||"";
    n.setAttribute("data-nudge-sel","1");
    n.setAttribute("transform", (dx||dy) ? (`translate(${dx} ${dy})`+(base?" "+base:"")) : base);
  };
  keySet.forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    const esc=cssAttrEscape(id);
    if(kind==="dock"){
      if(svg) svg.querySelectorAll('g.dock-hit[data-dock="'+esc+'"]').forEach(applyNode);
      // slips are children of the dock group — they ride along
    }else if(kind==="slip"){
      const info=slipWorldPos(id);
      if(info && dockIds.has(info.dock.id)) return; // parent dock already nudged
      if(svg) svg.querySelectorAll('g.slip[data-id="'+esc+'"]').forEach(applyNode);
    }else if(kind==="mark"){
      if(svg) svg.querySelectorAll('[data-mark="'+esc+'"]').forEach(applyNode);
    }
  });
}
function nudgeLayers(dx,dy,scaleF,cx,cy){
  // Never nudge layerBg — photo stays put while docks/marks move (Move photo owns the aerial)
  let t=`translate(${dx} ${dy})`;
  if(scaleF!=null && Math.abs(scaleF-1)>1e-6){
    const s=scaleF, ox=cx||(MAP_W/2), oy=cy||(MAP_H/2);
    t=`translate(${ox} ${oy}) scale(${s}) translate(${-ox} ${-oy}) translate(${dx} ${dy})`;
  }
  [layerStack, layerSite, layerWalkMarks, layerDocks, layerSlips, layerLabels, layerMarks].forEach(L=>{ if(L) L.setAttribute("transform", t); });
}
function scalePointXY(x,y,cx,cy,f){ return {x:cx+(x-cx)*f, y:cy+(y-cy)*f}; }
function scaleMembersByKeys(keys,f,cx,cy){
  f=Number(f)||1; if(Math.abs(f-1)<1e-9) return;
  const seenD=new Set(), seenM=new Set();
  const dockInKeys=new Set();
  (keys||[]).forEach(k=>{ const {kind,id}=parseMemberKey(k); if(kind==="dock") dockInKeys.add(id); });
  (keys||[]).forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind==="dock"){
      const d=docks.find(x=>x.id===id); if(!d||seenD.has(d.id)) return; seenD.add(d.id);
      const p=scalePointXY(Number(d.x)||0, Number(d.y)||0, cx, cy, f);
      d.x=p.x; d.y=p.y;
      ["sw","sh","w","h","gap"].forEach(prop=>{ if(d[prop]!=null) d[prop]=Number(d[prop])*f; });
      (d.extras||[]).forEach(ex=>{
        if(ex.dx!=null) ex.dx=Number(ex.dx)*f;
        if(ex.dy!=null) ex.dy=Number(ex.dy)*f;
        if(ex.w!=null) ex.w=Number(ex.w)*f;
        if(ex.h!=null) ex.h=Number(ex.h)*f;
      });
      if(d.placed){
        Object.keys(d.placed).forEach(pid=>{
          const pl=d.placed[pid]; if(!pl) return;
          if(pl.x!=null && pl.y!=null){
            const q=scalePointXY(Number(pl.x)||0, Number(pl.y)||0, cx, cy, f);
            pl.x=q.x; pl.y=q.y;
          }
          if(pl.w!=null) pl.w=Number(pl.w)*f;
          if(pl.h!=null) pl.h=Number(pl.h)*f;
        });
      }
    }else if(kind==="mark"){
      const m=marks.find(x=>x.id===id); if(!m||seenM.has(m.id)) return; seenM.add(m.id);
      const p=scalePointXY(Number(m.x)||0, Number(m.y)||0, cx, cy, f);
      m.x=p.x; m.y=p.y;
      if(m.w!=null) m.w=Number(m.w)*f;
      if(m.h!=null) m.h=Number(m.h)*f;
      if(m.size!=null) m.size=Number(m.size)*f;
    }else if(kind==="slip"){
      const info=slipWorldPos(id); if(!info) return;
      if(dockInKeys.has(info.dock.id)) return; // parent dock scaled
      const s=info.slip;
      const q=scalePointXY(Number(s.x)||0, Number(s.y)||0, cx, cy, f);
      setPlaced(info.dock, String(id), {
        x:q.x, y:q.y,
        w:(Number(s.w)||10)*f,
        h:(Number(s.h)||10)*f,
        rot:s.rot||0,
        fill:s.fill
      });
    }
  });
}
function selectionKeys(){
  if(multi.size) return [...multi];
  const keys=[];
  if(selectedDock) keys.push("dock:"+selectedDock);
  if(selectedMark) keys.push("mark:"+selectedMark);
  if(selected) keys.push("slip:"+selected);
  return keys;
}
function parentDocksFromKeys(keys){
  const ids=new Set();
  (keys||[]).forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind==="dock") ids.add(id);
    else if(kind==="slip"){ const d=findDockForSlipId(id); if(d) ids.add(d.id); }
  });
  return [...ids].map(id=>docks.find(d=>d.id===id)).filter(Boolean);
}
function bakeDockPlaced(d){
  if(!d) return;
  generatedSlips(d).forEach(raw=>{
    const s=applyPlaced(d, raw);
    if(!(d.placed&&d.placed[String(s.id)])){
      setPlaced(d, String(s.id), {x:s.x,y:s.y,w:s.w,h:s.h,rot:s.rot||0,fill:s.fill});
    }
  });
}
function unlockSelectionSlips(){
  const keys=selectionKeys();
  const docksToUnlock=parentDocksFromKeys(keys);
  if(!docksToUnlock.length){
    alert("Select a dock (or slips on a dock) first, then Unlock this dock.");
    return false;
  }
  // Unlock ONLY the parent dock(s) of the current selection — never every dock on the map
  docksToUnlock.forEach(d=>{ d.locked=false; bakeDockPlaced(d); });
  // Ensure each selected slip has placed coords so it can move independently
  keys.forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind!=="slip") return;
    const info=slipWorldPos(id); if(!info) return;
    const s=info.slip, d=info.dock;
    if(!(d.placed&&d.placed[String(id)])){
      setPlaced(d, String(id), {x:s.x,y:s.y,w:s.w,h:s.h,rot:s.rot||0,fill:s.fill});
    }
  });
  // Drop "Locked selection" groups that only covered these docks/slips
  const unlockIds=new Set(docksToUnlock.map(d=>d.id));
  groups=groups.filter(g=>{
    const mem=g.members||[];
    if((g.name==="Locked selection" || g.name==="Group") && mem.length){
      const touches=mem.some(k=>{
        const {kind,id}=parseMemberKey(k);
        if(kind==="dock") return unlockIds.has(id);
        if(kind==="slip"){ const d=findDockForSlipId(id); return d && unlockIds.has(d.id); }
        return false;
      });
      if(touches) return false;
    }
    return true;
  });
  multiPick=false;
  moveWholeChart=false;
  const names=docksToUnlock.map(d=>d.name||d.id).join(", ");
  const h=document.getElementById("hint");
  if(h) h.textContent="Unlocked "+names+" only · Multi-select / Add-remove freely · Lock as dock returns them to this parent";
  saveLayout(); redraw(); renderDockEditor(); updateSelHint(); updateSelChip();
  return true;
}
/** Ungroup + unlock only the dock(s) tied to the current selection (not the whole marina). */
function ungroupUnlockThisDock(){
  const keys=selectionKeys();
  if(!keys.length){
    alert("Select a dock or grouped slips first, then Ungroup / Unlock this dock.");
    return false;
  }
  const parents=parentDocksFromKeys(keys);
  // Remove groups that intersect this selection
  const keySet=new Set(keys);
  groups=groups.filter(g=>!(g.members||[]).some(k=>keySet.has(k)));
  // Unlock only those parent docks and bake placed geometry
  parents.forEach(d=>{ d.locked=false; bakeDockPlaced(d); });
  // Prefer a slip multi-selection so she can Lock back to the same parent cleanly
  if(parents.length){
    multi.clear();
    parents.forEach(d=>{
      generatedSlips(d).forEach(s=>multi.add("slip:"+String(s.id)));
    });
    selectedDock=parents.length===1?parents[0].id:null;
    selected=null; selectedMark=null;
  }
  multiPick=true;
  moveWholeChart=false;
  setMultiPick(true);
  const names=parents.map(d=>d.name||d.id).join(", ")||"selection";
  const h=document.getElementById("hint");
  if(h) h.textContent="Ungrouped / unlocked "+names+" only · add/remove slips, then Lock as dock to return to the same parent";
  saveLayout(); redraw(); renderDockEditor(); updateSelHint(); updateSelChip();
  return true;
}
function removeSlipFromDock(d, slipId){
  const sid=String(slipId);
  d.a=(d.a||[]).filter(n=>String(n)!==sid);
  d.b=(d.b||[]).filter(n=>String(n)!==sid);
  d.extras=(d.extras||[]).filter(ex=>String(ex.num)!==sid);
  if(d.placed) delete d.placed[sid];
}
function lockSelectionAsDock(){
  const keys=selectionKeys();
  const slipKeys=keys.filter(k=>k.startsWith("slip:"));
  const dockKeys=keys.filter(k=>k.startsWith("dock:"));
  const parents=parentDocksFromKeys(keys);
  if(!parents.length && !dockKeys.length){
    alert("Select a dock, or Multi-select slips that belong to a dock, then Lock as dock.");
    return false;
  }
  // If slips come from more than one parent dock, re-parent them into one new locked dock
  const uniqueParents=new Set(parents.map(d=>d.id));
  if(slipKeys.length>=2 && uniqueParents.size>1){
    return joinSelectionAsNewDock(true);
  }
  // Same parent (or dock selected): relock ORIGINAL parent dock(s), keep placed positions
  parents.forEach(d=>{ d.locked=true; bakeDockPlaced(d); });
  // Replace any prior Locked selection group with a clean dock-keyed group
  groups=groups.filter(g=>g.name!=="Locked selection");
  if(parents.length===1){
    const d=parents[0];
    // Prefer dock member so Unlock this dock / Lock round-trips cleanly
    groups.push({id:uid("grp"),name:"Locked selection",members:["dock:"+d.id]});
    multi.clear();
    multi.add("dock:"+d.id);
    selectedDock=d.id; selected=null; selectedMark=null;
  }else if(keys.length>=2){
    groups.push({id:uid("grp"),name:"Locked selection",members:[...keys]});
  }
  multiPick=false;
  moveWholeChart=true;
  const h=document.getElementById("hint");
  const pname=parents.length===1?(parents[0].name||parents[0].id):"dock";
  if(h) h.textContent="Locked back to "+pname+" · drag moves the whole unit · Ungroup / Unlock this dock to adjust again";
  saveLayout(); redraw(); renderDockEditor(); updateSelHint(); updateSelChip();
  return true;
}
function joinSelectionAsNewDock(quiet){
  const keys=selectionKeys();
  const slipIds=keys.filter(k=>k.startsWith("slip:")).map(k=>k.slice(5));
  if(slipIds.length<1 && keys.some(k=>k.startsWith("dock:"))){
    // Lock docks only
    parentDocksFromKeys(keys).forEach(d=>{ d.locked=true; });
    multiPick=false; moveWholeChart=true;
    saveLayout(); redraw(); renderDockEditor(); updateSelHint();
    return true;
  }
  if(slipIds.length<2){
    if(!quiet) alert("Multi-select at least two slips first, then Lock as dock / Join.");
    return false;
  }
  const pieces=[];
  slipIds.forEach(id=>{
    const info=slipWorldPos(id);
    if(info) pieces.push({id:String(id), dock:info.dock, slip:info.slip});
  });
  if(pieces.length<2){ alert("Could not resolve those slips on the chart."); return false; }
  const minX=Math.min(...pieces.map(p=>Number(p.slip.x)||0));
  const minY=Math.min(...pieces.map(p=>Number(p.slip.y)||0));
  const avgW=pieces.reduce((a,p)=>a+(Number(p.slip.w)||40),0)/pieces.length;
  const avgH=pieces.reduce((a,p)=>a+(Number(p.slip.h)||16),0)/pieces.length;
  const name=quiet?("Joined "+pieces.length+" slips"): (prompt("Name for the new dock?","Joined slips")||"Joined slips");
  if(name==null) return false;
  const newDock={
    id:uid("dock"), name:String(name).trim()||"Joined slips", type:"col",
    x:minX, y:minY, kind:(pieces[0].slip.kind||pieces[0].dock.kind||"std"),
    size:"Custom", locked:true, gap:Math.max(2, Math.round(avgH+2)),
    w:Math.round(avgW), h:Math.round(avgH), sw:Math.round(avgW), sh:Math.round(avgH),
    a:[], b:[], extras:[], placed:{}, fill:pieces[0].dock.fill
  };
  pieces.forEach(p=>{
    removeSlipFromDock(p.dock, p.id);
    const num=/^\d+$/.test(p.id)?Number(p.id):p.id;
    newDock.extras.push({
      num, dx:(Number(p.slip.x)||0)-minX, dy:(Number(p.slip.y)||0)-minY,
      w:Number(p.slip.w)||avgW, h:Number(p.slip.h)||avgH,
      kind:p.slip.kind, size:p.slip.size, filter:p.slip.filter
    });
    if(p.slip.fill){
      newDock.placed[String(num)]={x:Number(p.slip.x)||minX, y:Number(p.slip.y)||minY, w:Number(p.slip.w)||avgW, h:Number(p.slip.h)||avgH, rot:p.slip.rot||0, fill:p.slip.fill};
    }
  });
  // Drop empty docks left behind (no slips)
  docks=docks.filter(d=>{
    if(d.id===newDock.id) return true;
    const left=generatedSlips(d);
    return left.length>0 || (d.a&&d.a.length) || (d.b&&d.b.length) || (d.extras&&d.extras.length);
  });
  docks.push(newDock);
  ensureStackOrder();
  stackMove(["dock:"+newDock.id],"front");
  groups=groups.filter(g=>!(g.members||[]).some(k=>slipIds.some(id=>k==="slip:"+id)));
  groups.push({id:uid("grp"),name:newDock.name,members:["dock:"+newDock.id]});
  multi.clear(); multi.add("dock:"+newDock.id);
  selectedDock=newDock.id; selected=null; selectedMark=null;
  multiPick=false; moveWholeChart=true;
  const h=document.getElementById("hint");
  if(h) h.textContent="Joined as dock “"+newDock.name+"” · locked · drag moves the whole unit";
  saveLayout(); redraw(); renderDockEditor(); updateSelHint(); updateSelChip();
  return true;
}
function scaleSelectionByFactor(f){
  f=Number(f)||1; if(Math.abs(f-1)<1e-9) return false;
  const keys=selectionKeys();
  if(!keys.length){ alert("Select or Multi-select pieces first."); return false; }
  const box=keysBBox(keys)||{x:0,y:0,w:MAP_W,h:MAP_H};
  const cx=box.x+box.w/2, cy=box.y+box.h/2;
  // Ensure slip keys have placed coords before scaling (works even if dock still locked)
  keys.forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind!=="slip") return;
    const info=slipWorldPos(id); if(!info) return;
    const s=info.slip, d=info.dock;
    if(!(d.placed&&d.placed[String(id)])){
      setPlaced(d, String(id), {x:s.x,y:s.y,w:s.w,h:s.h,rot:s.rot||0,fill:s.fill});
    }
  });
  scaleMembersByKeys(keys, f, cx, cy);
  sanitizeLayout(); saveLayout(); redraw(); renderDockEditor(); updateSelHint();
  try{ syncMultiGeomInputs(); }catch(e){}
  return true;
}
function resizeSelectionSlips(dw, dh){
  dw=Number(dw)||0; dh=Number(dh)||0;
  if(!dw && !dh) return false;
  const keys=selectionKeys();
  let n=0;
  keys.forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind==="slip"){
      const info=slipWorldPos(id); if(!info) return;
      const s=info.slip;
      setPlaced(info.dock, String(id), {
        x:s.x, y:s.y,
        w:Math.max(6, (Number(s.w)||10)+dw),
        h:Math.max(6, (Number(s.h)||10)+dh),
        rot:s.rot||0, fill:s.fill
      });
      n++;
    }else if(kind==="dock"){
      const d=docks.find(x=>x.id===id); if(!d) return;
      if(d.type==="col"){ d.w=Math.max(6,(Number(d.w)||40)+dw); d.h=Math.max(6,(Number(d.h)||16)+dh); }
      else { d.sw=Math.max(6,(Number(d.sw)||d.w||40)+dw); d.sh=Math.max(6,(Number(d.sh)||d.h||16)+dh); }
      n++;
    }
  });
  if(!n){ alert("Selection has no slips/docks to resize."); return false; }
  sanitizeLayout(); saveLayout(); redraw(); renderDockEditor();
  return true;
}
function selectionGeomSummary(){
  const keys=selectionKeys();
  const box=keysBBox(keys);
  let swSum=0, shSum=0, n=0;
  (keys||[]).forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind==="slip"){
      const info=slipWorldPos(id); if(!info||!info.slip) return;
      swSum+=Number(info.slip.w)||10; shSum+=Number(info.slip.h)||10; n++;
    }else if(kind==="dock"){
      const d=docks.find(x=>x.id===id); if(!d) return;
      swSum+=Number(d.sw!=null?d.sw:(d.w||40))||40;
      shSum+=Number(d.sh!=null?d.sh:(d.h||16))||16; n++;
    }else if(kind==="mark"){
      const m=marks.find(x=>x.id===id); if(!m||m.kind==="text") return;
      if(m.w!=null||m.h!=null){ swSum+=Number(m.w)||12; shSum+=Number(m.h)||20; n++; }
    }
  });
  return {
    keys, box,
    x: box?Math.round(box.x):0,
    y: box?Math.round(box.y):0,
    gw: box?Math.round(box.w):0,
    gh: box?Math.round(box.h):0,
    sw: n?Math.round(swSum/n):40,
    sh: n?Math.round(shSum/n):16,
    n
  };
}
function syncMultiGeomInputs(){
  if(multi.size<1 && !selectionKeys().length) return;
  const g=selectionGeomSummary();
  const fill=(id,val)=>{
    const el=document.getElementById(id); if(!el) return;
    if(document.activeElement===el) return;
    el.value=String(val);
  };
  fill("multi-x", g.x); fill("multi-y", g.y);
  fill("multi-sw", g.sw); fill("multi-sh", g.sh);
  fill("ed-sel-x", g.x); fill("ed-sel-y", g.y);
  fill("ed-sel-sw", g.sw); fill("ed-sel-sh", g.sh);
  const boxLab=document.getElementById("multi-geom-label");
  if(boxLab) boxLab.textContent = multi.size>1 ? ("Group · "+multi.size) : "Selection";
}
function moveSelectionToXY(nx, ny){
  const keys=selectionKeys();
  if(!keys.length){ alert("Select or Multi-select pieces first."); return false; }
  const box=keysBBox(keys); if(!box) return false;
  const rawDx=(Number(nx)||0)-box.x, rawDy=(Number(ny)||0)-box.y;
  const c=clampDeltaForBox(box, rawDx, rawDy);
  moveMembersByKeys(keys, c.dx, c.dy);
  sanitizeLayout(); saveLayout(); redraw(); renderDockEditor(); updateSelHint();
  return true;
}
function setSelectionPieceSize(nw, nh){
  nw=Math.max(6, Number(nw)||0); nh=Math.max(6, Number(nh)||0);
  if(!nw || !nh){ alert("Enter Width and Height (min 6)."); return false; }
  const keys=selectionKeys();
  let n=0;
  keys.forEach(k=>{
    const {kind,id}=parseMemberKey(k);
    if(kind==="slip"){
      const info=slipWorldPos(id); if(!info) return;
      const s=info.slip;
      // Always write placed so group sizing works whether the parent dock is locked or not
      setPlaced(info.dock, String(id), {
        x:s.x, y:s.y, w:nw, h:nh, rot:s.rot||0, fill:s.fill
      });
      n++;
    }else if(kind==="dock"){
      const d=docks.find(x=>x.id===id); if(!d) return;
      if(d.type==="col"){ d.w=nw; d.h=nh; }
      else { d.sw=nw; d.sh=nh; }
      if(d.placed){
        Object.keys(d.placed).forEach(pid=>{
          const p=d.placed[pid]; if(!p) return;
          p.w=nw; p.h=nh;
        });
      }
      n++;
    }else if(kind==="mark"){
      const m=marks.find(x=>x.id===id); if(!m || m.kind==="text") return;
      m.w=nw; m.h=nh; n++;
    }
  });
  if(!n){ alert("Selection has no slips/docks to size."); return false; }
  sanitizeLayout(); saveLayout(); redraw(); renderDockEditor(); updateSelHint();
  try{ syncMultiGeomInputs(); }catch(e){}
  return true;
}
function wireGeomFields(ids){
  const applyPos=()=>{
    const xEl=document.getElementById(ids.x), yEl=document.getElementById(ids.y);
    if(!xEl||!yEl) return;
    moveSelectionToXY(+xEl.value, +yEl.value);
  };
  const applySize=()=>{
    const wEl=document.getElementById(ids.w), hEl=document.getElementById(ids.h);
    if(!wEl||!hEl) return;
    setSelectionPieceSize(+wEl.value, +hEl.value);
  };
  const bind=(id,fn)=>{
    const el=document.getElementById(id); if(!el) return;
    el.onchange=fn;
    el.onkeydown=ev=>{ if(ev.key==="Enter"){ ev.preventDefault(); fn(); el.blur(); } };
  };
  bind(ids.x, applyPos); bind(ids.y, applyPos);
  bind(ids.w, applySize); bind(ids.h, applySize);
}


function selectionOwnsTap(tapKey, tapDock){
  if(!tapKey) return false;
  if(multi.has(tapKey)) return true;
  // Slip on a selected dock counts as part of the group (Lock as dock stores dock:id)
  if(tapKey.startsWith("slip:") && tapDock && multi.has("dock:"+tapDock)) return true;
  // Dock hit while slips from that dock are selected
  if(tapKey.startsWith("dock:")){
    const did=tapKey.slice(5);
    for(const k of multi){
      if(!k.startsWith("slip:")) continue;
      const d=findDockForSlipId(k.slice(5));
      if(d && d.id===did) return true;
    }
  }
  return false;
}
function keysForDrag(kind,id){
  const key=kind+":"+id;
  if(multi.has(key) && multi.size>1) return [...multi];
  const g=findGroupFor(kind,id);
  if(g && (g.members||[]).length>1) return [...(g.members||[])];
  if(moveWholeChart) return allLayoutKeys();
  return null;
}

function toggleMultiKey(k){
  if(multi.has(k)) multi.delete(k); else multi.add(k);
  if(multi.size<=1) moveWholeChart=false;
  updateSelHint();
  redraw();
}
function selectAllLayout(){
  multi.clear();
  allLayoutKeys().forEach(k=>multi.add(k));
  moveWholeChart=true;
  updateSelHint(); redraw();
}
function groupAllLayout(){
  selectAllLayout();
  groups=groups.filter(g=>g.name!=="Entire map");
  groups.push({id:uid("grp"),name:"Entire map",members:[...multi]});
  moveWholeChart=true;
  updateSelHint(); saveLayout(false); lastSnap=snap(); redraw();
}

function buildSlips(){
  slips=[];
  docks.forEach(d=>{
    generatedSlips(d).forEach(s=>{
      const p=applyPlaced(d,s);
      slips.push({id:p.id,num:p.num,dock:d.name,dockId:d.id,kind:p.kind||d.kind,size:p.size||d.size,x:p.x,y:p.y,w:p.w,h:p.h,rot:p.rot||0,filter:p.filter||d.name,fill:p.fill||d.fill});
    });
  });
}
const layerBg=el("g",{id:"bg"}), layerStack=el("g",{id:"stack"}), layerSite=el("g",{id:"lod-site"}), layerWalkMarks=el("g",{id:"lod-walkmarks"}), layerMarks=el("g",{id:"marks"}), layerDocks=el("g",{id:"docks"}), layerSlips=el("g",{id:"slips"}), layerLabels=el("g",{id:"lod-labels"});
svg.appendChild(el("rect",{width:MAP_W,height:MAP_H,fill:"#0c3c41"}));
const bgImg=el("image",{href:"dock-map.jpg?v=89",x:0,y:0,width:MAP_W,height:MAP_H,opacity:0.9,preserveAspectRatio:"none"});
layerBg.appendChild(bgImg);
svg.setAttribute("overflow","hidden"); // clip to chart viewBox — aerial fills workspace via none
loadPhotoAlign();
applyPhotoAlign();
// layerStack paints docks+marks in stackOrder (cross-type z-order). Empty LOD groups kept for nudge/compat.
svg.appendChild(layerBg);svg.appendChild(layerStack);svg.appendChild(layerSite);svg.appendChild(layerWalkMarks);svg.appendChild(layerDocks);svg.appendChild(layerSlips);svg.appendChild(layerLabels);svg.appendChild(layerMarks);
syncMapBoundVisual();
function layerOptionFor(slipId, layerId){
  const rec=data[slipId];
  if(!rec||!rec.layerOpts) return null;
  return rec.layerOpts[layerId]||null;
}
function fill(s){
  if(activeLayerId){
    const layer=layers.find(l=>l.id===activeLayerId);
    const optId=layerOptionFor(s.id, activeLayerId);
    const opt=layer && (layer.options||[]).find(o=>o.id===optId);
    if(opt&&opt.color) return opt.color;
    return "#5a6866"; // unassigned under active layer
  }
  const rec=data[s.id];
  if(rec&&rec.status==="occupied")return "#b55a32";
  if(rec&&rec.status==="reserved")return "#d7b45a";
  if(s.fill)return s.fill;
  const dock=docks.find(x=>x.id===s.dockId);
  if(dock&&dock.fill)return dock.fill;
  return COLORS[s.kind]||"#e4dcc8";
}
function match(s,f){
  if(slipHiddenByLayer(s)) return false;
  if(activeLayerId){
    if(!layerOptFilter||layerOptFilter==="All") return true;
    if(layerOptFilter==="__none__") return !layerOptionFor(s.id, activeLayerId);
    return layerOptionFor(s.id, activeLayerId)===layerOptFilter;
  }
  if(!f||f==="All") return true;
  return s.filter===f || s.dock===f;
}
function activeLayer(){ return layers.find(l=>l.id===activeLayerId)||null; }
function slipHiddenByLayer(s){
  const layer=activeLayer();
  if(!layer) return false;
  if(layer.hidden) return true; // whole layer hidden → hide all slips while this layer is the active view
  const optId=layerOptionFor(s.id, layer.id);
  if(!optId) return !!layer.hideUnassigned;
  const opt=(layer.options||[]).find(o=>o.id===optId);
  return !!(opt && opt.hidden);
}
function buildMarkGroup(m){
  const rot=Number(m.rot)||0;
  const attrs={"data-mark":m.id,"data-lod":markLodBucket(m),class:"dock-hit"+(selectedMark===m.id?" on":"")+(multi.has("mark:"+m.id)?" multi":"")};
  if(rot) attrs.transform=`rotate(${rot} ${m.x} ${m.y})`;
  const g=el("g",attrs);
  if(m.kind==="box"){g.appendChild(el("rect",{class:"walk",x:m.x,y:m.y,width:m.w,height:m.h,rx:8,fill:m.fill||"#2b6d8a"}));g.appendChild(el("text",{x:m.x+m.w/2,y:m.y+m.h/2-6,"text-anchor":"middle",fill:m.ink||"#243018","font-size":13,"font-weight":700},m.t1||""));if(m.t2)g.appendChild(el("text",{x:m.x+m.w/2,y:m.y+m.h/2+12,"text-anchor":"middle",fill:m.ink||"#243018","font-size":11},m.t2));}
  else if(m.kind==="p"){const rx=m.w?m.w/2:70,ry=m.h?m.h/2:26;g.appendChild(el("ellipse",{class:"walk",cx:m.x,cy:m.y,rx,ry,fill:"none",stroke:"#9ad","stroke-width":3}));g.appendChild(el("text",{x:m.x,y:m.y+6,"text-anchor":"middle",fill:"#8ec4ea","font-size":18,"font-weight":800},"P"));}
  else if(m.kind==="bridge"){g.appendChild(el("rect",{class:"walk",x:m.x,y:m.y,width:m.w,height:m.h,fill:"#8a8a84"}));g.appendChild(el("text",{x:m.x+m.w/2,y:m.y+16,"text-anchor":"middle",fill:"#222","font-size":12},"Hwy 92 Bridge"));}
  else if(m.kind==="bar"){g.appendChild(el("rect",{x:m.x,y:m.y,width:m.w||12,height:m.h||20,rx:3,fill:"#bfb9ac",class:"walk"}));}
  else if(m.kind==="pill"){
    g.appendChild(el("rect",{x:m.x,y:m.y,width:m.w,height:m.h,rx:4,fill:m.fill||"#2b6d8a",class:"walk"}));
    const pfs=screenAwareFontSize(10), psw=labelStrokeWidth(pfs);
    g.appendChild(el("text",{x:m.x+m.w/2,y:m.y+m.h/2+4,"text-anchor":"middle",fill:"#0a1210",stroke:"#f4fffe","stroke-width":String(psw),"paint-order":"stroke","font-size":String(pfs),"font-weight":800,class:"screen-label","data-world-fs":"10"},m.label||""));
  }
  else if(m.kind==="text"){
    const baseFs=Math.max(8, Math.min(72, Number(m.size)||13)); const fs=screenAwareFontSize(baseFs); const sw=labelStrokeWidth(fs);
    const ink=m.ink||"#0a1210";
    const tw=Math.max(28,(m.text||"").length*fs*0.62), th=fs+8, bx=m.x-4, by=m.y-fs;
    if(m.bg){
      const bgFill=m.bgFill||"#0c1c1a";
      g.appendChild(el("rect",{class:"walk label-bg",x:bx,y:by,width:tw,height:th,rx:5,fill:bgFill,"fill-opacity":"0.72"}));
    }else{
      g.appendChild(el("rect",{class:"walk",x:bx,y:by,width:tw,height:th,fill:editing?"rgba(255,255,255,.12)":"none",stroke:editing?"rgba(255,255,255,.35)":"none","stroke-width":editing?1:0}));
    }
    g.appendChild(el("text",{x:m.x,y:m.y,fill:ink,stroke:"#f4fffe","stroke-width":String(sw),"paint-order":"stroke","font-size":String(fs),"font-weight":800,class:"screen-label","data-world-fs":String(baseFs)},m.text||""));
  }
  return g;
}
function drawMarks(){ /* marks drawn in redraw via stackOrder */ }
function appendWalk(g,d){
  const geom=walkGeomFromDock(d);
  g.appendChild(el("rect",{class:"walk",x:geom.x,y:geom.y,width:geom.w,height:geom.h,rx:3,fill:"#bfb9ac"}));
  g.appendChild(el("text",dockNameLabelAttrs(d.x,d.y-12,14),d.name));
}
function redraw(){
  buildSlips();
  ensureStackOrder();
  layerStack.innerHTML="";
  layerSite.innerHTML=""; layerWalkMarks.innerHTML=""; layerLabels.innerHTML=""; layerMarks.innerHTML="";
  layerDocks.innerHTML=""; layerSlips.innerHTML="";
  const byDock={};
  const pieceG={};
  docks.forEach(d=>{
    const rot=Number(d.rot)||0;
    const attrs={"data-dock":d.id,"data-lod":"walk",class:"dock-hit"+(selectedDock===d.id?" on":"")+(multi.has("dock:"+d.id)?" multi":"")};
    if(rot) attrs.transform=`rotate(${rot} ${d.x} ${d.y})`;
    const g=el("g",attrs); appendWalk(g,d); byDock[d.id]=g; pieceG["dock:"+d.id]=g;
  });
  marks.forEach(m=>{ pieceG["mark:"+m.id]=buildMarkGroup(m); });
  slips.forEach(s=>{
    const parent=byDock[s.dockId]||layerSlips;
    const rot=Number(s.rot)||0;
    const hidden=slipHiddenByLayer(s);
    const dim=!hidden && !match(s,filter);
    const attrs={class:"slip"+(selected===s.id?" on":"")+(multi.has("slip:"+s.id)?" multi":"")+(dim?" dim":"")+(hidden?" layer-hidden":""),"data-id":s.id,"data-dock":s.dockId};
    if(rot) attrs.transform=`rotate(${rot} ${s.x+s.w/2} ${s.y+s.h/2})`;
    const g=el("g",attrs);
    g.appendChild(el("rect",{x:s.x,y:s.y,width:s.w,height:s.h,rx:2,fill:fill(s)}));
    const label=el("text",slipLabelAttrs(s.x+s.w/2,s.y+s.h/2,9),String(s.num).replace(/^F|^C/,""));
    if(s.h>s.w+6){ label.setAttribute("transform",`rotate(90 ${s.x+s.w/2} ${s.y+s.h/2})`); label.setAttribute("dominant-baseline","middle"); }
    g.appendChild(label);
    parent.appendChild(g);
  });
  // Paint order = stackOrder (back → front). Orphan slips (no dock) stay in top-level layerSlips.
  stackOrder.forEach(k=>{ const g=pieceG[k]; if(g) layerStack.appendChild(g); });
  document.getElementById("count").textContent=slips.filter(s=>/^\d+$/.test(String(s.num))).length+" numbered slips";
  if(mapBoundRect && mapBoundRect.parentNode===svg) svg.appendChild(mapBoundRect);
  syncMapBoundVisual();
  applyDeepZoomLod();
  try{ redrawGcpMarkers(); }catch(e){}
  try{ redrawScaleMarkers(); }catch(e){}
}
const DOCK_CHIPS=["All","5","4","3","2","1","7","8","9","10","11","12","13","Houseboats","Cruiser","Fuel","Sales"];
const chipsEl=document.getElementById("chips");
function renderChips(){
  chipsEl.innerHTML="";
  if(activeLayerId){
    const layer=layers.find(l=>l.id===activeLayerId);
    if(layer && layer.hidden){
      const note=document.createElement("button");
      note.className="chip"; note.textContent="Layer hidden — click to show";
      note.onclick=()=>{ layer.hidden=false; saveLayersStore(); saveLayout(false); renderChips(); renderLayersEditor(); redraw(); };
      chipsEl.appendChild(note);
    }
    const opts=[{id:"All",name:"All",color:null},{id:"__none__",name:"Unassigned",color:null,isNone:true}].concat((layer&&layer.options)||[]);
    opts.forEach(o=>{
      const wrap=document.createElement("span");
      wrap.style.display="inline-flex"; wrap.style.gap="2px"; wrap.style.alignItems="center";
      const b=document.createElement("button");
      const isHidden = o.id==="__none__" ? !!(layer&&layer.hideUnassigned) : !!(o.hidden);
      b.className="chip"+(layerOptFilter===o.id?" on":"")+" layer-on"+(isHidden?" hidden-opt":"");
      b.textContent=o.name||o.id;
      if(o.color){ b.style.boxShadow="inset 0 -3px 0 "+o.color; }
      b.onclick=()=>{ layerOptFilter=o.id; renderChips(); redraw(); };
      wrap.appendChild(b);
      if(o.id!=="All"){
        const eye=document.createElement("button");
        eye.className="chip eye"+(isHidden?" off":"");
        eye.title=isHidden?"Show":"Hide";
        eye.textContent=isHidden?"🙈":"👁";
        eye.onclick=e=>{
          e.stopPropagation();
          if(o.id==="__none__"){ layer.hideUnassigned=!layer.hideUnassigned; }
          else { o.hidden=!o.hidden; }
          saveLayersStore(); saveLayout(false); renderChips(); renderLayersEditor(); redraw();
        };
        wrap.appendChild(eye);
      }
      chipsEl.appendChild(wrap);
    });
    const clear=document.createElement("button");
    clear.className="chip"; clear.textContent="Exit layer colors";
    clear.onclick=()=>{ activeLayerId=null; layerOptFilter="All"; renderChips(); renderLayersEditor(); redraw(); };
    chipsEl.appendChild(clear);
  }else{
    DOCK_CHIPS.forEach(c=>{
      const b=document.createElement("button");
      b.className="chip"+(filter===c?" on":"");
      b.textContent=c;
      b.onclick=()=>{ filter=c; renderChips(); redraw(); };
      chipsEl.appendChild(b);
    });
  }
}
renderChips();
redraw();
function svgPoint(e){
  // Prefer manual convert via known CSS zoom (tx/ty/scale). getScreenCTM() is unreliable
  // on some mobile browsers when the SVG root uses CSS transform.
  try{
    const r = chart.getBoundingClientRect();
    const cx = (e.clientX!=null?e.clientX:(e.touches&&e.touches[0]?e.touches[0].clientX:0));
    const cy = (e.clientY!=null?e.clientY:(e.touches&&e.touches[0]?e.touches[0].clientY:0));
    const sc = Math.max(1e-6, Number(scale)||1);
    return { x:(cx - r.left - tx)/sc, y:(cy - r.top - ty)/sc };
  }catch(_){}
  try{
    const pt=svg.createSVGPoint(); pt.x=e.clientX; pt.y=e.clientY;
    const ctm=svg.getScreenCTM();
    return ctm?pt.matrixTransform(ctm.inverse()):{x:0,y:0};
  }catch(_){ return {x:0,y:0}; }
}
function showTab(name){document.querySelectorAll(".tabs button").forEach(b=>b.classList.toggle("on",b.dataset.tab===name));document.getElementById("pane-slip").hidden=name!=="slip";document.getElementById("pane-dir").hidden=name!=="dir";const pl=document.getElementById("pane-layers"); if(pl) pl.hidden=name!=="layers";document.getElementById("pane-layout").hidden=name!=="layout"; if(name==="layers") renderLayersEditor();}
function nudgeCtrlHtml(){return `<div class="st ed-nudge"><button type="button" data-nudge="-10,0">←</button><button type="button" data-nudge="10,0">→</button><button type="button" data-nudge="0,-10">↑</button><button type="button" data-nudge="0,10">↓</button></div>`;}
function rotCtrl(val){return `<label>Rotation (degrees)<input id="ed-rot" type="range" min="-180" max="180" step="1" value="${val}"/></label><div class="row2"><label>Angle<input id="ed-rot-num" type="number" step="1" value="${val}"/></label><div class="st"><button type="button" data-rot="-90">-90</button><button type="button" data-rot="-15">-15</button><button type="button" data-rot="15">+15</button><button type="button" data-rot="90">+90</button><button type="button" data-rot="0">0</button></div></div>`;}
function placementSec(inner){return `<div class="ed-sec"><div class="ed-sec-title">Placement &amp; transform</div>${inner}</div>`;}
function bindRot(obj,after){const apply=v=>{obj.rot=((Number(v)%360)+360)%360;if(obj.rot>180)obj.rot-=360;if(Math.abs(obj.rot)<0.01)obj.rot=0;saveLayout();redraw();if(after)after();};document.getElementById("ed-rot").oninput=e=>{document.getElementById("ed-rot-num").value=e.target.value;obj.rot=+e.target.value;saveLayout();redraw();};document.getElementById("ed-rot").onchange=e=>apply(e.target.value);document.getElementById("ed-rot-num").onchange=e=>apply(e.target.value);document.querySelectorAll("[data-rot]").forEach(btn=>btn.onclick=()=>{const s=+btn.dataset.rot;apply(s===0?0:(Number(obj.rot)||0)+s);});}
function nextSlipNumber(){
  const used=new Set(slips.map(s=>s.id));
  let n=900;
  while(used.has(String(n))) n++;
  return n;
}
function resizeSide(arr,count,startHint){
  arr=arr?arr.slice():[];
  count=Math.max(0,Math.min(80,+count||0));
  if(arr.length>count) return arr.slice(0,count);
  let n=startHint!=null?startHint:nextSlipNumber();
  const used=new Set(slips.map(s=>String(s.num)).concat(arr.map(String)));
  while(arr.length<count){ while(used.has(String(n))) n++; arr.push(/^[A-Z]/.test(String(startHint))?String(startHint):n); used.add(String(n)); n++; }
  return arr;
}
function renderMultiSelectionEditor(box){
    const parents=parentDocksFromKeys([...multi]);
    const anyLocked=parents.some(d=>isLocked(d));
    const anyUnlocked=parents.some(d=>!isLocked(d));
    const geom=selectionGeomSummary();
    box.innerHTML=`<h2>${multi.size} selected</h2>
      <p class="hint">Type Group X/Y to move the set (top-left). Type Slip width/height to set every selected slip/dock size. Or drag / Scale±. Lock as dock when finished.</p>
      <div class="st">
        <button type="button" class="btn" id="ed-sel-unlock" title="Unlock only the dock(s) for this selection">Unlock this dock</button>
        <button type="button" class="btn" id="ed-sel-lock">Lock as dock</button>
      </div>
      <div class="st">
        <button type="button" class="btn" id="ed-sel-ungroup" title="Ungroup and unlock only this dock — slips stay on the original parent">Ungroup / Unlock this dock</button>
      </div>
      <div class="st">
        <button type="button" class="btn" id="ed-sel-group">Group / Join</button>
        <button type="button" class="btn" id="ed-sel-join-new">Join as new dock</button>
      </div>
      ${dockAssignSectionHtml("Set all selected slips", slipIdsForKeys([...multi]).length, false)}
      ${placementSec(`
        <p class="hint" style="margin-top:0">Group position (selection top-left) &amp; slip size</p>
        <div class="row2"><label>Group X<input id="ed-sel-x" type="number" value="${geom.x}"/></label><label>Group Y<input id="ed-sel-y" type="number" value="${geom.y}"/></label></div>
        <div class="row2"><label>Slip width<input id="ed-sel-sw" type="number" min="6" value="${geom.sw}"/></label><label>Slip height<input id="ed-sel-sh" type="number" min="6" value="${geom.sh}"/></label></div>
        <p class="hint">Group size on map: ${geom.gw}×${geom.gh} · Scale −/+ resizes the whole arrangement together</p>
        <div class="st">
          <button type="button" class="btn" id="ed-sel-scale-down" title="Scale 90%">Scale −</button>
          <button type="button" class="btn" id="ed-sel-scale-up" title="Scale 110%">Scale +</button>
        </div>
        <div class="st">
          <button type="button" class="btn" data-sel-resize="-4,0">W −</button>
          <button type="button" class="btn" data-sel-resize="4,0">W +</button>
          <button type="button" class="btn" data-sel-resize="0,-4">H −</button>
          <button type="button" class="btn" data-sel-resize="0,4">H +</button>
        </div>
        ${nudgeCtrlHtml()}
      `)}
      ${stackCtrlHtml()}`;
    bindStackButtons();
    const u=document.getElementById("ed-sel-unlock");
    if(u){ u.disabled=!parents.length; u.onclick=()=>unlockSelectionSlips(); }
    const ug=document.getElementById("ed-sel-ungroup");
    if(ug){ ug.onclick=()=>ungroupUnlockThisDock(); }
    const l=document.getElementById("ed-sel-lock");
    if(l){ l.onclick=()=>lockSelectionAsDock(); }
    const g=document.getElementById("ed-sel-group");
    if(g) g.onclick=()=>{
      if(multi.size<2) return;
      const name=prompt("Group name?","Group "+(groups.length+1));
      if(name==null) return;
      groups.push({id:uid("grp"),name:String(name).trim()||"Group",members:[...multi]});
      multiPick=false; moveWholeChart=true;
      const h=document.getElementById("hint");
      if(h) h.textContent="Grouped · drag selected to move all "+multi.size+" · tap to add/remove · Scale −/+ · Lock as dock when done";
      saveLayout(); redraw(); updateSelHint(); updateSelChip(); renderDockEditor();
    };
    const j=document.getElementById("ed-sel-join-new");
    if(j) j.onclick=()=>joinSelectionAsNewDock(false);
    const sd=document.getElementById("ed-sel-scale-down");
    if(sd) sd.onclick=()=>scaleSelectionByFactor(0.9);
    const su=document.getElementById("ed-sel-scale-up");
    if(su) su.onclick=()=>scaleSelectionByFactor(1.1);
    box.querySelectorAll("[data-sel-resize]").forEach(btn=>{
      btn.onclick=()=>{ const [dw,dh]=btn.getAttribute("data-sel-resize").split(",").map(Number); resizeSelectionSlips(dw,dh); };
    });
    box.querySelectorAll("[data-nudge]").forEach(btn=>{
      btn.onclick=()=>{
        const [dx,dy]=btn.dataset.nudge.split(",").map(Number);
        const keys=[...multi];
        const c=clampDeltaForBox(keysBBox(keys), dx, dy);
        moveMembersByKeys(keys, c.dx, c.dy);
        saveLayout(); redraw(); renderDockEditor();
      };
    });
    bindDockAssign(box, ()=>slipIdsForKeys([...multi]), "the selection", ()=>{ if(selected) renderSlipLayerAssigns(selected); });
    wireGeomFields({x:"ed-sel-x",y:"ed-sel-y",w:"ed-sel-sw",h:"ed-sel-sh"});
    try{ syncMultiGeomInputs(); }catch(e){}
}
function renderDockEditor(){
 try{
  const box=document.getElementById("dock-editor");
  const d=docks.find(x=>x.id===selectedDock);
  const m=marks.find(x=>x.id===selectedMark);
  const s=slips.find(x=>x.id===selected);
  // Multi-selection UI takes priority so Scale −/+ and Group X/Y/Slip W/H stay available
  if(editing && multi.size>1){
    renderMultiSelectionEditor(box);
    return;
  }
  if(s && editing && selectedDock && d && !isLocked(d)){
    const placed=(d.placed&&d.placed[s.id])||{};
    box.innerHTML=`<h2>Slip ${s.num}</h2><p class="hint">Unlocked · drag this slip · Multi-select several, then Lock as dock when done</p>
      <div class="st"><button type="button" class="btn" id="ed-lock-as-dock">Lock as dock</button><button type="button" class="btn" id="ed-unlock-slips" disabled>Unlock slips</button></div>
      <label>Number / label<input id="ed-num" value="${s.num}"/></label>`+
      placementSec(`<div class="row2"><label>X<input id="ed-x" type="number" value="${Math.round(s.x)}"/></label><label>Y<input id="ed-y" type="number" value="${Math.round(s.y)}"/></label></div><div class="row2"><label>Width<input id="ed-w" type="number" value="${Math.round(s.w)}"/></label><label>Height<input id="ed-h" type="number" value="${Math.round(s.h)}"/></label></div>${rotCtrl(Number(s.rot)||0)}${nudgeCtrlHtml()}`)+
      `<label>Color<input id="ed-fill" type="color" value="${placed.fill||d.fill||COLORS[s.kind]||"#e4dcc8"}"/></label><div class="st"><button type="button" id="ed-dup-slip">Duplicate slip</button><button type="button" id="ed-del-slip">Delete this slip</button></div>`;
    const apply=()=>{const nx=+document.getElementById("ed-x").value,ny=+document.getElementById("ed-y").value,nw=+document.getElementById("ed-w").value,nh=+document.getElementById("ed-h").value;const box0={x:nx,y:ny,w:Math.max(1,nw),h:Math.max(1,nh)};const c=clampDeltaForBox(box0,0,0);setPlaced(d,s.id,{x:nx+c.dx,y:ny+c.dy,w:nw,h:nh,fill:document.getElementById("ed-fill").value});saveLayout();redraw();};
    document.getElementById("ed-fill").oninput=()=>{setPlaced(d,s.id,{fill:document.getElementById("ed-fill").value});saveLayout(false);redraw();};
    document.getElementById("ed-fill").onchange=()=>saveLayout();
    document.getElementById("ed-num").onchange=()=>{
      const nn=String(document.getElementById("ed-num").value).trim(); if(!nn) return;
      const rename=arr=>(arr||[]).map(n=>String(n)===String(s.id)?(/^\d+$/.test(nn)?Number(nn):nn):n);
      d.a=rename(d.a); d.b=rename(d.b);
      (d.extras||[]).forEach(ex=>{ if(String(ex.num)===String(s.id)) ex.num=/^\d+$/.test(nn)?Number(nn):nn; });
      if(d.placed && d.placed[s.id]){ d.placed[nn]=d.placed[s.id]; delete d.placed[s.id]; }
      selected=nn; saveLayout(); redraw(); renderDockEditor();
    };
    document.getElementById("ed-dup-slip").onclick=()=>{
      const num=prompt("Duplicate as slip number?", String(nextSlipNumber())); if(num==null||!String(num).trim()) return;
      d.extras=d.extras||[];
      d.extras.push({num:String(num).trim(),dx:(s.x-d.x)+20,dy:(s.y-d.y)+20,w:s.w,h:s.h,kind:s.kind,size:s.size});
      d.locked=false; selected=String(num).trim(); saveLayout(); redraw(); renderDockEditor();
    };
    ["ed-x","ed-y","ed-w","ed-h"].forEach(id=>document.getElementById(id).onchange=apply);
    const rotObj={rot:Number(s.rot)||0};
    bindRot(rotObj,()=>{setPlaced(d,s.id,{rot:rotObj.rot});saveLayout();redraw();renderDockEditor();});
    box.querySelectorAll("[data-nudge]").forEach(btn=>btn.onclick=()=>{const [dx,dy]=btn.dataset.nudge.split(",").map(Number);const box0=slipBBoxFrom(d,s.id,s);const c=clampDeltaForBox(box0,dx,dy);setPlaced(d,s.id,{x:s.x+c.dx,y:s.y+c.dy});saveLayout();redraw();renderDockEditor();});
    document.getElementById("ed-del-slip").onclick=()=>{
      if(!confirm("Delete slip "+s.num+"?")) return;
      d.a=(d.a||[]).filter(n=>String(n)!==s.id);
      d.b=(d.b||[]).filter(n=>String(n)!==s.id);
      d.extras=(d.extras||[]).filter(ex=>String(ex.num)!==s.id);
      if(d.placed) delete d.placed[s.id];
      selected=null;saveLayout();redraw();renderDockEditor();
    };
    const lockBtn=document.getElementById("ed-lock-as-dock");
    if(lockBtn) lockBtn.onclick=()=>{ selectedDock=d.id; if(!multi.size) multi.add("dock:"+d.id); lockSelectionAsDock(); };
    return;
  }
  if(d){
    const locked=isLocked(d);
    const moreOpen=!isMobileEdit()||dockEditorMore;
    box.innerHTML=`<h2>Dock ${d.name}</h2>
      <div class="st"><button type="button" class="btn" id="ed-lock">${locked?"Unlock this dock":"Lock as dock"}</button>
      <button type="button" class="btn" id="ed-multi-here" title="Multi-select slips on this dock">Multi-select slips</button></div>
      <p class="hint">${locked?"Locked as one dock unit. Unlock slips → Multi-select the ones you want → move/resize → Lock as dock when done.":"Unlocked: drag slips one at a time, or Multi-select several to move/resize together, then Lock as dock."}</p>`+
      dockAssignSectionHtml("Set all slips on this dock", dockSlipIdsFor(d.id).length, false)+
      placementSec(`<div class="row2"><label>X<input id="ed-x" type="number" value="${Math.round(d.x)}"/></label><label>Y<input id="ed-y" type="number" value="${Math.round(d.y)}"/></label></div>
      <div class="row2"><label>Slip width<input id="ed-sw" type="number" value="${Math.round(d.sw||d.w||40)}"/></label><label>Slip height<input id="ed-sh" type="number" value="${Math.round(d.sh||d.h||15)}"/></label></div>
      <label>Gap<input id="ed-gap" type="number" value="${Math.round(d.gap||3)}"/></label>
      ${rotCtrl(Number(d.rot)||0)}
      ${nudgeCtrlHtml()}`)+
      (isMobileEdit()?`<button type="button" class="btn ed-more-btn" id="ed-more-toggle">${moreOpen?"Less":"More"}</button>`:"")+
      `<div id="ed-more-block"${moreOpen?"":" hidden"}>
      <label>Dock name<input id="ed-name" value="${d.name||""}"/></label>
      <label>Layout<select id="ed-type"><option value="ns"${d.type==="ns"?" selected":""}>North–south finger</option><option value="ew"${d.type==="ew"?" selected":""}>East–west finger</option><option value="col"${d.type==="col"?" selected":""}>Single column</option></select></label>
      <div class="row2"><label>Side A count<input id="ed-acount" type="number" min="0" max="80" value="${(d.a||[]).length}"/></label><label>Side B count<input id="ed-bcount" type="number" min="0" max="80" value="${(d.b||[]).length}"/></label></div>
      <label>Left / top numbers<textarea id="ed-a" rows="3">${(d.a||[]).join(", ")}</textarea></label>
      <label>Right / bottom numbers<textarea id="ed-b" rows="3">${(d.b||[]).join(", ")}</textarea></label>
      <div class="st"><button type="button" id="ed-add-slip">+ Slip on this dock</button><button type="button" id="ed-reset-slips">Reset slip layout</button></div>
      ${stackCtrlHtml()}
      </div>`;
    const moreBtn=document.getElementById("ed-more-toggle");
    if(moreBtn) moreBtn.onclick=()=>{ dockEditorMore=!dockEditorMore; renderDockEditor(); };
    bindDockAssign(box, ()=>dockSlipIdsFor(d.id), "Dock "+d.name, ()=>{ if(selected) renderSlipLayerAssigns(selected); });
    document.getElementById("ed-lock").onclick=()=>{
      if(locked){
        selectedDock=d.id; unlockSelectionSlips();
      }else{
        selectedDock=d.id; if(!multi.size) multi.add("dock:"+d.id); lockSelectionAsDock();
      }
    };
    const multiHere=document.getElementById("ed-multi-here");
    if(multiHere) multiHere.onclick=()=>{
      if(isLocked(d)) unlockSelectionSlips();
      multi.clear();
      generatedSlips(d).forEach(s=>multi.add("slip:"+String(s.id)));
      setMultiPick(true);
      const h=document.getElementById("hint");
      if(h) h.textContent="Multi-select · untick slips you don’t want, then Done / Group / Lock as dock";
      updateSelHint(); redraw(); renderDockEditor();
    };
    document.getElementById("ed-name").oninput=()=>{d.name=document.getElementById("ed-name").value;saveLayout();redraw();};
    document.getElementById("ed-type").onchange=()=>{d.type=document.getElementById("ed-type").value;d.placed={};saveLayout();redraw();renderDockEditor();};
    const applyPos=()=>{const nx=+document.getElementById("ed-x").value,ny=+document.getElementById("ed-y").value;const rawDx=nx-d.x, rawDy=ny-d.y;const c=clampDeltaForBox(dockBBox(d),rawDx,rawDy);if(isLocked(d)) moveDockSlips(d,c.dx,c.dy);d.x+=c.dx;d.y+=c.dy;saveLayout();redraw();};
    document.getElementById("ed-x").onchange=applyPos;document.getElementById("ed-y").onchange=applyPos;
    const applySize=()=>{
      const sw=+document.getElementById("ed-sw").value,sh=+document.getElementById("ed-sh").value,gap=+document.getElementById("ed-gap").value;
      if(d.type==="col"){d.w=sw;d.h=sh;} else {d.sw=sw;d.sh=sh;}
      d.gap=gap;d.placed={};saveLayout();redraw();
    };
    ["ed-sw","ed-sh","ed-gap"].forEach(id=>document.getElementById(id).onchange=applySize);
    document.getElementById("ed-acount").onchange=()=>{d.a=resizeSide(d.a,+document.getElementById("ed-acount").value);d.placed={};saveLayout();redraw();renderDockEditor();};
    document.getElementById("ed-bcount").onchange=()=>{d.b=resizeSide(d.b,+document.getElementById("ed-bcount").value);d.placed={};saveLayout();redraw();renderDockEditor();};
    bindRot(d,()=>renderDockEditor());
    document.getElementById("ed-a").onchange=()=>{d.a=parseNums(document.getElementById("ed-a").value);saveLayout();redraw();};
    document.getElementById("ed-b").onchange=()=>{d.b=parseNums(document.getElementById("ed-b").value);saveLayout();redraw();};
    box.querySelectorAll("[data-nudge]").forEach(btn=>btn.onclick=()=>{const [dx,dy]=btn.dataset.nudge.split(",").map(Number);const c=clampDeltaForBox(dockBBox(d),dx,dy);if(isLocked(d)) moveDockSlips(d,c.dx,c.dy);d.x+=c.dx;d.y+=c.dy;saveLayout();redraw();renderDockEditor();});
    document.getElementById("ed-add-slip").onclick=()=>{
      const num=prompt("New slip number?", String(nextSlipNumber()));
      if(num==null||!String(num).trim()) return;
      d.extras=d.extras||[];
      d.extras.push({num:String(num).trim(),dx:0,dy:-30,w:d.sw||d.w||40,h:d.sh||d.h||16});
      d.locked=false;saveLayout();selected=String(num).trim();redraw();renderDockEditor();
    };
    document.getElementById("ed-reset-slips").onclick=()=>{d.placed={};saveLayout();redraw();renderDockEditor();};
    if(!document.getElementById("ed-fill-dock")){
      const colorRow=document.createElement("div");
      colorRow.innerHTML=`<label>Dock / slip color<input id="ed-fill-dock" type="color" value="${d.fill||COLORS[d.kind]||"#e4dcc8"}"/></label><div class="st"><button type="button" id="ed-dup-dock">Duplicate dock</button><button type="button" id="ed-del-dock">Delete dock</button></div>`;
      (document.getElementById("ed-more-block")||box).appendChild(colorRow);
      document.getElementById("ed-fill-dock").oninput=()=>{d.fill=document.getElementById("ed-fill-dock").value;saveLayout(false);redraw();};
      document.getElementById("ed-fill-dock").onchange=()=>saveLayout();
      document.getElementById("ed-dup-dock").onclick=()=>{
        const copy=clone(d); copy.id=uid("dock"); copy.name=(d.name||"Dock")+" copy"; copy.x+=40; copy.y+=40;
        docks.push(copy); ensureStackOrder(); stackMove(["dock:"+copy.id],"front"); selectedDock=copy.id; saveLayout(); redraw(); renderDockEditor();
      };
      document.getElementById("ed-del-dock").onclick=()=>{
        if(!confirm("Delete dock "+d.name+" and its slips?")) return;
        docks=docks.filter(x=>x.id!==d.id);
        groups.forEach(g=>g.members=(g.members||[]).filter(k=>k!=="dock:"+d.id));
        ensureStackOrder();
        selectedDock=null; selected=null; saveLayout(); redraw(); renderDockEditor();
      };
    }
    bindStackButtons();
  }else if(m){
    const kindName={bar:"Walkway",box:"Building",pill:"Building",bridge:"Bridge",text:"Label",p:"Parking"}[m.kind]||m.kind;
    const isText=m.kind==="text"||(m.text!=null&&m.kind!=="box"&&m.kind!=="pill");
    const colorVal=isText?(m.ink||"#d7eceb"):(m.fill||m.ink||"#2b6d8a");
    const colorLabel=isText?"Text color":(m.kind==="pill"||m.kind==="box"?"Fill color":"Color");
    const sizeVal=Math.max(8, Math.min(72, Math.round(m.size||13)));
    const whRow=(!isText||m.w!=null)?`<div class="row2"><label>Width<input id="ed-w" type="number" value="${Math.round(m.w||12)}"/></label><label>Height<input id="ed-h" type="number" value="${Math.round(m.h||20)}"/></label></div>`:"";
    const sizeRow=isText?`<label>Font size<input id="ed-size" type="number" min="8" max="72" step="1" value="${sizeVal}"/></label>`:"";
    const textFields=`${m.kind==="text"||m.text!=null?`<label>Text<input id="ed-text" value="${(m.text||"").replace(/"/g,"&quot;")}"/></label>`:""}${m.t1!=null?`<label>Title<input id="ed-t1" value="${(m.t1||"").replace(/"/g,"&quot;")}"/></label>`:""}${m.label!=null?`<label>Label<input id="ed-label" value="${(m.label||"").replace(/"/g,"&quot;")}"/></label>`:""}`;
    const bgRow=isText?`<label class="ed-check"><input id="ed-bg" type="checkbox"${m.bg?" checked":""}/> Background</label>${m.bg?`<label>Background color<input id="ed-bgfill" type="color" value="${m.bgFill||"#0c1c1a"}"/></label>`:""}`:"";
    box.innerHTML=`<h2>${kindName}</h2><p class="hint">${isText?"Drag on the map or use Placement & transform. Optional background helps labels on the aerial.":(m.title||m.id)}</p>${textFields}`+
      placementSec(`<div class="row2"><label>X<input id="ed-x" type="number" value="${Math.round(m.x)}"/></label><label>Y<input id="ed-y" type="number" value="${Math.round(m.y)}"/></label></div>${whRow}${sizeRow}${rotCtrl(Number(m.rot)||0)}${nudgeCtrlHtml()}`)+
      `${bgRow}<label>${colorLabel}<input id="ed-fill" type="color" value="${colorVal}"/></label>${m.kind==="box"||m.kind==="pill"?`<label>Text / ink color<input id="ed-ink" type="color" value="${m.ink||"#ffffff"}"/></label>`:""}${stackCtrlHtml()}<div class="st"><button type="button" id="ed-dup-mark">Duplicate</button><button type="button" id="ed-del">Delete this piece</button></div>`;
    const apply=()=>{const nx=+document.getElementById("ed-x").value,ny=+document.getElementById("ed-y").value;const ew=document.getElementById("ed-w"),eh=document.getElementById("ed-h");if(ew)m.w=+ew.value;if(eh)m.h=+eh.value;const c=clampDeltaForBox(markBBox(Object.assign({},m,{x:m.x,y:m.y})),nx-m.x,ny-m.y);m.x+=c.dx;m.y+=c.dy; clampLayoutIntoMap(); saveLayout();redraw();};
    document.getElementById("ed-x").onchange=apply;document.getElementById("ed-y").onchange=apply;
    const ew=document.getElementById("ed-w"); if(ew) ew.onchange=apply; const eh=document.getElementById("ed-h"); if(eh) eh.onchange=apply;
    bindRot(m,()=>renderDockEditor());
    const t=document.getElementById("ed-text"); if(t) t.oninput=()=>{m.text=t.value;saveLayout();redraw();};
    const t1=document.getElementById("ed-t1"); if(t1) t1.oninput=()=>{m.t1=t1.value;saveLayout();redraw();};
    const lb=document.getElementById("ed-label"); if(lb) lb.oninput=()=>{m.label=lb.value;saveLayout();redraw();};
    const sz=document.getElementById("ed-size"); if(sz){ sz.oninput=()=>{m.size=Math.max(8,Math.min(72,+sz.value||13));saveLayout(false);redraw();}; sz.onchange=()=>{m.size=Math.max(8,Math.min(72,+sz.value||13));saveLayout();}; }
    const bgEl=document.getElementById("ed-bg");
    if(bgEl){ bgEl.onchange=()=>{ m.bg=!!bgEl.checked; if(!m.bg) delete m.bgFill; else if(!m.bgFill) m.bgFill="#0c1c1a"; saveLayout(); redraw(); renderDockEditor(); }; }
    const bgf=document.getElementById("ed-bgfill");
    if(bgf){ bgf.oninput=()=>{ m.bgFill=bgf.value; saveLayout(false); redraw(); }; bgf.onchange=()=>saveLayout(); }
    box.querySelectorAll("[data-nudge]").forEach(btn=>btn.onclick=()=>{const [dx,dy]=btn.dataset.nudge.split(",").map(Number);const c=clampDeltaForBox(markBBox(m),dx,dy);m.x+=c.dx;m.y+=c.dy;saveLayout();redraw();renderDockEditor();});
    const cf=document.getElementById("ed-fill");
    if(cf){ cf.oninput=()=>{ if(m.kind==="text") m.ink=cf.value; else m.fill=cf.value; saveLayout(false); redraw(); }; cf.onchange=()=>saveLayout(); }
    const ink=document.getElementById("ed-ink");
    if(ink){ ink.oninput=()=>{ m.ink=ink.value; saveLayout(false); redraw(); }; ink.onchange=()=>saveLayout(); }
    document.getElementById("ed-dup-mark").onclick=()=>{ const copy=clone(m); copy.id=uid(m.kind||"mark"); copy.x+=30; copy.y+=30; marks.push(copy); ensureStackOrder(); stackMove(["mark:"+copy.id],"front"); selectedMark=copy.id; saveLayout(); redraw(); renderDockEditor(); };
    document.getElementById("ed-del").onclick=()=>{if(!confirm("Delete this piece?"))return;marks=marks.filter(x=>x.id!==m.id);groups.forEach(g=>g.members=(g.members||[]).filter(k=>k!=="mark:"+m.id));ensureStackOrder();selectedMark=null;saveLayout();redraw();renderDockEditor();};
    bindStackButtons();
  }else box.innerHTML="<p>Click a dock, slip, walkway, building, or label. Workflow: Unlock slips → Multi-select → move/resize → Lock as dock.</p>";
 } finally {
  if(typeof isMobileEdit==="function" && isMobileEdit() && document.body.classList.contains("editing")){
    requestAnimationFrame(()=>{ try{ syncEditChromeHeight(); }catch(e){} });
  }
 }
}

/* ===== Whole-dock layer assigning (v96) ===== */
var dockAssignOpen=false;
function dockSlipIdsFor(dockId){
  const d=docks.find(x=>x.id===dockId); if(!d) return [];
  let ids=slips.filter(s=>s.dockId===dockId).map(s=>s.id);
  if(!ids.length){ try{ ids=generatedSlips(d).map(s=>applyPlaced(d,s).id); }catch(e){} }
  return ids;
}
function slipIdsForKeys(keys){
  const out=[], seen=new Set();
  const add=id=>{ const k=String(id); if(seen.has(k)) return; seen.add(k); out.push(id); };
  (keys||[]).forEach(key=>{
    const i=String(key).indexOf(":"); if(i<0) return;
    const kind=String(key).slice(0,i), id=String(key).slice(i+1);
    if(kind==="slip"){ const s=slips.find(x=>String(x.id)===id); add(s?s.id:id); }
    else if(kind==="dock"){ const d=docks.find(x=>String(x.id)===id); if(d) dockSlipIdsFor(d.id).forEach(add); }
  });
  return out;
}
function dockAssignSectionHtml(title, count, collapsible){
  if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY) return "";
  if(!layers.length || !count) return "";
  const selects=layers.map(layer=>{
    const options=["<option value=\"__keep\" selected>\u2014</option>","<option value=\"\">Unassigned</option>"].concat((layer.options||[]).map(o=>"<option value=\""+o.id+"\">"+o.name+"</option>"));
    return "<label>"+layer.name+"<select data-dock-assign=\""+layer.id+"\">"+options.join("")+"</select></label>";
  }).join("");
  const inner="<p class=\"hint\" style=\"margin:0 0 4px\">Pick an option to set it on all "+count+" slips. You can still change single slips afterward.</p><div class=\"row2\">"+selects+"</div>";
  if(collapsible) return "<details class=\"ed-sec dock-assign\""+(dockAssignOpen?" open":"")+"><summary class=\"ed-sec-title\" style=\"cursor:pointer;margin:0\">"+title+"</summary><div style=\"margin-top:6px\">"+inner+"</div></details>";
  return "<div class=\"ed-sec dock-assign\"><div class=\"ed-sec-title\">"+title+"</div>"+inner+"</div>";
}
function bindDockAssign(box, getIds, label, after){
  if(!box) return;
  const det=box.querySelector("details.dock-assign");
  if(det) det.addEventListener("toggle",()=>{ dockAssignOpen=det.open; });
  box.querySelectorAll("[data-dock-assign]").forEach(sel=>{
    sel.onchange=()=>{
      const v=sel.value, layerId=sel.dataset.dockAssign;
      if(v==="__keep") return;
      if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){ sel.value="__keep"; blockEdit(); return; }
      const layer=layers.find(l=>l.id===layerId);
      const opt=layer&&(layer.options||[]).find(o=>o.id===v);
      const ids=getIds();
      if(!layer||!ids.length){ sel.value="__keep"; return; }
      const optName=v?(opt?opt.name:v):"Unassigned";
      if(!confirm("Set "+layer.name+" to \u201c"+optName+"\u201d on all "+ids.length+" slips of "+label+"?")){ sel.value="__keep"; return; }
      ids.forEach(id=>{
        data[id]=data[id]||{status:"vacant"};
        data[id].layerOpts=data[id].layerOpts||{};
        if(!v) delete data[id].layerOpts[layerId];
        else data[id].layerOpts[layerId]=v;
      });
      save(data);
      sel.value="__keep";
      redraw();
      if(typeof after==="function"){ try{ after(); }catch(e){} }
    };
  });
}
function renderSlipLayerAssigns(slipId){
  const box=document.getElementById("slip-layer-assigns");
  if(!box) return;
  if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){
    if(!layers.length||!activeLayerId){ box.innerHTML=""; return; }
    const layer=layers.find(l=>l.id===activeLayerId);
    const rec=data[slipId]||{};
    const optId=(rec.layerOpts||{})[activeLayerId];
    const opt=layer && (layer.options||[]).find(o=>o.id===optId);
    box.innerHTML="<p class=\"hint\" style=\"margin-top:10px\">"+ (layer?layer.name:"Layer") +": <b>"+(opt?opt.name:"Unassigned")+"</b></p>";
    return;
  }
  if(!layers.length){ box.innerHTML=""; return; }
  const rec=data[slipId]||{};
  const opts=rec.layerOpts||{};
  box.innerHTML="<p class=\"hint\" style=\"margin-top:10px\">Layer colors</p>"+layers.map(layer=>{
    const cur=opts[layer.id]||"";
    const options=["<option value=\"\">Unassigned</option>"].concat((layer.options||[]).map(o=>"<option value=\""+o.id+"\""+(cur===o.id?" selected":"")+">"+o.name+"</option>"));
    return "<label>"+layer.name+"<select data-layer-assign=\""+layer.id+"\">"+options.join("")+"</select></label>";
  }).join("");
  const assignSlip=slips.find(x=>String(x.id)===String(slipId));
  const assignDock=assignSlip&&docks.find(x=>x.id===assignSlip.dockId);
  if(assignDock){
    box.innerHTML+=dockAssignSectionHtml("Set all slips on Dock "+assignDock.name, dockSlipIdsFor(assignDock.id).length, true);
    bindDockAssign(box, ()=>dockSlipIdsFor(assignDock.id), "Dock "+assignDock.name, ()=>renderSlipLayerAssigns(slipId));
  }
  box.querySelectorAll("[data-layer-assign]").forEach(sel=>{
    sel.onchange=()=>{
      data[slipId]=data[slipId]||{status:"vacant"};
      data[slipId].layerOpts=data[slipId].layerOpts||{};
      const v=sel.value;
      if(!v) delete data[slipId].layerOpts[sel.dataset.layerAssign];
      else data[slipId].layerOpts[sel.dataset.layerAssign]=v;
      save(data); redraw();
    };
  });
}
function select(id){selected=id;selectedDock=null;selectedMark=null;const s=slips.find(x=>x.id===id);if(!s)return;const rec=data[id]||{status:"vacant",boat:"",notes:""};document.getElementById("slip-detail").hidden=false;document.getElementById("slip-title").textContent=(/^\d+$/.test(String(s.num))?"Slip ":"")+s.num;document.getElementById("slip-meta").textContent="Dock "+s.dock+" · "+s.size;document.getElementById("boat").value=rec.boat||"";document.getElementById("notes").value=rec.notes||"";document.querySelectorAll("#pane-slip .st button").forEach(b=>b.classList.toggle("on",b.dataset.st===(rec.status||"vacant")));renderSlipLayerAssigns(id);if(!editing)showTab("slip");redraw();}
function selectDock(id){selectedDock=id;selectedMark=null;if(!editing) selected=null;showTab("layout");if(!isMobileEdit()) openEditPanel(); else { const h=document.getElementById("hint"); if(h) h.textContent=pieceLabel("dock",id)+" · drag to move · Tools for properties";  } renderDockEditor();redraw();updateSelChip();}
function selectMark(id){selectedMark=id;selectedDock=null;selected=null;showTab("layout");if(!isMobileEdit()) openEditPanel(); else { const h=document.getElementById("hint"); if(h) h.textContent=pieceLabel("mark",id)+" · drag to move · Tools for properties";  } renderDockEditor();redraw();updateSelChip();}
function selectEditSlip(id){
  const s=slips.find(x=>x.id===id); if(!s) return;
  selected=id; selectedDock=s.dockId; selectedMark=null;
  showTab("layout"); if(!isMobileEdit()) openEditPanel(); else { const h=document.getElementById("hint"); if(h){ const num=String(s.num); h.textContent=((/^\d+$/.test(num)?"Slip ":"")+num)+" · drag to move · Tools for properties"; }  } renderDockEditor(); redraw(); updateSelChip();
}
let dockDrag=null,pan=null; // scale/tx/ty declared earlier for screen-aware labels
function lodFade(t,a,b){ if(t<=a) return 0; if(t>=b) return 1; return (t-a)/(b-a); }
function zoomUnit(){ return scale/Math.max(1e-6, minFitScale()); }
function applyDeepZoomLod(){
  applyPhotoAlign();
  const btn=document.getElementById("btn-deep-zoom");
  if(btn) btn.classList.toggle("on", deepZoom);
  document.body.classList.toggle("deepzoom", deepZoom);
  const val=document.getElementById("photo-op-val");
  if(val) val.textContent=Math.round(photoMax*100)+"%";
  if(!deepZoom || editing || multiPick || photoMoveMode || dockAlignMode || gcpMode || scaleMeasureMode){
    // Keep aerial visible while aligning / measuring (deep-zoom fade hides the photo when zoomed in)
    bgImg.setAttribute("opacity", String(photoMax));
    if(layerStack) layerStack.setAttribute("opacity","1");
    [layerSite, layerWalkMarks, layerDocks, layerSlips, layerLabels].forEach(L=>{ if(L) L.setAttribute("opacity","1"); });
    if(layerStack) layerStack.querySelectorAll("[data-lod]").forEach(n=>n.setAttribute("opacity","1"));
    return;
  }
  const z=zoomUnit();
  // Photo strong when zoomed out; fades as vectors appear
  const photo = photoMax * (1 - lodFade(z, 0.95, 2.2));
  bgImg.setAttribute("opacity", String(Math.max(0, Math.min(1, photo))));
  const site = lodFade(z, 0.85, 1.35);
  const walk = lodFade(z, 1.15, 1.75);
  const labels = lodFade(z, 2.0, 2.9);
  if(layerStack){
    layerStack.setAttribute("opacity","1");
    layerStack.querySelectorAll("[data-lod]").forEach(n=>{
      const b=n.getAttribute("data-lod");
      n.setAttribute("opacity", String(b==="site"?site : b==="labels"?labels : walk));
    });
  }
  if(layerSite) layerSite.setAttribute("opacity", String(site));
  if(layerWalkMarks) layerWalkMarks.setAttribute("opacity", String(walk));
  if(layerDocks) layerDocks.setAttribute("opacity", String(walk));
  if(layerSlips) layerSlips.setAttribute("opacity", String(lodFade(z, 1.55, 2.35)));
  if(layerLabels) layerLabels.setAttribute("opacity", String(labels));
}
function applyZoom(){ svg.style.transform=`translate(${tx}px,${ty}px) scale(${scale})`; applyDeepZoomLod(); syncLabelFonts(); }
function chartSize(){
  if(!chart) return {w:800, h:560};
  const r=chart.getBoundingClientRect();
  return {w:Math.max(320, r.width||800), h:Math.max(240, r.height||560)};
}
function minFitScale(){
  const {w,h}=chartSize();
  return Math.min(w/WORLD_W, h/WORLD_H)*0.96;
}
function minZoomScale(){
  // Allow zooming out well past "fit whole map" for more range
  return Math.max(0.06, minFitScale()*0.28);
}
function maxZoomScale(){ return deepZoom ? 9 : 5; }
function fitWholeMap(){
  const {w,h}=chartSize();
  scale=Math.max(minZoomScale(), Math.min(maxZoomScale(), minFitScale()));
  tx=(w-WORLD_W*scale)/2;
  ty=(h-WORLD_H*scale)/2;
  applyZoom();
}
function zoomToward(cx,cy,factor){
  const s1=Math.min(maxZoomScale(), Math.max(minZoomScale(), scale*factor));
  const k=s1/scale;
  tx=cx-(cx-tx)*k;
  ty=cy-(cy-ty)*k;
  scale=s1;
  applyZoom();
}
function defaultMarinaZoom(){
  // Start fit-to-page, then zoom in so docks are readable; ⛶ still fits the whole map
  fitWholeMap();
  const {w,h}=chartSize();
  zoomToward(w/2, h/2, 1.9);
}
svg.addEventListener("click",e=>{
  if(dockDrag&&dockDrag.moved)return;
  if(photoMoveMode||dockAlignMode||gcpMode){ e.preventDefault(); e.stopPropagation(); return; }
  if(editing){
    const sEl=e.target.closest("[data-id]");
    const dEl=e.target.closest("[data-dock]");
    const mEl=e.target.closest("[data-mark]");
    // Desktop Shift-click multi-select (phones use Multi-select + pointerup instead)
    if(e.shiftKey){
      if(sEl && sEl.getAttribute("data-id")){
        const id=sEl.getAttribute("data-id");
        toggleMultiKey("slip:"+id);
        selected=id; selectedDock=null; selectedMark=null;
        showTab("layout"); renderDockEditor();
        return;
      }
      if(dEl){
        const id=dEl.getAttribute("data-dock");
        toggleMultiKey("dock:"+id);
        selectedDock=id; selectedMark=null; selected=null;
        showTab("layout"); renderDockEditor();
        return;
      }
      if(mEl){
        const id=mEl.getAttribute("data-mark");
        toggleMultiKey("mark:"+id);
        selectedMark=id; selectedDock=null; selected=null;
        showTab("layout"); renderDockEditor();
        return;
      }
      return;
    }
    if(multiPick){
      // Handled on pointerup for touch — ignore click to avoid double-toggle
      return;
    }
    if(sEl){
      const dock=docks.find(x=>x.id===sEl.getAttribute("data-dock"));
      if(dock && !isLocked(dock)){ selectEditSlip(sEl.getAttribute("data-id")); return; }
      if(dEl){ selectDock(dEl.getAttribute("data-dock")); return; }
    }
    if(dEl){selectDock(dEl.getAttribute("data-dock"));return;}
    if(mEl){selectMark(mEl.getAttribute("data-mark"));return;}
    return;
  }
  const t=e.target.closest("[data-id]"); if(t) select(t.getAttribute("data-id"));
});
function markHitBox(m){
  if(!m) return null;
  if(m.kind==="text"){
    const fs=Math.max(8, Math.min(72, Number(m.size)||13));
    const w=Math.max(28,(m.text||"").length*fs*0.62);
    return {x:m.x-4,y:m.y-fs,w:w,h:fs+8};
  }
  if(m.kind==="p"){
    const rx=m.w?m.w/2:70, ry=m.h?m.h/2:26;
    return {x:m.x-rx,y:m.y-ry,w:rx*2,h:ry*2};
  }
  if(m.w!=null && m.h!=null) return {x:m.x,y:m.y,w:m.w,h:m.h};
  return {x:m.x-12,y:m.y-12,w:24,h:24};
}
function dist2ToRect(px,py,r){
  const cx=Math.max(r.x, Math.min(px, r.x+r.w));
  const cy=Math.max(r.y, Math.min(py, r.y+r.h));
  const dx=px-cx, dy=py-cy;
  return dx*dx+dy*dy;
}
function hitEditTarget(e){
  // Prefer real DOM hits (including stacked SVG under the finger)
  let sEl=null, dEl=null, mEl=null;
  const pickFrom = (node)=>{
    if(!node || !node.closest) return;
    if(!sEl){ const s=node.closest("[data-id]"); if(s && chart.contains(s)) sEl=s; }
    if(!dEl){ const d=node.closest("[data-dock]"); if(d && chart.contains(d)) dEl=d; }
    if(!mEl){ const m=node.closest("[data-mark]"); if(m && chart.contains(m)) mEl=m; }
  };
  pickFrom(e.target);
  if(!sEl && !dEl && !mEl && document.elementsFromPoint){
    const stack=document.elementsFromPoint(e.clientX, e.clientY)||[];
    for(const node of stack){
      const before=!(sEl||dEl||mEl);
      pickFrom(node);
      // Stop at the topmost interactive chart piece
      if(before && (sEl||dEl||mEl)) break;
    }
  }
  // Geometric slop: fat-finger near a dock/slip/mark should still grab it (not pan)
  if(!sEl && !dEl && !mEl){
    const p=svgPoint(e);
    const slop=Math.max(14, 22/Math.max(0.001, scale)); // ~22 screen px in world units
    const slop2=slop*slop;
    let best=null, bestD=slop2;
    slips.forEach(s=>{
      const r={x:s.x,y:s.y,w:s.w,h:s.h};
      const d=dist2ToRect(p.x,p.y,r);
      if(d<=bestD){ bestD=d; best={type:"slip",s}; }
    });
    docks.forEach(d=>{
      const g=walkGeomFromDock(d);
      const r={x:g.x,y:g.y,w:g.w,h:g.h};
      const dist=dist2ToRect(p.x,p.y,r);
      if(dist<=bestD){ bestD=dist; best={type:"dock",d}; }
      // also dock label area near name
      const lr={x:d.x-24,y:d.y-28,w:48,h:22};
      const distL=dist2ToRect(p.x,p.y,lr);
      if(distL<=bestD){ bestD=distL; best={type:"dock",d}; }
    });
    marks.forEach(m=>{
      const box=markHitBox(m); if(!box) return;
      const dist=dist2ToRect(p.x,p.y,box);
      if(dist<=bestD){ bestD=dist; best={type:"mark",m}; }
    });
    if(best){
      if(best.type==="slip"){
        // Synthesize via querying current DOM if present
        sEl=(layerStack && layerStack.querySelector('[data-id="'+best.s.id+'"]')) || (layerSlips && layerSlips.querySelector('[data-id="'+best.s.id+'"]'));
        if(!sEl){
          // fake minimal attrs object
          sEl={ getAttribute:(k)=>k==="data-id"?best.s.id:(k==="data-dock"?best.s.dockId:null), closest:(sel)=>sel.includes("data-id")?sEl:(sel.includes("data-dock")?sEl:null) };
        }
        dEl=sEl;
      }else if(best.type==="dock"){
        dEl=(layerStack && layerStack.querySelector('[data-dock="'+best.d.id+'"]')) || (layerDocks && layerDocks.querySelector('[data-dock="'+best.d.id+'"]'));
        if(!dEl) dEl={ getAttribute:(k)=>k==="data-dock"?best.d.id:null, closest:()=>dEl };
      }else if(best.type==="mark"){
        mEl=(layerStack && layerStack.querySelector('[data-mark="'+best.m.id+'"]')) || (
          (layerMarks && layerMarks.querySelector('[data-mark="'+best.m.id+'"]')) ||
          (layerWalkMarks && layerWalkMarks.querySelector('[data-mark="'+best.m.id+'"]')) ||
          (layerLabels && layerLabels.querySelector('[data-mark="'+best.m.id+'"]')) ||
          (layerSite && layerSite.querySelector('[data-mark="'+best.m.id+'"]'))
        );
        if(!mEl) mEl={ getAttribute:(k)=>k==="data-mark"?best.m.id:null, closest:()=>mEl };
      }
    }
  }
  // If we hit a slip that carries data-dock, treat as dock hit too for locked docks
  if(sEl && !dEl){
    const did=sEl.getAttribute("data-dock");
    if(did) dEl=sEl;
  }
  return {sEl,dEl,mEl};
}
// v97: two-finger pinch zooms the map in view and edit mode. .chart has touch-action:none,
// so the browser can't pinch there; the map handles it here. Pinch outside the map is left to the browser.
// Photo move / dock align keep their own two-finger scaling.
const mapPinchPts=new Map(), mapPinchIgnore=new Set();
let mapPinch=null, mapPinchHold=null;
function mapPinchAllowed(){ return !photoMoveMode && !dockAlignMode; }
function mapPinchGeom(){
  const r=chart.getBoundingClientRect(), v=[...mapPinchPts.values()], a=v[0], b=v[1];
  return {d:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)), mx:(a.x+b.x)/2-r.left, my:(a.y+b.y)/2-r.top};
}
function mapPinchUndoDrag(){
  // Second finger landed before the first finger really dragged: put back any tiny live move, save nothing
  if(!dockDrag) return;
  try{
    if(dockDrag.kind==="chart"){ clearSelectionNudge(); }
    else if(dockDrag.kind==="dock"){
      const d=docks.find(x=>x.id===dockDrag.id);
      if(d){ const mdx=dockDrag.x-d.x, mdy=dockDrag.y-d.y;
        if(mdx||mdy){ const g=findGroupFor("dock", d.id); if(g) moveGroupMembers(g,mdx,mdy); else { if(isLocked(d)) moveDockSlips(d,mdx,mdy); d.x=dockDrag.x; d.y=dockDrag.y; } redraw(); } }
    }else if(dockDrag.kind==="mark"){
      const m=marks.find(x=>x.id===dockDrag.id);
      if(m){ const mdx=dockDrag.x-m.x, mdy=dockDrag.y-m.y;
        if(mdx||mdy){ const g=findGroupFor("mark", m.id); if(g) moveGroupMembers(g,mdx,mdy); else { m.x=dockDrag.x; m.y=dockDrag.y; } redraw(); } }
    }else if(dockDrag.kind==="slip"){
      const d=docks.find(x=>x.id===dockDrag.dockId), p=d&&d.placed&&d.placed[dockDrag.id];
      if(p && (p.x!==dockDrag.x || p.y!==dockDrag.y)){ setPlaced(d,dockDrag.id,{x:dockDrag.x,y:dockDrag.y}); redraw(); }
    }
  }catch(_){}
}
chart.addEventListener("pointerdown",e=>{
  if(e.pointerType==="mouse") return;
  if(e.isPrimary){ mapPinchPts.clear(); mapPinchIgnore.clear(); mapPinch=null; mapPinchHold=null; } // first finger of a new touch: drop stale state
  if(e.target.closest && e.target.closest(".zoom,.pan,button,input,select,textarea,label,#scale-measure-chip,#gcp-align-chip,#photo-move-chip,#dock-align-chip")) return;
  mapPinchPts.set(e.pointerId,{x:e.clientX,y:e.clientY,x0:e.clientX,y0:e.clientY});
  if(mapPinchPts.size<2 || !mapPinchAllowed()) return;
  if(!mapPinch){
    const first=[...mapPinchPts.values()][0];
    const dragging=dockDrag && dockDrag.kind!=="pick" && Math.hypot(first.x-first.x0, first.y-first.y0)>12;
    if(dragging){ mapPinchPts.delete(e.pointerId); mapPinchIgnore.add(e.pointerId); e.stopImmediatePropagation(); return; } // keep the drag; ignore the extra finger
    mapPinchUndoDrag();
    dockDrag=null; pan=null; scaleDrag=null; gcpDrag=null; mapPinchHold=null; chart.style.cursor="";
    const g=mapPinchGeom();
    mapPinch={d0:g.d, s0:scale, wx:(g.mx-tx)/scale, wy:(g.my-ty)/scale};
  }
  try{ e.preventDefault(); }catch(_){}
  try{ chart.setPointerCapture(e.pointerId); }catch(_){}
  e.stopImmediatePropagation();
});
chart.addEventListener("pointermove",e=>{
  if(mapPinchIgnore.has(e.pointerId)){ e.stopImmediatePropagation(); return; }
  const pt=mapPinchPts.get(e.pointerId);
  if(!pt) return;
  pt.x=e.clientX; pt.y=e.clientY;
  if(mapPinch && mapPinchPts.size>=2){
    const g=mapPinchGeom();
    const s1=Math.min(maxZoomScale(), Math.max(minZoomScale(), mapPinch.s0*g.d/mapPinch.d0));
    scale=s1; tx=g.mx-mapPinch.wx*s1; ty=g.my-mapPinch.wy*s1; applyZoom();
  }else if(mapPinchHold && mapPinchHold.id===e.pointerId){
    tx=e.clientX-mapPinchHold.px; ty=e.clientY-mapPinchHold.py; applyZoom(); // one finger left: keep panning
  }else return;
  try{ e.preventDefault(); }catch(_){}
  e.stopImmediatePropagation();
});
function mapPinchEnd(e){
  if(mapPinchIgnore.delete(e.pointerId)){ e.stopImmediatePropagation(); return; }
  if(!mapPinchPts.delete(e.pointerId)) return;
  if(!mapPinch && !mapPinchHold) return;
  e.stopImmediatePropagation();
  dockDrag=null; pan=null;
  if(mapPinchPts.size>=2){ const g=mapPinchGeom(); mapPinch={d0:g.d, s0:scale, wx:(g.mx-tx)/scale, wy:(g.my-ty)/scale}; return; }
  mapPinch=null;
  if(mapPinchPts.size===1){ const [id,p]=[...mapPinchPts.entries()][0]; mapPinchHold={id, px:p.x-tx, py:p.y-ty}; }
  else mapPinchHold=null;
}
chart.addEventListener("pointerup",mapPinchEnd);
chart.addEventListener("pointercancel",mapPinchEnd);
// iOS Safari: keep a pinch on the map from also zooming the page
chart.addEventListener("gesturestart",e=>{ try{ e.preventDefault(); }catch(_){} },{passive:false});
chart.addEventListener("gesturechange",e=>{ try{ e.preventDefault(); }catch(_){} },{passive:false});
chart.addEventListener("pointerdown",e=>{
  if(scaleMeasureMode){
    try{ e.preventDefault(); }catch(_){}
    if(e.target.closest && e.target.closest(".zoom,.pan,#scale-measure-chip,#gcp-align-chip,#photo-move-chip,#dock-align-chip,button,input,label")) return;
    const p=svgPoint(e);
    scaleDrag={px:p.x,py:p.y,cx:e.clientX,cy:e.clientY,moved:false};
    try{ chart.setPointerCapture(e.pointerId); }catch(_){}
    return;
  }
  if(gcpMode){
    try{ e.preventDefault(); }catch(_){}
    if(e.target.closest && e.target.closest(".zoom,.pan,#gcp-align-chip,#photo-move-chip,#dock-align-chip,button,input,label")) return;
    const p=svgPoint(e);
    gcpDrag={px:p.x,py:p.y,cx:e.clientX,cy:e.clientY,moved:false};
    try{ chart.setPointerCapture(e.pointerId); }catch(_){}
    return;
  }
  if(dockAlignMode){
    try{ e.preventDefault(); }catch(_){}
    if(e.target.closest && e.target.closest(".zoom,.pan,#dock-align-chip,#photo-move-chip,button,input,label")) return;
    dockAlignPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const p=svgPoint(e);
    const keys = multi.size ? [...multi] : allLayoutKeys();
    const box = keysBBox(keys) || {x:0,y:0,w:MAP_W,h:MAP_H};
    const cx = box.x + box.w/2, cy = box.y + box.h/2;
    if(dockAlignPointers.size>=2){
      const dist=dockAlignPinchDist();
      dockAlignDrag={kind:"pinch",keys,startDist:dist,startScale:1,cx,cy,sx:0,sy:0,moved:false};
    }else{
      dockAlignDrag={kind:"pan",keys,px:p.x,py:p.y,sx:0,sy:0,cx,cy,scaleF:1,moved:false,startBox:box};
    }
    try{ chart.setPointerCapture(e.pointerId); }catch(_){}
    return;
  }
  if(photoMoveMode){
    try{ e.preventDefault(); }catch(_){}
    if(e.target.closest && e.target.closest(".zoom,.pan,#photo-move-chip,#dock-align-chip,button,input,label")) return;
    photoPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const p=svgPoint(e);
    if(photoPointers.size>=2){
      const dist=photoPinchDist();
      photoDrag={kind:"pinch",startDist:dist,startScaleX:clampPhotoScale(photoAlign.scaleX!=null?photoAlign.scaleX:photoAlign.scale),startScaleY:clampPhotoScale(photoAlign.scaleY!=null?photoAlign.scaleY:photoAlign.scale),moved:false};
    }else{
      photoDrag={kind:"pan",ox:Number(photoAlign.x)||0,oy:Number(photoAlign.y)||0,px:p.x,py:p.y,moved:false};
    }
    try{ chart.setPointerCapture(e.pointerId); }catch(_){}
    return;
  }
  if(editing){
    // Prevent browser pan/zoom gestures from stealing the interaction
    try{ e.preventDefault(); }catch(_){}
    const {sEl,dEl,mEl}=hitEditTarget(e);
    const p=svgPoint(e);
    // Multi-select: tap toggles; if several already selected, dragging a selected piece moves the set
    if(multiPick){
      let tapKey=null, tapDock=null, tapMark=null, tapSlip=null;
      if(sEl && sEl.getAttribute("data-id")){
        tapSlip=sEl.getAttribute("data-id");
        tapKey="slip:"+tapSlip;
        tapDock=sEl.getAttribute("data-dock")||null;
      }else if(mEl && mEl.getAttribute("data-mark")){ tapMark=mEl.getAttribute("data-mark"); tapKey="mark:"+tapMark; }
      else if(dEl && dEl.getAttribute("data-dock")){ tapDock=dEl.getAttribute("data-dock"); tapKey="dock:"+tapDock; }
      if(tapKey){
        if(multi.size>1 && multi.has(tapKey)){
          const _keys=[...multi]; dockDrag={kind:"chart",keys:_keys,px:p.x,py:p.y,sx:0,sy:0,moved:false,fromMultiPick:true,tapKey,tapDock,tapMark,tapSlip,startBox:keysBBox(_keys)};
          chart.style.cursor="grabbing";
          chart.setPointerCapture(e.pointerId);
          return;
        }
        dockDrag={kind:"pick",tapKey,tapDock,tapMark,tapSlip,px:p.x,py:p.y,moved:false};
        chart.setPointerCapture(e.pointerId);
        return;
      }
      pan={x:e.clientX-tx,y:e.clientY-ty}; chart.setPointerCapture(e.pointerId); return;
    }
    // Grouped / multi-selected / select-all:
    //  - drag a SELECTED piece → move only that selection (pan must not steal)
    //  - tap a selected piece → remove from selection
    //  - tap an unselected piece → add to selection
    //  - empty water / drag on unselected → pan
    if(moveWholeChart || multi.size>1){
      let tapKey=null, tapDock=null, tapMark=null, tapSlip=null;
      if(sEl && sEl.getAttribute("data-id")){
        tapSlip=sEl.getAttribute("data-id");
        tapKey="slip:"+tapSlip;
        tapDock=sEl.getAttribute("data-dock")||null;
      }else if(mEl && mEl.getAttribute("data-mark")){ tapMark=mEl.getAttribute("data-mark"); tapKey="mark:"+tapMark; }
      else if(dEl && dEl.getAttribute("data-dock")){ tapDock=dEl.getAttribute("data-dock"); tapKey="dock:"+tapDock; }
      if(!(sEl||dEl||mEl) || !tapKey){
        pan={x:e.clientX-tx,y:e.clientY-ty}; chart.setPointerCapture(e.pointerId); return;
      }
      if(selectionOwnsTap(tapKey, tapDock) || (!multi.size && moveWholeChart)){
        const keys = multi.size ? [...multi] : allLayoutKeys();
        // Tap-toggle only when the exact key is in multi; dock/slip ownership still drags the group
        const canToggle = multi.has(tapKey);
        dockDrag={kind:"chart",keys,px:p.x,py:p.y,sx:0,sy:0,moved:false,fromMultiPick:canToggle,tapKey,tapDock,tapMark,tapSlip,startBox:keysBBox(keys)};
        chart.style.cursor="grabbing";
        chart.setPointerCapture(e.pointerId);
        return;
      }
      // Hit outside the current selection — allow free add (tap) without moving the group
      dockDrag={kind:"pick",tapKey,tapDock,tapMark,tapSlip,px:p.x,py:p.y,moved:false};
      chart.setPointerCapture(e.pointerId);
      return;
    }
    if(sEl){
      const dock=docks.find(x=>x.id===sEl.getAttribute("data-dock"));
      const slip=slips.find(x=>x.id===sEl.getAttribute("data-id"));
      const slipId=sEl.getAttribute("data-id");
      const slipBundle=slipId ? keysForDrag("slip", slipId) : null;
      const bundle=slipBundle || (dock ? keysForDrag("dock", dock.id) : null);
      if(bundle){
        dockDrag={kind:"chart",keys:bundle,px:p.x,py:p.y,sx:0,sy:0,moved:false,startBox:keysBBox(bundle)};
        chart.setPointerCapture(e.pointerId);
        return;
      }
      // Multi size 1 with this slip (after Move selected): treat as chart move of that slip even if dock locked
      if(slipId && multi.size===1 && multi.has("slip:"+slipId)){
        const keys=["slip:"+slipId];
        dockDrag={kind:"chart",keys,px:p.x,py:p.y,sx:0,sy:0,moved:false,startBox:keysBBox(keys)};
        chart.setPointerCapture(e.pointerId);
        return;
      }
      if(dock && slip && !isLocked(dock)){
        dockDrag={kind:"slip",dockId:dock.id,id:slip.id,x:slip.x,y:slip.y,px:p.x,py:p.y,moved:false,startBox:slipBBoxFrom(dock,slip.id,slip)};
        selectEditSlip(slip.id);
        chart.setPointerCapture(e.pointerId);
        return;
      }
      // Locked dock: still allow dragging a slip alone via placed coords when explicitly selected
      if(dock && slip && isLocked(dock) && selected===slip.id){
        dockDrag={kind:"slip",dockId:dock.id,id:slip.id,x:slip.x,y:slip.y,px:p.x,py:p.y,moved:false,startBox:slipBBoxFrom(dock,slip.id,slip)};
        chart.setPointerCapture(e.pointerId);
        return;
      }
    }
    if(dEl){
      const d=docks.find(x=>x.id===dEl.getAttribute("data-dock"));
      if(d){
        const bundle=keysForDrag("dock", d.id);
        if(bundle){ dockDrag={kind:"chart",keys:bundle,px:p.x,py:p.y,sx:0,sy:0,moved:false,startBox:keysBBox(bundle)}; chart.setPointerCapture(e.pointerId); return; }
        dockDrag={kind:"dock",id:d.id,x:d.x,y:d.y,px:p.x,py:p.y,moved:false,startBox:dockBBox(d)};selectDock(d.id);chart.setPointerCapture(e.pointerId);return;
      }
    }
    if(mEl){
      const m=marks.find(x=>x.id===mEl.getAttribute("data-mark"));
      if(m){
        const bundle=keysForDrag("mark", m.id);
        if(bundle){ dockDrag={kind:"chart",keys:bundle,px:p.x,py:p.y,sx:0,sy:0,moved:false,startBox:keysBBox(bundle)}; chart.setPointerCapture(e.pointerId); return; }
        dockDrag={kind:"mark",id:m.id,x:m.x,y:m.y,px:p.x,py:p.y,moved:false,startBox:markBBox(m)};selectMark(m.id);chart.setPointerCapture(e.pointerId);return;
      }
    }
    // Empty water / background only → pan the map
    pan={x:e.clientX-tx,y:e.clientY-ty};chart.setPointerCapture(e.pointerId);return;
  }
  if(e.target.closest("[data-id]")) return;
  pan={x:e.clientX-tx,y:e.clientY-ty};chart.setPointerCapture(e.pointerId);
});
chart.addEventListener("pointermove",e=>{
  if(scaleMeasureMode && scaleDrag){
    const p=svgPoint(e);
    const scaleSlop=(e.pointerType==="touch"||e.pointerType==="pen")?18:10;
    if(!scaleDrag.moved && (Math.hypot(e.clientX-scaleDrag.cx, e.clientY-scaleDrag.cy)>scaleSlop)){
      scaleDrag.moved=true;
      scaleDrag.pan={x:e.clientX-tx,y:e.clientY-ty};
    }
    if(scaleDrag.moved && scaleDrag.pan){
      try{ e.preventDefault(); }catch(_){}
      tx=e.clientX-scaleDrag.pan.x; ty=e.clientY-scaleDrag.pan.y; applyZoom();
    }else if(scalePts.length===1){
      scaleLive={x2:p.x,y2:p.y};
      updateScaleChip();
      redrawScaleMarkers();
    }
    return;
  }
  if(gcpMode && gcpDrag){
    const p=svgPoint(e);
    const dx=p.x-gcpDrag.px, dy=p.y-gcpDrag.py;
    const gcpSlop=(e.pointerType==="touch"||e.pointerType==="pen")?18:10;
    if(!gcpDrag.moved && (Math.hypot(e.clientX-gcpDrag.cx, e.clientY-gcpDrag.cy)>gcpSlop)){
      gcpDrag.moved=true;
      gcpDrag.pan={x:e.clientX-tx,y:e.clientY-ty};
    }
    if(gcpDrag.moved && gcpDrag.pan){
      try{ e.preventDefault(); }catch(_){}
      tx=e.clientX-gcpDrag.pan.x; ty=e.clientY-gcpDrag.pan.y; applyZoom();
    }
    return;
  }
  if(dockAlignMode && dockAlignDrag){
    try{ e.preventDefault(); }catch(_){}
    if(dockAlignPointers.has(e.pointerId)) dockAlignPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(dockAlignDrag.kind==="pinch" || dockAlignPointers.size>=2){
      if(dockAlignDrag.kind!=="pinch"){
        const dist=dockAlignPinchDist();
        dockAlignDrag={kind:"pinch",keys:dockAlignDrag.keys,startDist:dist,startScale:1,cx:dockAlignDrag.cx,cy:dockAlignDrag.cy,sx:dockAlignDrag.sx||0,sy:dockAlignDrag.sy||0,moved:false};
      }
      const dist=dockAlignPinchDist();
      if(dist && dockAlignDrag.startDist){
        const ratio=dist/dockAlignDrag.startDist;
        if(Math.abs(ratio-1)>0.02) dockAlignDrag.moved=true;
        dockAlignDrag.scaleF=Math.max(0.35, Math.min(2.8, ratio));
        nudgeLayers(dockAlignDrag.sx||0, dockAlignDrag.sy||0, dockAlignDrag.scaleF, dockAlignDrag.cx, dockAlignDrag.cy);
      }
      return;
    }
    const p=svgPoint(e);
    const dx=p.x-dockAlignDrag.px, dy=p.y-dockAlignDrag.py;
    if(Math.abs(dx)+Math.abs(dy)>4) dockAlignDrag.moved=true;
    const c=clampDeltaForBox(dockAlignDrag.startBox||keysBBox(dockAlignDrag.keys), Math.round(dx), Math.round(dy));
    dockAlignDrag.sx=c.dx; dockAlignDrag.sy=c.dy;
    nudgeLayers(dockAlignDrag.sx, dockAlignDrag.sy, 1, dockAlignDrag.cx, dockAlignDrag.cy);
    return;
  }
  if(photoMoveMode && photoDrag){
    try{ e.preventDefault(); }catch(_){}
    if(photoPointers.has(e.pointerId)) photoPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(photoDrag.kind==="pinch" || photoPointers.size>=2){
      if(photoDrag.kind!=="pinch"){
        const dist=photoPinchDist();
        photoDrag={kind:"pinch",startDist:dist,startScaleX:clampPhotoScale(photoAlign.scaleX!=null?photoAlign.scaleX:photoAlign.scale),startScaleY:clampPhotoScale(photoAlign.scaleY!=null?photoAlign.scaleY:photoAlign.scale),moved:false};
      }
      const dist=photoPinchDist();
      if(dist && photoDrag.startDist){
        const ratio=dist/photoDrag.startDist;
        if(Math.abs(ratio-1)>0.02) photoDrag.moved=true;
        photoAlign.scaleX=clampPhotoScale(photoDrag.startScaleX*ratio);
        photoAlign.scaleY=clampPhotoScale(photoDrag.startScaleY*ratio);
        syncPhotoAlignScaleAvg();
        savePhotoAlign(); applyPhotoAlign();
      }
      return;
    }
    const p=svgPoint(e);
    const dx=p.x-photoDrag.px, dy=p.y-photoDrag.py;
    if(Math.abs(dx)+Math.abs(dy)>4) photoDrag.moved=true;
    photoAlign.x=photoDrag.ox+dx;
    photoAlign.y=photoDrag.oy+dy;
    savePhotoAlign(); applyPhotoAlign();
    return;
  }
  if(dockDrag){
    try{ e.preventDefault(); }catch(_){}
    const p=svgPoint(e); const dx=p.x-dockDrag.px, dy=p.y-dockDrag.py;
    if(Math.abs(dx)+Math.abs(dy)>6) dockDrag.moved=true; // slightly looser for fat fingers
    if(dockDrag.kind==="pick"){
      // Finger slid while multi-picking — treat as pan instead of a toggle
      if(dockDrag.moved){
        if(!pan) pan={x:e.clientX-tx, y:e.clientY-ty};
        tx=e.clientX-pan.x; ty=e.clientY-pan.y; applyZoom();
      }
      return;
    }
    if(dockDrag.kind==="chart"){
      const rawX=Math.round(dx), rawY=Math.round(dy);
      const c=clampDeltaForBox(dockDrag.startBox||keysBBox(dockDrag.keys), rawX, rawY);
      dockDrag.sx=c.dx; dockDrag.sy=c.dy;
      // Live nudge ONLY the selection — never translate the whole marina for a partial group
      nudgeSelectionKeys(dockDrag.keys, dockDrag.sx, dockDrag.sy);
      return;
    }
    if(dockDrag.kind==="slip"){
      const d=docks.find(x=>x.id===dockDrag.dockId);
      if(d){
        const c=clampDeltaForBox(dockDrag.startBox||{x:dockDrag.x,y:dockDrag.y,w:10,h:10}, Math.round(dx), Math.round(dy));
        setPlaced(d,dockDrag.id,{x:Math.round(dockDrag.x+c.dx),y:Math.round(dockDrag.y+c.dy)}); redraw();
      }
    }else if(dockDrag.kind==="dock"){
      const d=docks.find(x=>x.id===dockDrag.id);
      if(d){
        const c=clampDeltaForBox(dockDrag.startBox||dockBBox(d), Math.round(dx), Math.round(dy));
        const nx=Math.round(dockDrag.x+c.dx), ny=Math.round(dockDrag.y+c.dy);
        const mdx=nx-d.x, mdy=ny-d.y;
        const g=findGroupFor("dock", d.id);
        if(g){ moveGroupMembers(g, mdx, mdy); }
        else { if(isLocked(d)) moveDockSlips(d,mdx,mdy); d.x=nx; d.y=ny; }
        redraw();
      }
    }else{
      const m=marks.find(x=>x.id===dockDrag.id);
      if(m){
        const c=clampDeltaForBox(dockDrag.startBox||markBBox(m), Math.round(dx), Math.round(dy));
        const nx=Math.round(dockDrag.x+c.dx), ny=Math.round(dockDrag.y+c.dy);
        const mdx=nx-m.x, mdy=ny-m.y;
        const g=findGroupFor("mark", m.id);
        if(g) moveGroupMembers(g, mdx, mdy);
        else { m.x=nx; m.y=ny; }
        redraw();
      }
    }
    return;
  }
  if(!pan) return;
  try{ e.preventDefault(); }catch(_){}
  tx=e.clientX-pan.x; ty=e.clientY-pan.y; applyZoom();
});
chart.addEventListener("pointerup",e=>{
  if(scaleMeasureMode){
    if(scaleDrag){
      if(!scaleDrag.moved){
        placeScaleClick({x:scaleDrag.px, y:scaleDrag.py});
      }
      scaleDrag=null;
    }
    return;
  }
  if(gcpMode){
    if(gcpDrag){
      if(!gcpDrag.moved){
        const p=svgPoint(e);
        // prefer start point for stability
        placeGcpClick({x:gcpDrag.px, y:gcpDrag.py});
      }
      gcpDrag=null;
    }
    return;
  }
  if(dockAlignMode){
    dockAlignPointers.delete(e.pointerId);
    if(dockAlignDrag){
      clearLayerNudge();
      if(dockAlignDrag.moved){
        const keys=dockAlignDrag.keys||allLayoutKeys();
        const sf=dockAlignDrag.scaleF!=null?dockAlignDrag.scaleF:1;
        if(Math.abs(sf-1)>1e-6){
          scaleMembersByKeys(keys, sf, dockAlignDrag.cx, dockAlignDrag.cy);
        }
        if(dockAlignDrag.sx || dockAlignDrag.sy){
          // If we also scaled, translation was applied in pre-scale space via SVG;
          // for pan-only, sx/sy are world deltas. When pinch+pan mixed we only pinch for now.
          if(Math.abs(sf-1)<=1e-6) moveMembersByKeys(keys, dockAlignDrag.sx, dockAlignDrag.sy);
        }
        sanitizeLayout();
        saveLayout();
        redraw();
        renderDockEditor();
      }
    }
    if(dockAlignPointers.size===0) dockAlignDrag=null;
    else dockAlignDrag=null;
    return;
  }
  if(photoMoveMode){
    photoPointers.delete(e.pointerId);
    if(photoDrag && photoDrag.moved) saveLayout(false);
    if(photoPointers.size===0) photoDrag=null;
    else if(photoPointers.size===1){
      // Fall back to pan with remaining finger
      const rem=[...photoPointers.keys()][0];
      // keep last align; next move will restart pan on next pointerdown typically
      photoDrag=null;
    }
    return;
  }
  if(dockDrag){
    if(dockDrag.kind==="pick"){
      if(!dockDrag.moved && dockDrag.tapKey){
        toggleMultiKey(dockDrag.tapKey);
        if(dockDrag.tapSlip){ selected=dockDrag.tapSlip; selectedDock=null; selectedMark=null; }
        else if(dockDrag.tapDock){ selectedDock=dockDrag.tapDock; selectedMark=null; selected=null; }
        else if(dockDrag.tapMark){ selectedMark=dockDrag.tapMark; selectedDock=null; selected=null; }
        else if(dockDrag.tapKey && dockDrag.tapKey.startsWith("slip:")){ selected=dockDrag.tapKey.slice(5); selectedDock=null; selectedMark=null; }

        showTab("layout"); renderDockEditor();
      }
    }else if(dockDrag.kind==="chart"){
      clearSelectionNudge();
      if(dockDrag.fromMultiPick && !dockDrag.moved && dockDrag.tapKey){
        // Tap (not drag) while a multi-selection exists — toggle that piece
        toggleMultiKey(dockDrag.tapKey);
        if(dockDrag.tapSlip){ selected=dockDrag.tapSlip; selectedDock=null; selectedMark=null; }
        else if(dockDrag.tapDock){ selectedDock=dockDrag.tapDock; selectedMark=null; selected=null; }
        else if(dockDrag.tapMark){ selectedMark=dockDrag.tapMark; selectedDock=null; selected=null; }
        else if(dockDrag.tapKey && dockDrag.tapKey.startsWith("slip:")){ selected=dockDrag.tapKey.slice(5); selectedDock=null; selectedMark=null; }

        showTab("layout"); renderDockEditor();
      }else if(dockDrag.moved && (dockDrag.sx || dockDrag.sy)){
        // sx/sy already map-clamped during drag; soft-cap absurd pointer glitches
        const sx=Math.max(-MAP_W, Math.min(MAP_W, dockDrag.sx));
        const sy=Math.max(-MAP_H, Math.min(MAP_H, dockDrag.sy));
        moveMembersByKeys(dockDrag.keys, sx, sy);
        sanitizeLayout();
        saveLayout();
        redraw();
      }
      chart.style.cursor="";
      renderDockEditor();
    }else if(dockDrag.moved){
      sanitizeLayout();
      saveLayout(); renderDockEditor();
    }
  }
  dockDrag=null; pan=null;
});
chart.addEventListener("wheel",e=>{
  e.preventDefault();
  const r=chart.getBoundingClientRect();
  const cx=e.clientX-r.left, cy=e.clientY-r.top;
  zoomToward(cx, cy, e.deltaY<0?1.08:0.92);
},{passive:false});
function panBy(dx,dy){
  tx+=dx; ty+=dy; applyZoom();
}
function panStep(){
  // ~1/5 of the visible chart per tap — readable nudge when zoomed in
  const {w,h}=chartSize();
  return {x:Math.max(60, Math.round(w*0.22)), y:Math.max(60, Math.round(h*0.22))};
}
function bindHold(btn, fn){
  if(!btn) return;
  let timer=null, repeating=false;
  const start=e=>{
    e.preventDefault();
    fn();
    repeating=false;
    timer=setTimeout(function tick(){
      repeating=true; fn();
      timer=setTimeout(tick, 70);
    }, 320);
  };
  const stop=()=>{ if(timer){ clearTimeout(timer); timer=null; } };
  btn.addEventListener("pointerdown", start);
  btn.addEventListener("pointerup", stop);
  btn.addEventListener("pointerleave", stop);
  btn.addEventListener("pointercancel", stop);
  // Prevent the synthetic click from double-firing after a hold
  btn.addEventListener("click", e=>{ e.preventDefault(); });
}
document.getElementById("z-in").onclick=()=>{ const {w,h}=chartSize(); zoomToward(w/2,h/2,1.15); };
document.getElementById("z-out").onclick=()=>{ const {w,h}=chartSize(); zoomToward(w/2,h/2,1/1.15); };
document.getElementById("z-full").onclick=()=>fitWholeMap();
bindHold(document.getElementById("pan-left"), ()=>{ const s=panStep(); panBy(s.x,0); });
bindHold(document.getElementById("pan-right"), ()=>{ const s=panStep(); panBy(-s.x,0); });
bindHold(document.getElementById("pan-up"), ()=>{ const s=panStep(); panBy(0,s.y); });
bindHold(document.getElementById("pan-down"), ()=>{ const s=panStep(); panBy(0,-s.y); });
const panCenter=document.getElementById("pan-center");
if(panCenter) panCenter.onclick=()=>fitWholeMap();
// Initial view: zoomed in for reading slips; use ⛶ to see whole map on one page
requestAnimationFrame(()=>requestAnimationFrame(()=>{ if(deepZoom) fitWholeMap(); else defaultMarinaZoom(); }));
window.addEventListener("resize",()=>{
  // After flex shell reflow, chart getBoundingClientRect changes — re-apply zoom band
  if(scale<minZoomScale()) scale=minZoomScale();
  applyZoom();
  try{ if(document.body.classList.contains("editing")) syncEditChromeHeight(); }catch(e){}
});
document.querySelectorAll("#pane-slip .st button").forEach(b=>b.onclick=()=>{if(!selected)return; if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){ blockEdit(); return; }data[selected]=data[selected]||{};data[selected].status=b.dataset.st;save(data);select(selected);});
["boat","notes"].forEach(fid=>document.getElementById(fid).addEventListener("input",()=>{if(!selected)return; if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){ blockEdit(); return; }data[selected]=data[selected]||{status:"vacant"};data[selected][fid]=document.getElementById(fid).value;save(data);renderDir();}));
document.getElementById("q").addEventListener("input",function(){const hit=slips.find(s=>String(s.num)===this.value.trim());if(hit)select(hit.id);});
document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
function renderDir(){const list=document.getElementById("dir-list");const rows=Object.keys(data).map(id=>({id,...data[id]})).filter(r=>r.boat||r.notes||(r.status&&r.status!=="vacant"));if(!rows.length){list.innerHTML="<p>No marked slips yet.</p>";return;}list.innerHTML=rows.map(r=>`<div class="dir-item" data-jump="${r.id}"><b>${/^\d+$/.test(r.id)?"Slip "+r.id:r.id}</b> · ${r.status||""}<br>${r.boat||""} ${r.notes||""}</div>`).join("");list.querySelectorAll("[data-jump]").forEach(n=>n.onclick=()=>select(n.dataset.jump));}
renderDir();


function mobileAligning(){
  return document.body.classList.contains("gcp-aligning")||document.body.classList.contains("photo-moving")||document.body.classList.contains("dock-aligning")||document.body.classList.contains("scale-measuring");
}
function mobileShowAdjustSheet(){
  if(!isMobileEdit()||mobileAligning()) return;
  openEditPanel();
}
function ensureSelectionInView(){
  if(!isMobileEdit()||!document.body.classList.contains("editing")) return;
  let x=null,y=null;
  try{
    if(selectedDock){ const d=docks.find(z=>z.id===selectedDock); if(d){ x=d.x; y=d.y; } }
    else if(selectedMark){ const m=marks.find(z=>z.id===selectedMark); if(m){ x=m.x; y=m.y; } }
    else if(selected){ const s=slips.find(z=>z.id===selected); if(s){ x=s.x; y=s.y; } }
  }catch(e){ return; }
  if(x==null||y==null) return;
  const {w,h}=chartSize();
  const sx=tx+x*scale, sy=ty+y*scale;
  const m=28;
  let dx=0,dy=0;
  if(sx<m) dx=m-sx; else if(sx>w-m) dx=(w-m)-sx;
  if(sy<m) dy=m-sy; else if(sy>h-m) dy=(h*0.42)-sy;
  if(dx||dy){ tx+=dx; ty+=dy; applyZoom(); }
}
function refreshMobileEditLayout(){
  requestAnimationFrame(()=>{
    try{ syncEditChromeHeight(); }catch(e){}
    requestAnimationFrame(()=>{ try{ ensureSelectionInView(); }catch(e){} });
  });
}
function noteAlignModeForMobile(){
  if(!isMobileEdit()) return;
  if(mobileAligning()) closeEditPanel();
  refreshMobileEditLayout();
}

function setEditPanelOpen(on){
  document.body.classList.toggle("panel-open", !!on);
  if(on){
    const aside=document.querySelector("aside"); if(aside && isMobileEdit()) aside.scrollTop=0;
    if(isMobileEdit()){
      stretchToolsOpen=false;
      document.body.classList.remove("stretch-open","photo-tools-open");
      const sb=document.getElementById("btn-stretch-toggle"); if(sb) sb.classList.remove("on");
      const pb=document.getElementById("btn-photo-tools"); if(pb) pb.classList.remove("on");
    }
  }
  const b=document.getElementById("btn-panel-toggle");
  if(b){ b.classList.toggle("on", !!on); b.textContent = on ? "Map" : "Tools"; }
  const fab=document.getElementById("edit-fab-tools");
  if(fab){ fab.classList.toggle("on", !!on); fab.textContent = on ? "Map" : "Tools"; }
  requestAnimationFrame(()=>{ try{ syncEditChromeHeight(); ensureSelectionInView(); }catch(e){} });
}
function openEditPanel(){ if(window.matchMedia && window.matchMedia("(max-width:860px)").matches) setEditPanelOpen(true); }
function isMobileEdit(){ return !!(window.matchMedia && window.matchMedia("(max-width:860px)").matches); }
function closeEditPanel(){ setEditPanelOpen(false); }
document.getElementById("edit-toggle").onclick=()=>{ if(blockEdit()) return;
  editing=!editing;
  document.body.classList.toggle("editing",editing);
  document.documentElement.classList.toggle("editing",editing);
  chart.classList.toggle("editing",editing);
  document.getElementById("edit-toggle").classList.toggle("on",editing);
  document.getElementById("edit-toggle").textContent=editing?"Done editing":"Edit docks";
  const em=document.getElementById("edit-toggle-mobile");
  if(em){ em.classList.toggle("on",editing); em.textContent="Done"; }
  const es=document.getElementById("edit-toggle-sticky");
  if(es){ es.classList.toggle("on",editing); es.textContent=editing?"Done editing":"Edit docks"; }
  if(!editing){ multiPick=false; closeEditPanel(); stretchToolsOpen=false; document.body.classList.remove("stretch-open","photo-tools-open"); ["--edit-chrome-h","--edit-photo-op-h","--edit-label-h","--edit-align-h","--edit-top","--edit-sheet-h"].forEach(k=>document.documentElement.style.removeProperty(k)); if(dockAlignMode) setDockAlignMode(false); if(photoMoveMode) setPhotoMoveMode(false); if(gcpMode) setGcpMode(false); if(scaleMeasureMode) setScaleMeasureMode(false); }
  document.getElementById("hint").textContent=editing
    ? (window.matchMedia("(max-width:860px)").matches
        ? "Tools = panel · drag docks · empty water pans · Done exits"
        : (multiPick?"Multi-select on · tap docks/slips/labels":(moveWholeChart||multi.size>1?"Drag selected pieces to move the group · tap to add/remove · empty water pans · Ungroup/Unlock this dock to edit":"Drag docks/labels · use Dock panel on the right · empty water pans")))
    : "Click a numbered slip · drag to pan";
  if(editing){
    showTab("layout");
    if(isMobileEdit()) closeEditPanel(); /* mobile: map full-screen until Tools */
    /* desktop: leave side panel visible — do not force sheet behavior */
  }
  updateSelHint(); updateSelChip(); syncMapBoundVisual(); redraw(); applyDeepZoomLod();
  // reflow zoom after layout change + pin chrome height so map never covers Tools/Done
  requestAnimationFrame(()=>{ try{ syncEditChromeHeight(); applyZoom(); }catch(e){} });
};

function syncEditChromeHeight(){
  const chrome=document.getElementById("edit-chrome");
  if(!chrome || !document.body.classList.contains("editing")) return;
  const root=document.documentElement;
  const chromeH=Math.ceil(chrome.getBoundingClientRect().height)||56;
  root.style.setProperty("--edit-chrome-h", chromeH+"px");
  // Mobile: Align / Photo / Label bars stay fixed under chrome — reserve space so map is not covered
  let opH=0, labH=0, alignH=0;
  if(isMobileEdit()){
    const op=document.getElementById("photo-op-bar");
    const lab=document.getElementById("label-size-bar");
    const al=document.getElementById("photo-align-bar");
    const vis=el=>{
      if(!el) return 0;
      const st=window.getComputedStyle(el);
      if(st.display==="none" || st.visibility==="hidden") return 0;
      return Math.ceil(el.getBoundingClientRect().height)||0;
    };
    opH=vis(op); labH=vis(lab); alignH=vis(al);
  }
  root.style.setProperty("--edit-photo-op-h", opH+"px");
  root.style.setProperty("--edit-label-h", labH+"px");
  root.style.setProperty("--edit-align-h", alignH+"px");
  root.style.setProperty("--edit-top", (chromeH+opH+labH+alignH)+"px");
  let sheetH=0;
  if(isMobileEdit() && document.body.classList.contains("panel-open")){
    const aside=document.querySelector("aside");
    if(aside){
      const cap=Math.round((window.visualViewport&&window.visualViewport.height||window.innerHeight)*0.40);
      const h=Math.ceil(aside.getBoundingClientRect().height)||0;
      sheetH=Math.max(0, Math.min(h||cap, cap));
    }
  }
  root.style.setProperty("--edit-sheet-h", sheetH+"px");
}
function wireMobileEditChrome(){
  const map={
    "btn-undo-m":"btn-undo",
    "btn-redo-m":"btn-redo",
    "btn-save-m":"btn-save",
    "btn-save-sticky":"btn-save",
    "edit-toggle-mobile":"edit-toggle",
    "edit-toggle-sticky":"edit-toggle"
  };
  Object.keys(map).forEach(id=>{
    const src=document.getElementById(id);
    const dst=document.getElementById(map[id]);
    if(src && dst) src.onclick=()=> dst.click();
  });
  let wasMobile=isMobileEdit();
  window.addEventListener("resize", ()=>{
    const now=isMobileEdit();
    if(document.body.classList.contains("editing")){
      if(now!==wasMobile){ wasMobile=now; try{ renderDockEditor(); }catch(e){} }
      syncEditChromeHeight();
    }else wasMobile=now;
  });
  const stretchBtn=document.getElementById("btn-stretch-toggle");
  if(stretchBtn) stretchBtn.onclick=()=>{
    stretchToolsOpen=!stretchToolsOpen;
    document.body.classList.toggle("stretch-open", stretchToolsOpen);
    stretchBtn.classList.toggle("on", stretchToolsOpen);
    if(stretchToolsOpen && isMobileEdit()){
      document.body.classList.remove("photo-tools-open");
      const pb=document.getElementById("btn-photo-tools"); if(pb) pb.classList.remove("on");
      closeEditPanel();
    }
    refreshMobileEditLayout();
  };
  const photoBtn=document.getElementById("btn-photo-tools");
  if(photoBtn) photoBtn.onclick=()=>{
    const on=!document.body.classList.contains("photo-tools-open");
    document.body.classList.toggle("photo-tools-open", on);
    photoBtn.classList.toggle("on", on);
    if(on && isMobileEdit()){
      stretchToolsOpen=false;
      document.body.classList.remove("stretch-open");
      if(stretchBtn) stretchBtn.classList.remove("on");
      closeEditPanel();
    }
    refreshMobileEditLayout();
  };
}
wireMobileEditChrome();

const _btnPanel=document.getElementById("btn-panel-toggle");
if(_btnPanel) _btnPanel.onclick=()=> setEditPanelOpen(!document.body.classList.contains("panel-open"));
const _btnSheetClose=document.getElementById("btn-sheet-close");
if(_btnSheetClose) _btnSheetClose.onclick=()=> closeEditPanel();
const _sheetHandle=document.getElementById("sheet-handle");
if(_sheetHandle) _sheetHandle.addEventListener("click", e=>{
  if(e.target.closest("button")) return;
  setEditPanelOpen(!document.body.classList.contains("panel-open"));
});
(function wireEditFabs(){
  const fabTools=document.getElementById("edit-fab-tools");
  const fabDone=document.getElementById("edit-fab-done");
  const peek=document.getElementById("edit-tools-peek");
  if(fabTools) fabTools.onclick=()=> setEditPanelOpen(!document.body.classList.contains("panel-open"));
  if(fabDone) fabDone.onclick=()=>{ const t=document.getElementById("edit-toggle"); if(t) t.click(); };
  if(peek) peek.onclick=()=> setEditPanelOpen(true);
})();


/** Ground Control Point (GCP) alignment — move docks onto aerial. */
function fitSimilarity(pairs){
  const n=(pairs||[]).length;
  if(n<2) return null;
  let ax=0,ay=0,bx=0,by=0;
  for(const p of pairs){ ax+=Number(p.ax)||0; ay+=Number(p.ay)||0; bx+=Number(p.bx)||0; by+=Number(p.by)||0; }
  ax/=n; ay/=n; bx/=n; by/=n;
  let sumAxBx=0,sumAyBx=0,sumAxBy=0,sumAyBy=0,sumA2=0;
  for(const p of pairs){
    const Ax=(Number(p.ax)||0)-ax, Ay=(Number(p.ay)||0)-ay;
    const Bx=(Number(p.bx)||0)-bx, By=(Number(p.by)||0)-by;
    sumAxBx+=Ax*Bx; sumAyBx+=Ay*Bx; sumAxBy+=Ax*By; sumAyBy+=Ay*By;
    sumA2+=Ax*Ax+Ay*Ay;
  }
  if(sumA2<1e-12) return null;
  const ang=Math.atan2(sumAxBy-sumAyBx, sumAxBx+sumAyBy);
  const cos=Math.cos(ang), sin=Math.sin(ang);
  let num=0;
  for(const p of pairs){
    const Ax=(Number(p.ax)||0)-ax, Ay=(Number(p.ay)||0)-ay;
    const Bx=(Number(p.bx)||0)-bx, By=(Number(p.by)||0)-by;
    num+=Bx*(cos*Ax-sin*Ay)+By*(sin*Ax+cos*Ay);
  }
  let s=num/sumA2;
  if(!isFinite(s) || s<=0) s=1;
  s=Math.max(0.2, Math.min(5, s));
  const a=s*cos, b=-s*sin, d=s*sin, e=s*cos;
  const c=bx-(a*ax+b*ay);
  const f=by-(d*ax+e*ay);
  return {kind:"similarity", a,b,c,d,e,f, s, rotDeg:ang*180/Math.PI};
}
function solveLeastSquares3(rows){
  // Solve x*a + y*b + 1*c = rhs via normal equations
  const A=[[0,0,0],[0,0,0],[0,0,0]];
  const B=[0,0,0];
  for(const r of rows){
    const x=Number(r.x)||0, y=Number(r.y)||0, rhs=Number(r.rhs)||0;
    const row=[x,y,1];
    for(let i=0;i<3;i++){
      B[i]+=row[i]*rhs;
      for(let j=0;j<3;j++) A[i][j]+=row[i]*row[j];
    }
  }
  // Gaussian elimination with partial pivot
  const M=[A[0].concat(B[0]), A[1].concat(B[1]), A[2].concat(B[2])];
  for(let col=0; col<3; col++){
    let piv=col;
    for(let r=col+1;r<3;r++) if(Math.abs(M[r][col])>Math.abs(M[piv][col])) piv=r;
    if(Math.abs(M[piv][col])<1e-12) return null;
    if(piv!==col){ const t=M[col]; M[col]=M[piv]; M[piv]=t; }
    const div=M[col][col];
    for(let j=col;j<4;j++) M[col][j]/=div;
    for(let r=0;r<3;r++){
      if(r===col) continue;
      const f=M[r][col];
      for(let j=col;j<4;j++) M[r][j]-=f*M[col][j];
    }
  }
  return [M[0][3], M[1][3], M[2][3]];
}
function fitAffine(pairs){
  const n=(pairs||[]).length;
  if(n<3) return fitSimilarity(pairs);
  const rowsX=pairs.map(p=>({x:p.ax,y:p.ay,rhs:p.bx}));
  const rowsY=pairs.map(p=>({x:p.ax,y:p.ay,rhs:p.by}));
  const abc=solveLeastSquares3(rowsX);
  const defv=solveLeastSquares3(rowsY);
  if(!abc || !defv) return fitSimilarity(pairs);
  const [a,b,c]=abc, [d,e,f]=defv;
  if(![a,b,c,d,e,f].every(v=>isFinite(v))) return fitSimilarity(pairs);
  const det=a*e-b*d;
  if(Math.abs(det)<1e-8) return fitSimilarity(pairs);
  const sx=Math.hypot(a,d), sy=Math.hypot(b,e);
  if(sx<0.15||sx>6||sy<0.15||sy>6) return fitSimilarity(pairs);
  // Prefer similarity when nearly similarity (shear tiny)
  const shear=Math.abs(a*b+d*e)/(sx*sy+1e-12);
  if(shear>0.35){
    // still allow affine if stable
  }
  const rotDeg=Math.atan2(d,a)*180/Math.PI;
  return {kind:"affine", a,b,c,d,e,f, s:(sx+sy)/2, rotDeg};
}
function fitGcpTransform(pairs){
  if(!pairs || pairs.length<2) return null;
  const sim=fitSimilarity(pairs);
  if(pairs.length>=3){
    const aff=fitAffine(pairs);
    // Prefer similarity so dock sw/sh/gap actually scale onto the aerial.
    // Only keep affine when shear is meaningful (otherwise similarity is stabler & scales sizes).
    if(aff && aff.kind==="affine"){
      const sx=Math.hypot(aff.a,aff.d), sy=Math.hypot(aff.b,aff.e);
      const shear=Math.abs(aff.a*aff.b+aff.d*aff.e)/(sx*sy+1e-12);
      if(shear>0.12) return aff;
    }
  }
  return sim;
}
function transformPoint(x,y,T){
  x=Number(x)||0; y=Number(y)||0;
  if(!T) return {x,y};
  return {x:T.a*x+T.b*y+T.c, y:T.d*x+T.e*y+T.f};
}
function normalizeRotDeg(v){
  let r=((Number(v)%360)+360)%360;
  if(r>180) r-=360;
  if(Math.abs(r)<0.01) r=0;
  return r;
}
function applyGcpTransformToDock(d, T, opts){
  if(!d || !T) return;
  const updateRot=!(opts && opts.updateRot===false);
  const p=transformPoint(d.x, d.y, T);
  d.x=p.x; d.y=p.y;
  // Scale dock geometry for BOTH similarity and low-shear affine (T.s = average scale).
  const s = (T.s!=null && isFinite(T.s) && T.s>0) ? T.s : 1;
  if(Math.abs(s-1)>1e-6){
    ["sw","sh","w","h","gap"].forEach(prop=>{ if(d[prop]!=null) d[prop]=Number(d[prop])*s; });
    (d.extras||[]).forEach(ex=>{
      if(ex.dx!=null) ex.dx=Number(ex.dx)*s;
      if(ex.dy!=null) ex.dy=Number(ex.dy)*s;
      if(ex.w!=null) ex.w=Number(ex.w)*s;
      if(ex.h!=null) ex.h=Number(ex.h)*s;
    });
  }
  if(d.placed){
    Object.keys(d.placed).forEach(id=>{
      const pl=d.placed[id]; if(!pl) return;
      if(pl.x!=null && pl.y!=null){
        const q=transformPoint(pl.x, pl.y, T);
        pl.x=q.x; pl.y=q.y;
      }
      if(Math.abs(s-1)>1e-6){
        if(pl.w!=null) pl.w=Number(pl.w)*s;
        if(pl.h!=null) pl.h=Number(pl.h)*s;
      }
      if(updateRot && T.rotDeg!=null && isFinite(T.rotDeg) && Math.abs(T.rotDeg)>0.05){
        pl.rot=normalizeRotDeg((Number(pl.rot)||0)+T.rotDeg);
      }
    });
  }
  if(updateRot && T.rotDeg!=null && isFinite(T.rotDeg) && Math.abs(T.rotDeg)>0.05){
    d.rot=normalizeRotDeg((Number(d.rot)||0)+T.rotDeg);
  }
}
function applyGcpTransformToMark(m, T, opts){
  if(!m || !T) return;
  const updateRot=!(opts && opts.updateRot===false);
  const p=transformPoint(m.x, m.y, T);
  m.x=p.x; m.y=p.y;
  const s = (T.s!=null && isFinite(T.s) && T.s>0) ? T.s : 1;
  if(Math.abs(s-1)>1e-6){
    if(m.w!=null) m.w=Number(m.w)*s;
    if(m.h!=null) m.h=Number(m.h)*s;
    if(m.size!=null) m.size=Number(m.size)*s;
  }
  if(updateRot && T.rotDeg!=null && isFinite(T.rotDeg) && Math.abs(T.rotDeg)>0.05){
    m.rot=normalizeRotDeg((Number(m.rot)||0)+T.rotDeg);
  }
}
function loadGcpPairs(){
  try{
    const raw=JSON.parse(localStorage.getItem(GCP_STORE)||"null");
    if(Array.isArray(raw)){
      gcpPairs=raw.filter(p=>p && isFinite(p.ax)&&isFinite(p.ay)&&isFinite(p.bx)&&isFinite(p.by))
        .map(p=>({ax:+p.ax,ay:+p.ay,bx:+p.bx,by:+p.by}));
    }
  }catch(e){}
}
function saveGcpPairs(){
  try{ localStorage.setItem(GCP_STORE, JSON.stringify(gcpPairs||[])); }catch(e){}
}
function clearGcpPairs(persist){
  gcpPairs=[]; gcpPending=null;
  if(persist!==false) saveGcpPairs();
  updateGcpChip();
  redrawGcpMarkers();
}
let gcpLayer=null;
function ensureGcpLayer(){
  if(!svg) return null;
  if(!gcpLayer || gcpLayer.parentNode!==svg){
    gcpLayer=el("g",{id:"gcp-layer", "pointer-events":"none"});
    svg.appendChild(gcpLayer);
  }
  return gcpLayer;
}
function redrawGcpMarkers(){
  const g=ensureGcpLayer();
  if(!g) return;
  g.innerHTML="";
  if(!gcpMode && !(gcpPairs&&gcpPairs.length)) return;
  if(!gcpMode) return;
  const r=Math.max(6, 10/Math.max(0.25, scale));
  gcpPairs.forEach((p,i)=>{
    const n=i+1;
    g.appendChild(el("line",{x1:p.ax,y1:p.ay,x2:p.bx,y2:p.by,stroke:"#ffd166", "stroke-width":Math.max(1,2/Math.max(0.25,scale)), opacity:"0.85"}));
    g.appendChild(el("circle",{cx:p.ax,cy:p.ay,r:r,fill:"#3a86ff", stroke:"#fff", "stroke-width":1.5}));
    g.appendChild(el("text",{x:p.ax,y:p.ay-r-2,"text-anchor":"middle",fill:"#3a86ff","font-size":Math.max(10,12/Math.max(0.25,scale)),"font-weight":"700"}, "A"+n));
    g.appendChild(el("circle",{cx:p.bx,cy:p.by,r:r,fill:"#f4a261", stroke:"#fff", "stroke-width":1.5}));
    g.appendChild(el("text",{x:p.bx,y:p.by-r-2,"text-anchor":"middle",fill:"#f4a261","font-size":Math.max(10,12/Math.max(0.25,scale)),"font-weight":"700"}, "B"+n));
  });
  if(gcpPending){
    g.appendChild(el("circle",{cx:gcpPending.ax,cy:gcpPending.ay,r:r,fill:"#3a86ff", stroke:"#fff", "stroke-width":1.5, opacity:"0.7"}));
    g.appendChild(el("text",{x:gcpPending.ax,y:gcpPending.ay-r-2,"text-anchor":"middle",fill:"#3a86ff","font-size":Math.max(10,12/Math.max(0.25,scale)),"font-weight":"700"}, "A?"));
  }
  // keep on top
  svg.appendChild(g);
  if(mapBoundRect && mapBoundRect.parentNode===svg) svg.appendChild(mapBoundRect);
}
function updateGcpChip(){
  const countEl=document.getElementById("gcp-pair-count");
  if(countEl) countEl.textContent=(gcpPairs.length||0)+" pair"+(gcpPairs.length===1?"":"s");
  const applyAll=document.getElementById("gcp-apply-all");
  const applySel=document.getElementById("gcp-apply-selected");
  const ready=gcpPairs.length>=2;
  if(applyAll) applyAll.disabled=!ready;
  if(applySel) applySel.disabled=!ready;
}
function setGcpMode(on){
  if(!IS_LAYOUT_SOURCE){ gcpMode=false; return; }
  gcpMode=!!on;
  if(gcpMode){
    if(photoMoveMode) setPhotoMoveMode(false);
    if(dockAlignMode) setDockAlignMode(false);
    if(scaleMeasureMode) setScaleMeasureMode(false);
    if(!editing){
      const t=document.getElementById("edit-toggle");
      if(t) t.click();
    }
    gcpDrag=null;
  }else{
    gcpDrag=null;
    gcpPending=null;
  }
  document.body.classList.toggle("gcp-aligning", gcpMode);
  const btn=document.getElementById("btn-gcp-align");
  if(btn){
    btn.classList.toggle("on", gcpMode);
    btn.textContent=gcpMode?"Done GCP":"GCP align";
  }
  const chip=document.getElementById("gcp-align-chip");
  if(chip) chip.hidden=!gcpMode;
  updateGcpChip();
  const hint=document.getElementById("hint");
  if(hint){
    if(gcpMode) hint.textContent="GCP align — tap dock corner (A), then matching aerial spot (B) · 2+ pairs to Apply";
    else if(photoMoveMode) hint.textContent="Moving photo — drag to pan, Stretch width/height or pinch · docks locked";
    else if(dockAlignMode) hint.textContent="Aligning docks — drag to pan, pinch or −/+ to scale · photo locked";
    else if(editing) hint.textContent="Edit docks · drag pieces · empty water pans";
  }
  chart.style.cursor=gcpMode?"crosshair":(photoMoveMode?"move":(dockAlignMode?"grab":""));
  redrawGcpMarkers();
  try{ applyDeepZoomLod(); }catch(e){}
  try{ noteAlignModeForMobile(); }catch(e){}
}
function placeGcpClick(p){
  if(!gcpMode || !p) return;
  if(!gcpPending){
    gcpPending={ax:p.x, ay:p.y};
  }else{
    gcpPairs.push({ax:gcpPending.ax, ay:gcpPending.ay, bx:p.x, by:p.y});
    gcpPending=null;
    saveGcpPairs();
  }
  updateGcpChip();
  redrawGcpMarkers();
}
function undoLastGcpPair(){
  if(gcpPending){ gcpPending=null; updateGcpChip(); redrawGcpMarkers(); return; }
  if(!gcpPairs.length) return;
  gcpPairs.pop();
  saveGcpPairs();
  updateGcpChip();
  redrawGcpMarkers();
}
function applyGcpToTargets(scope){
  if(!IS_LAYOUT_SOURCE) return;
  if(!gcpMode && !(gcpPairs&&gcpPairs.length>=2)) return;
  if(gcpPairs.length<2){ alert("Need at least 2 GCP pairs before Apply."); return; }
  const T=fitGcpTransform(gcpPairs);
  if(!T){ alert("Could not fit a stable transform from these pairs."); return; }
  if(scope==="selected"){
    if(!selectedDock){ alert("Select a dock first (or use Apply to all docks)."); return; }
    const d=docks.find(x=>x.id===selectedDock);
    if(!d){ alert("Selected dock not found."); return; }
    applyGcpTransformToDock(d, T);
  }else{
    docks.forEach(d=>applyGcpTransformToDock(d, T));
    marks.forEach(m=>applyGcpTransformToMark(m, T));
  }
  sanitizeLayout();
  saveLayout(true);
  clearGcpPairs(true);
  redraw();
  renderDockEditor();
  const hint=document.getElementById("hint");
  if(hint) hint.textContent="GCP applied ("+T.kind+") · Undo in header if needed";
}

function setPhotoMoveMode(on){
  photoMoveMode=!!on;
  if(photoMoveMode && dockAlignMode) setDockAlignMode(false);
  if(photoMoveMode && gcpMode) setGcpMode(false);
  if(photoMoveMode && scaleMeasureMode) setScaleMeasureMode(false);
  if(!photoMoveMode){
    photoDrag=null;
    photoPointers.clear();
  }
  document.body.classList.toggle("photo-moving", photoMoveMode);
  const btn=document.getElementById("btn-photo-move");
  if(btn){
    btn.classList.toggle("on", photoMoveMode);
    btn.textContent=photoMoveMode?"Done moving photo":"Move photo";
  }
  const chip=document.getElementById("photo-move-chip");
  if(chip) chip.hidden=!photoMoveMode;
  const hint=document.getElementById("hint");
  if(hint){
    if(photoMoveMode) hint.textContent="Moving photo — drag to pan, Stretch width/height or pinch · docks locked";
    else if(gcpMode) hint.textContent="GCP align — tap dock corner (A), then matching aerial spot (B) · 2+ pairs to Apply";
    else if(dockAlignMode) hint.textContent="Aligning docks — drag to pan, pinch or −/+ to scale · photo locked";
    else if(editing) hint.textContent="Edit docks · drag pieces · empty water pans";
  }
  chart.style.cursor=photoMoveMode?"move":(gcpMode?"crosshair":(dockAlignMode?"grab":""));
  try{ applyDeepZoomLod(); }catch(e){}
  try{ noteAlignModeForMobile(); }catch(e){}
}
function setDockAlignMode(on){
  dockAlignMode=!!on;
  if(dockAlignMode){
    if(photoMoveMode) setPhotoMoveMode(false);
    if(gcpMode) setGcpMode(false);
    if(scaleMeasureMode) setScaleMeasureMode(false);
    if(!editing){
      const t=document.getElementById("edit-toggle");
      if(t) t.click();
    }
    // Treat whole layout as one group under the photo
    selectAllLayout();
    clearLayerNudge();
    dockAlignDrag=null;
    dockAlignPointers.clear();
  }else{
    clearLayerNudge();
    dockAlignDrag=null;
    dockAlignPointers.clear();
  }
  document.body.classList.toggle("dock-aligning", dockAlignMode);
  const btn=document.getElementById("btn-dock-align");
  if(btn){
    btn.classList.toggle("on", dockAlignMode);
    btn.textContent=dockAlignMode?"Done aligning":"Align docks to photo";
  }
  const chip=document.getElementById("dock-align-chip");
  if(chip) chip.hidden=!dockAlignMode;
  const hint=document.getElementById("hint");
  if(hint){
    if(dockAlignMode) hint.textContent="Aligning docks — drag to pan, pinch or −/+ to scale · photo locked · labels stay readable";
    else if(gcpMode) hint.textContent="GCP align — tap dock corner (A), then matching aerial spot (B) · 2+ pairs to Apply";
    else if(photoMoveMode) hint.textContent="Moving photo — drag to pan, Stretch width/height or pinch · docks locked";
    else if(editing) hint.textContent="Edit docks · drag pieces · empty water pans";
  }
  chart.style.cursor=dockAlignMode?"grab":(gcpMode?"crosshair":(photoMoveMode?"move":""));
  try{ noteAlignModeForMobile(); }catch(e){}
}
function photoPinchDist(){
  const pts=[...photoPointers.values()];
  if(pts.length<2) return null;
  const dx=pts[0].x-pts[1].x, dy=pts[0].y-pts[1].y;
  return Math.hypot(dx,dy)||null;
}
function dockAlignPinchDist(){
  const pts=[...dockAlignPointers.values()];
  if(pts.length<2) return null;
  const dx=pts[0].x-pts[1].x, dy=pts[0].y-pts[1].y;
  return Math.hypot(dx,dy)||null;
}

/* ===== Scale / measurements calculator (laceys-scale-v1) ===== */
function canEditScaleCalibrate(){
  // MAIN + share (edit tools) can calibrate; view/layersedit read-only
  if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY) return false;
  if(typeof LAYERS_EDIT_ONLY!=="undefined" && LAYERS_EDIT_ONLY) return false;
  return true;
}
function canApplyScaleToDock(){
  return typeof IS_LAYOUT_SOURCE!=="undefined" && IS_LAYOUT_SOURCE;
}
function loadChartScale(){
  try{
    const raw=JSON.parse(localStorage.getItem(SCALE_STORE)||"null");
    if(raw && typeof raw==="object"){
      const cupf=Number(raw.chartUnitsPerFoot);
      const fpcu=Number(raw.feetPerChartUnit);
      if(isFinite(cupf) && cupf>0){
        chartScaleCal={chartUnitsPerFoot:cupf, feetPerChartUnit:(isFinite(fpcu)&&fpcu>0)?fpcu:(1/cupf)};
      }
    }
  }catch(e){}
}
function saveChartScale(){
  try{
    if(chartScaleCal.chartUnitsPerFoot==null){
      localStorage.removeItem(SCALE_STORE);
    }else{
      localStorage.setItem(SCALE_STORE, JSON.stringify({
        chartUnitsPerFoot:chartScaleCal.chartUnitsPerFoot,
        feetPerChartUnit:chartScaleCal.feetPerChartUnit
      }));
    }
  }catch(e){}
}
function clearChartScale(){
  chartScaleCal={chartUnitsPerFoot:null,feetPerChartUnit:null};
  saveChartScale();
  updateScaleReadout();
  updateScaleChip();
  redrawScaleMarkers();
}
function setChartScaleFromDistance(distChart, feet){
  const f=Number(feet);
  const d=Number(distChart);
  if(!(f>0) || !(d>0)) return false;
  const cupf=d/f;
  chartScaleCal={chartUnitsPerFoot:cupf, feetPerChartUnit:1/cupf};
  saveChartScale();
  updateScaleReadout();
  return true;
}
function fmtNum(n, digits){
  if(!isFinite(n)) return "—";
  const d=digits!=null?digits:2;
  const s=Number(n).toFixed(d);
  return s.replace(/\.?0+$/,"");
}
function updateScaleReadout(){
  const el=document.getElementById("scale-calib-readout");
  if(!el) return;
  const cupf=chartScaleCal.chartUnitsPerFoot;
  if(cupf==null || !(cupf>0)){
    el.textContent="Not calibrated yet — click Calibrate, then two points spanning a known distance (e.g. one slip length).";
  }else{
    el.textContent="1 ft ≈ "+fmtNum(cupf,3)+" chart units · 1 chart unit ≈ "+fmtNum(1/cupf,4)+" ft";
  }
  // gate apply / calibrate buttons
  const apply=document.getElementById("btn-scale-apply");
  if(apply){
    apply.disabled=!canApplyScaleToDock();
    apply.title=canApplyScaleToDock()?"Write primary slip sw/sh (and gap from divider) onto selected dock":"Apply only on MAIN editable chart";
  }
  const actions=document.getElementById("scale-calib-actions");
  if(actions){
    if(!canEditScaleCalibrate()){
      actions.querySelectorAll("button").forEach(b=>{ b.disabled=true; b.title="Read-only on this copy — calibrate on MAIN or Share"; });
    }
  }
  const panel=document.getElementById("scale-panel");
  if(panel && (typeof VIEW_ONLY!=="undefined" && VIEW_ONLY || typeof LAYERS_EDIT_ONLY!=="undefined" && LAYERS_EDIT_ONLY)){
    // keep panel for recipe + readout; calibrate disabled above
  }
}
function updateScaleChip(){
  const st=document.getElementById("scale-measure-status");
  if(!st) return;
  const cupf=chartScaleCal.chartUnitsPerFoot;
  if(scalePts.length===0){
    st.textContent=scaleForceCalibrate?"Calibrate: click first point":"Click first point";
  }else if(scalePts.length===1){
    let live="";
    if(scaleLive.x2!=null){
      const d=Math.hypot(scaleLive.x2-scalePts[0].x, scaleLive.y2-scalePts[0].y);
      live=" · "+fmtNum(d,1)+" cu";
      if(cupf>0) live+=" ≈ "+fmtNum(d/cupf,2)+" ft";
    }
    st.textContent=(scaleForceCalibrate?"Calibrate: click second point":"Click second point")+live;
  }else{
    const d=Math.hypot(scalePts[1].x-scalePts[0].x, scalePts[1].y-scalePts[0].y);
    let msg=fmtNum(d,1)+" chart units";
    if(cupf>0) msg+=" ≈ "+fmtNum(d/cupf,2)+" ft";
    st.textContent=msg;
  }
  const btn=document.getElementById("btn-scale-measure");
  if(btn) btn.classList.toggle("on", !!scaleMeasureMode);
}
let scaleLayer=null;
function ensureScaleLayer(){
  if(!svg) return null;
  if(!scaleLayer || scaleLayer.parentNode!==svg){
    scaleLayer=el("g",{id:"scale-layer","pointer-events":"none"});
    svg.appendChild(scaleLayer);
  }
  return scaleLayer;
}
function redrawScaleMarkers(){
  const g=ensureScaleLayer();
  if(!g) return;
  g.innerHTML="";
  if(!scaleMeasureMode && scalePts.length===0) return;
  if(!scaleMeasureMode) return;
  const r=Math.max(6, 10/Math.max(0.25, scale));
  const sw=Math.max(1.5, 2.5/Math.max(0.25, scale));
  const pts=scalePts.slice();
  if(pts.length===1 && scaleLive.x2!=null) pts.push({x:scaleLive.x2,y:scaleLive.y2, live:true});
  if(pts.length>=1){
    g.appendChild(el("circle",{cx:pts[0].x,cy:pts[0].y,r:r,fill:"#7ec8ff",stroke:"#fff","stroke-width":1.5}));
    g.appendChild(el("text",{x:pts[0].x,y:pts[0].y-r-2,"text-anchor":"middle",fill:"#7ec8ff","font-size":Math.max(10,12/Math.max(0.25,scale)),"font-weight":"700"}, "1"));
  }
  if(pts.length>=2){
    (function(){ const attrs={x1:pts[0].x,y1:pts[0].y,x2:pts[1].x,y2:pts[1].y,stroke:"#7ec8ff","stroke-width":sw,opacity:pts[1].live?"0.7":"0.95"}; if(pts[1].live) attrs["stroke-dasharray"]="6 4"; g.appendChild(el("line",attrs)); })();
    g.appendChild(el("circle",{cx:pts[1].x,cy:pts[1].y,r:r,fill:pts[1].live?"#aad4ff":"#7ec8ff",stroke:"#fff","stroke-width":1.5,opacity:pts[1].live?"0.8":"1"}));
    g.appendChild(el("text",{x:pts[1].x,y:pts[1].y-r-2,"text-anchor":"middle",fill:"#7ec8ff","font-size":Math.max(10,12/Math.max(0.25,scale)),"font-weight":"700"}, "2"));
    const midX=(pts[0].x+pts[1].x)/2, midY=(pts[0].y+pts[1].y)/2;
    const d=Math.hypot(pts[1].x-pts[0].x, pts[1].y-pts[0].y);
    const cupf=chartScaleCal.chartUnitsPerFoot;
    let label=fmtNum(d,1)+" cu";
    if(cupf>0) label+=" / "+fmtNum(d/cupf,2)+" ft";
    g.appendChild(el("text",{x:midX,y:midY-8,"text-anchor":"middle",fill:"#eef4f3","font-size":Math.max(11,13/Math.max(0.25,scale)),"font-weight":"700",stroke:"#0a3338","stroke-width":3,"paint-order":"stroke"}, label));
  }
  svg.appendChild(g);
  if(mapBoundRect && mapBoundRect.parentNode===svg) svg.appendChild(mapBoundRect);
}
function clearScalePts(){
  scalePts=[];
  scaleLive={x2:null,y2:null};
  updateScaleChip();
  redrawScaleMarkers();
}
function setScaleMeasureMode(on, opts){
  opts=opts||{};
  scaleMeasureMode=!!on;
  if(scaleMeasureMode){
    if(typeof photoMoveMode!=="undefined" && photoMoveMode) setPhotoMoveMode(false);
    if(typeof dockAlignMode!=="undefined" && dockAlignMode) setDockAlignMode(false);
    if(typeof gcpMode!=="undefined" && gcpMode) setGcpMode(false);
    if(!editing){
      const t=document.getElementById("edit-toggle");
      if(t) t.click();
    }
    scaleDrag=null;
    if(opts.forceCalibrate) scaleForceCalibrate=true;
    clearScalePts();
  }else{
    scaleForceCalibrate=false;
    scaleDrag=null;
    scaleLive={x2:null,y2:null};
    // keep last two pts briefly? clear for cleanliness
    scalePts=[];
  }
  document.body.classList.toggle("scale-measuring", scaleMeasureMode);
  const chip=document.getElementById("scale-measure-chip");
  if(chip) chip.hidden=!scaleMeasureMode;
  updateScaleChip();
  redrawScaleMarkers();
  const h=document.getElementById("hint");
  if(h && scaleMeasureMode){
    h.textContent=scaleForceCalibrate?"Scale calibrate — click two points spanning a known distance":"Scale measure — click two points (calibrate first for feet)";
  }
  try{ applyDeepZoomLod(); }catch(e){}
  try{ noteAlignModeForMobile(); }catch(e){}
}
function finishScalePair(){
  if(scalePts.length<2) return;
  const d=Math.hypot(scalePts[1].x-scalePts[0].x, scalePts[1].y-scalePts[0].y);
  const needCal=scaleForceCalibrate || !(chartScaleCal.chartUnitsPerFoot>0);
  if(needCal && canEditScaleCalibrate()){
    const def=30;
    const ans=prompt("This distance is ___ feet", String(def));
    if(ans!=null && String(ans).trim()!==""){
      const feet=Number(ans);
      if(isFinite(feet) && feet>0){
        setChartScaleFromDistance(d, feet);
        scaleForceCalibrate=false;
        const h=document.getElementById("hint");
        if(h) h.textContent="Calibrated: 1 ft ≈ "+fmtNum(chartScaleCal.chartUnitsPerFoot,3)+" chart units";
      }else{
        alert("Enter a positive number of feet.");
      }
    }
  }
  updateScaleChip();
  redrawScaleMarkers();
  // next pair starts fresh after a short beat — keep showing this measure until next click clears
}
function placeScaleClick(p){
  if(!p || !isFinite(p.x) || !isFinite(p.y)) return;
  if(scalePts.length>=2){
    // start a new measure
    scalePts=[{x:p.x,y:p.y}];
    scaleLive={x2:null,y2:null};
  }else if(scalePts.length===0){
    scalePts=[{x:p.x,y:p.y}];
    scaleLive={x2:null,y2:null};
  }else{
    scalePts.push({x:p.x,y:p.y});
    scaleLive={x2:null,y2:null};
    finishScalePair();
    return;
  }
  updateScaleChip();
  redrawScaleMarkers();
}
function numInput(id, fallback){
  const el=document.getElementById(id);
  if(!el) return fallback;
  const v=Number(el.value);
  return isFinite(v)?v:fallback;
}
function numFromEl(el, fallback){
  if(!el) return fallback;
  const v=Number(el.value);
  return isFinite(v)?v:fallback;
}
const SC_DEFAULT_SLIP_ROWS=[
  {n:13, along:10, into:30},
  {n:2, along:12, into:30}
];
function readSlipSizeRows(){
  const wrap=document.getElementById("sc-slip-rows");
  if(!wrap) return SC_DEFAULT_SLIP_ROWS.map(r=>({...r}));
  const rows=[];
  wrap.querySelectorAll(".sc-slip-row").forEach(row=>{
    const n=Math.max(0, numFromEl(row.querySelector(".sc-n"), 0));
    const along=Math.max(0, numFromEl(row.querySelector(".sc-along"), 0));
    const into=Math.max(0, numFromEl(row.querySelector(".sc-into"), 0));
    rows.push({n, along, into});
  });
  return rows.length?rows:SC_DEFAULT_SLIP_ROWS.map(r=>({...r}));
}
function bindSlipRowInputs(rowEl){
  rowEl.querySelectorAll("input").forEach(inp=>{
    inp.addEventListener("input", ()=>renderScaleRecipe());
    inp.addEventListener("change", ()=>renderScaleRecipe());
  });
  const rm=rowEl.querySelector(".sc-remove");
  if(rm) rm.addEventListener("click", ()=>{
    const wrap=document.getElementById("sc-slip-rows");
    if(!wrap) return;
    if(wrap.querySelectorAll(".sc-slip-row").length<=1) return; // keep at least one
    rowEl.remove();
    renderScaleRecipe();
  });
}
function makeSlipRowEl(data, idx){
  const d=data||{n:0,along:10,into:30};
  const div=document.createElement("div");
  div.className="sc-slip-row";
  div.dataset.idx=String(idx);
  div.innerHTML=
    '<label>Count (per side)<input class="sc-n" type="number" min="0" step="1" value="'+d.n+'"/></label>'+
    '<label>Along dock ft<input class="sc-along" type="number" min="0" step="0.1" value="'+d.along+'"/></label>'+
    '<label>Into slip ft<input class="sc-into" type="number" min="0" step="0.1" value="'+d.into+'"/></label>'+
    '<button type="button" class="sc-remove" title="Remove this slip size">×</button>';
  bindSlipRowInputs(div);
  return div;
}
function renderSlipSizeRows(rows){
  const wrap=document.getElementById("sc-slip-rows");
  if(!wrap) return;
  const data=(rows && rows.length)?rows:SC_DEFAULT_SLIP_ROWS;
  wrap.innerHTML="";
  data.forEach((r,i)=> wrap.appendChild(makeSlipRowEl(r,i)));
}
function addSlipSizeRow(){
  const wrap=document.getElementById("sc-slip-rows");
  if(!wrap) return;
  const n=wrap.querySelectorAll(".sc-slip-row").length;
  wrap.appendChild(makeSlipRowEl({n:1, along:10, into:30}, n));
  renderScaleRecipe();
}
function pickPrimarySlipRow(rows){
  // largest count; if tie, first row
  let best=rows[0]||{n:0,along:10,into:30};
  let bestIdx=0;
  rows.forEach((r,i)=>{
    if((r.n||0)>(best.n||0)){ best=r; bestIdx=i; }
  });
  return {row:best, index:bestIdx};
}
function computeDockRecipe(){
  const slipRows=readSlipSizeRows();
  const divN=Math.max(0, numInput("sc-div-n",4));
  const divW=Math.max(0, numInput("sc-div-w",2));
  const endN=Math.max(0, numInput("sc-end-n",0));
  const endW=Math.max(0, numInput("sc-end-w",2));
  const centerW=Math.max(0, numInput("sc-center-w",0));
  const typeEl=document.getElementById("sc-dock-type");
  const type=(typeEl && typeEl.value==="ew")?"ew":"ns";
  const bothEl=document.getElementById("sc-both-sides");
  const bothSides=!(bothEl && bothEl.value==="no");

  const slipSlots=slipRows.reduce((s,r)=>s+(r.n||0),0);
  const alongSlips=slipRows.reduce((s,r)=>s+(r.n||0)*(r.along||0),0);
  const maxInto=slipRows.reduce((m,r)=>Math.max(m, r.into||0), 0);
  const alongDiv=divN*divW;
  const alongEnd=endN*endW;
  // Full along = slips + dividers + end walkways (gap covered by dividers)
  const alongFt=alongSlips+alongDiv+alongEnd;
  const acrossFt = bothSides ? (maxInto + centerW + maxInto) : (maxInto + (centerW>0?centerW:0));

  const cupf=chartScaleCal.chartUnitsPerFoot;
  const toCu=ft => (cupf>0 ? ft*cupf : null);

  const slipSizes=slipRows.map((r,i)=>{
    let swFt, shFt;
    if(type==="ns"){ swFt=r.into; shFt=r.along; }
    else { swFt=r.along; shFt=r.into; }
    return {
      index:i, n:r.n, along:r.along, into:r.into,
      swFt, shFt,
      swCu:toCu(swFt), shCu:toCu(shFt)
    };
  });
  const primary=pickPrimarySlipRow(slipRows);
  const primSize=slipSizes[primary.index]||slipSizes[0];

  const result={
    type, bothSides,
    slipRows, slipSizes, slipSlots,
    alongSlips, alongDiv, alongEnd, alongFt, acrossFt,
    maxInto, centerW, divN, divW, endN, endW,
    // gap for apply comes from divider width
    gapFt:divW,
    primaryIndex:primary.index,
    stdN:primSize?primSize.n:0,
    stdAlong:primSize?primSize.along:0,
    stdInto:primSize?primSize.into:0,
    stdSwFt:primSize?primSize.swFt:0,
    stdShFt:primSize?primSize.shFt:0,
    stdSwCu:primSize?primSize.swCu:null,
    stdShCu:primSize?primSize.shCu:null,
    // legacy-ish extras note: non-primary rows
    extraSizes:slipSizes.filter((_,i)=>i!==primary.index),
    divCu:toCu(divW),
    endWalkCu:toCu(endW),
    centerCu:toCu(centerW),
    gapCu:toCu(divW),
    alongSlipsCu:toCu(alongSlips),
    alongCu:toCu(alongFt),
    acrossCu:toCu(acrossFt),
    calibrated:cupf>0
  };
  scaleLastRecipe=result;
  return result;
}
function formatSlipsOnlyOut(r){
  if(!r) return "Enter slip sizes, then Calculate slips.";
  const lines=[];
  lines.push("A — Slips only");
  lines.push("Dock length BEFORE dividers and cart path");
  lines.push("");
  lines.push("Along-dock (slips only): "+fmtNum(r.alongSlips,2)+" ft"
    +(r.calibrated?"  →  "+fmtNum(r.alongSlipsCu,1)+" chart units":"  (calibrate for chart units)"));
  const parts=r.slipSizes.map(s=> s.n+"×"+fmtNum(s.along,1)+" ft").join(" + ");
  if(parts) lines.push("  = "+parts);
  lines.push("Into-slip depth (max): "+fmtNum(r.maxInto,2)+" ft");
  r.slipSizes.forEach(s=>{
    if(s.n>0) lines.push("  · "+s.n+" slips @ "+fmtNum(s.along,1)+"×"+fmtNum(s.into,1)+" ft → into "+fmtNum(s.into,1)+" ft");
  });
  lines.push("");
  if(r.calibrated){
    lines.push("Chart-unit slip suggestions ("+r.type.toUpperCase()+"):");
    r.slipSizes.forEach(s=>{
      if(s.n<=0) return;
      lines.push("  · "+s.n+"×"+fmtNum(s.along,1)+"×"+fmtNum(s.into,1)+" ft → sw≈"+fmtNum(s.swCu,1)+", sh≈"+fmtNum(s.shCu,1)+" cu");
    });
  }else{
    lines.push("Calibrate to see sw/sh chart-unit suggestions for each slip size.");
  }
  lines.push("");
  lines.push("Primary for Apply: row "+(r.primaryIndex+1)+" ("+r.stdN+"×"+fmtNum(r.stdAlong,1)+"×"+fmtNum(r.stdInto,1)+" ft — largest count).");
  return lines.join("\n");
}
function formatFullDockOut(r){
  if(!r) return "Add dividers/cart path, then Calculate full dock.";
  const lines=[];
  lines.push("B — Full dock");
  lines.push("");
  lines.push("Along-dock (full): "+fmtNum(r.alongFt,2)+" ft"
    +(r.calibrated?"  →  "+fmtNum(r.alongCu,1)+" chart units":"  (calibrate for chart units)"));
  lines.push("  = slips-only "+fmtNum(r.alongSlips,1)
    +" + dividers "+fmtNum(r.alongDiv,1)
    +" + end walkways "+fmtNum(r.alongEnd,1));
  lines.push("  (slips-only was "+fmtNum(r.alongSlips,1)+" ft before dividers/cart)");
  lines.push("Across-dock width: "+fmtNum(r.acrossFt,2)+" ft"
    +(r.calibrated?"  →  "+fmtNum(r.acrossCu,1)+" chart units":""));
  if(r.bothSides){
    lines.push("  = intoA "+fmtNum(r.maxInto,1)+" + cart path "+fmtNum(r.centerW,1)+" + intoB "+fmtNum(r.maxInto,1));
  }else{
    lines.push("  = into-slip "+fmtNum(r.maxInto,1)+(r.centerW>0?" + cart path "+fmtNum(r.centerW,1):""));
  }
  lines.push("");
  if(r.divN>0){
    lines.push("Divider thickness: "+fmtNum(r.divW,2)+" ft × "+r.divN
      +(r.calibrated?"  →  ≈"+fmtNum(r.divCu,1)+" cu":""));
  }
  if(r.endN>0){
    lines.push("End walkway thickness: "+fmtNum(r.endW,2)+" ft each × "+r.endN
      +(r.calibrated?"  →  ≈"+fmtNum(r.endWalkCu,1)+" cu":""));
  }
  if(r.centerW>0){
    lines.push("Center cart path: "+fmtNum(r.centerW,2)+" ft"
      +(r.calibrated?"  →  ≈"+fmtNum(r.centerCu,1)+" cu (walk/gap between sides)":""));
  }
  if(r.calibrated && r.divW>0){
    lines.push("Apply gap from divider width: gap≈"+fmtNum(r.gapCu,1)+" cu");
  }
  return lines.join("\n");
}
function formatRecipeOut(r){
  // kept for any callers expecting a single blob
  if(!r) return "Enter sizes and Calculate.";
  return formatSlipsOnlyOut(r)+"\n\n"+formatFullDockOut(r);
}
function renderScaleRecipe(){
  const r=computeDockRecipe();
  const outA=document.getElementById("scale-recipe-out-a");
  if(outA) outA.textContent=formatSlipsOnlyOut(r);
  const outB=document.getElementById("scale-recipe-out");
  if(outB) outB.textContent=formatFullDockOut(r);
}
function applyScaleRecipeToSelected(){
  if(!canApplyScaleToDock()){
    alert("Apply to dock is only available on the MAIN editable chart.");
    return;
  }
  if(blockEdit && blockEdit()) return;
  const r=scaleLastRecipe || computeDockRecipe();
  if(!r.calibrated){
    alert("Calibrate the chart scale first, then Calculate, then Apply.");
    return;
  }
  if(!selectedDock){
    alert("Select a dock first (Dock tab / tap a dock).");
    return;
  }
  const d=docks.find(x=>x.id===selectedDock);
  if(!d){ alert("Selected dock not found."); return; }
  const sw=Math.round(r.stdSwCu);
  const sh=Math.round(r.stdShCu);
  const gap=r.divW>0?Math.round(r.gapCu):(d.gap!=null?d.gap:3);
  const extrasNote=(r.extraSizes||[]).filter(s=>s.n>0)
    .map(s=>s.n+"×"+fmtNum(s.along,1)+"×"+fmtNum(s.into,1)).join(", ");
  let msg="Apply to dock \""+(d.name||d.id)+"\"?\n\n"
    +"type → "+r.type+"\n"
    +"primary slip (largest count) → sw "+sw+"  sh "+sh
    +"\n  ("+r.stdN+" × "+fmtNum(r.stdAlong,1)+"×"+fmtNum(r.stdInto,1)+" ft)"
    +(r.divW>0?"\ngap from divider → "+gap:"")
    +(extrasNote?"\n\nOther slip sizes (note only): "+extrasNote:"")
    +(r.centerW>0?"\nCenter cart path ≈ "+fmtNum(r.centerCu,1)+" cu (set walk/mark separately).":"");
  if(!confirm(msg)) return;
  d.type=r.type;
  if(d.type==="col"){ d.w=sw; d.h=sh; }
  else { d.sw=sw; d.sh=sh; }
  if(r.divW>0) d.gap=gap;
  d.placed={};
  try{
    const sizesNote=r.slipSizes.filter(s=>s.n>0)
      .map(s=>s.n+"×"+fmtNum(s.along,1)+"×"+fmtNum(s.into,1)).join(" + ");
    const note="recipe: slips "+sizesNote
      +" · div "+r.divN+"×"+fmtNum(r.divW,1)+"ft · center "+fmtNum(r.centerW,1)+"ft · ends "+r.endN+"×"+fmtNum(r.endW,1)+"ft";
    d.size=note;
  }catch(_){}
  saveLayout();
  redraw();
  renderDockEditor();
  const h=document.getElementById("hint");
  if(h) h.textContent="Applied sw/sh from scale recipe to "+(d.name||d.id);
}
function wireScaleUI(){
  loadChartScale();
  updateScaleReadout();
  const measureBtn=document.getElementById("btn-scale-measure");
  if(measureBtn){
    if(!canEditScaleCalibrate()){
      // view/layersedit: allow opening measure if calibrated for read-only quick measure
      measureBtn.onclick=()=> setScaleMeasureMode(!scaleMeasureMode, {forceCalibrate:false});
    }else{
      measureBtn.onclick=()=> setScaleMeasureMode(!scaleMeasureMode, {forceCalibrate:!(chartScaleCal.chartUnitsPerFoot>0)});
    }
  }
  const done=document.getElementById("scale-measure-done");
  if(done) done.onclick=()=> setScaleMeasureMode(false);
  const clearPts=document.getElementById("scale-clear-pts");
  if(clearPts) clearPts.onclick=()=> clearScalePts();
  const cal=document.getElementById("btn-scale-calibrate");
  if(cal) cal.onclick=()=>{
    if(!canEditScaleCalibrate()){ alert("Calibrate on MAIN (or Share). This copy is read-only for scale."); return; }
    showTab("layout");
    setScaleMeasureMode(true, {forceCalibrate:true});
  };
  const recal=document.getElementById("btn-scale-recalibrate");
  if(recal) recal.onclick=()=>{
    if(!canEditScaleCalibrate()){ alert("Calibrate on MAIN (or Share)."); return; }
    setScaleMeasureMode(true, {forceCalibrate:true});
  };
  const clearCal=document.getElementById("btn-scale-clear");
  if(clearCal) clearCal.onclick=()=>{
    if(!canEditScaleCalibrate()){ alert("Clear calibration on MAIN (or Share)."); return; }
    if(!confirm("Clear saved chart scale calibration?")) return;
    clearChartScale();
  };
  renderSlipSizeRows(SC_DEFAULT_SLIP_ROWS);
  const addSlip=document.getElementById("btn-sc-add-slip");
  if(addSlip) addSlip.onclick=()=> addSlipSizeRow();
  const calcSlips=document.getElementById("btn-scale-calc-slips");
  if(calcSlips) calcSlips.onclick=()=> renderScaleRecipe();
  const calc=document.getElementById("btn-scale-calc");
  if(calc) calc.onclick=()=> renderScaleRecipe();
  const apply=document.getElementById("btn-scale-apply");
  if(apply) apply.onclick=()=> applyScaleRecipeToSelected();
  // live recalc on step-2 inputs
  ["sc-div-n","sc-div-w","sc-end-n","sc-end-w","sc-center-w","sc-dock-type","sc-both-sides"
  ].forEach(id=>{
    const el=document.getElementById(id);
    if(el){ el.addEventListener("input", ()=>renderScaleRecipe()); el.addEventListener("change", ()=>renderScaleRecipe()); }
  });
  renderScaleRecipe();
  updateScaleReadout();
}

function bumpPhotoScale(delta){
  photoAlign.scaleX=clampPhotoScale((Number(photoAlign.scaleX)||1)+delta);
  photoAlign.scaleY=clampPhotoScale((Number(photoAlign.scaleY)||1)+delta);
  syncPhotoAlignScaleAvg();
  savePhotoAlign(); applyPhotoAlign();
}
function bumpDockLayoutScale(delta){
  const keys = multi.size ? [...multi] : allLayoutKeys();
  const box = keysBBox(keys) || {x:0,y:0,w:MAP_W,h:MAP_H};
  const cx = box.x + box.w/2, cy = box.y + box.h/2;
  const f = Math.max(0.35, Math.min(2.8, 1 + delta));
  scaleMembersByKeys(keys, f, cx, cy);
  sanitizeLayout();
  saveLayout();
  redraw();
  renderDockEditor();
}
function setLabelSizeKey(key){
  if(LABEL_PX[key]==null) return;
  labelSizeKey=key;
  saveLabelSize();
  syncLabelSizeUI();
  syncLabelFonts();
  // Full redraw keeps mark hit boxes in sync with new text metrics
  try{ redraw(); }catch(e){}
}
function syncLabelSizeUI(){
  const sel=document.getElementById("label-size");
  if(sel) sel.value=labelSizeKey;
  document.querySelectorAll("[data-label-size]").forEach(b=>{
    b.classList.toggle("on", b.getAttribute("data-label-size")===labelSizeKey);
  });
}

(function wirePhotoOpacity(){
  const sl=document.getElementById("photo-op");
  if(sl){
    sl.value=String(Math.round(photoMax*100));
    photoMax=Math.max(0, Math.min(1, (+sl.value)/100));
    const sync=()=>{ photoMax=Math.max(0, Math.min(1, (+sl.value)/100)); saveLayout(false); applyDeepZoomLod(); };
    sl.oninput=sync; sl.onchange=sync;
  }
  const dz=document.getElementById("btn-deep-zoom");
  if(dz) dz.onclick=()=>{
    deepZoom=!deepZoom;
    document.getElementById("hint").textContent = deepZoom
      ? "Deep zoom · zoom out = photo, zoom in = walkways → slips → labels"
      : "Classic view · Photo slider sets fixed overlay opacity";
    if(deepZoom) fitWholeMap(); else defaultMarinaZoom();
    redraw(); applyDeepZoomLod();
  };
  const stepEl=()=>Math.max(1, +(document.getElementById("photo-step")||{}).value || 20);
  const nudge=(dx,dy)=>{ photoAlign.x=(Number(photoAlign.x)||0)+dx; photoAlign.y=(Number(photoAlign.y)||0)+dy; savePhotoAlign(); saveLayout(false); applyPhotoAlign(); };
  const bind= (id, fn)=>{ const b=document.getElementById(id); if(b) b.onclick=fn; };
  bind("photo-nudge-l", ()=>nudge(-stepEl(),0));
  bind("photo-nudge-r", ()=>nudge(stepEl(),0));
  bind("photo-nudge-u", ()=>nudge(0,-stepEl()));
  bind("photo-nudge-d", ()=>nudge(0,stepEl()));
  const bindStretch=(id, axis)=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.oninput=()=>{
      const v=clampPhotoScale((+el.value)/100);
      if(axis==="x") photoAlign.scaleX=v; else photoAlign.scaleY=v;
      syncPhotoAlignScaleAvg();
      savePhotoAlign(); applyPhotoAlign();
    };
    el.onchange=()=>saveLayout(false);
  };
  bindStretch("photo-scale-x", "x");
  bindStretch("photo-scale-y", "y");
  const bindStretchNum=(id, axis)=>{
    const el=document.getElementById(id);
    if(!el) return;
    const apply=()=>{
      const v=clampPhotoScale((+el.value)/100);
      el.value=String(Math.round(v*100));
      if(axis==="x") photoAlign.scaleX=v; else photoAlign.scaleY=v;
      syncPhotoAlignScaleAvg();
      savePhotoAlign(); applyPhotoAlign();
    };
    el.onchange=()=>{ apply(); saveLayout(false); };
    el.onkeydown=(e)=>{ if(e.key==="Enter"){ e.preventDefault(); apply(); saveLayout(false); } };
  };
  bindStretchNum("photo-scale-x-num", "x");
  bindStretchNum("photo-scale-y-num", "y");
  const rr=document.getElementById("photo-rot");
  if(rr){ rr.oninput=()=>{ photoAlign.rot=+rr.value||0; savePhotoAlign(); applyPhotoAlign(); }; rr.onchange=()=>saveLayout(false); }
  bind("photo-reset-align", ()=>{
    photoAlign={x:0,y:0,scale:1,scaleX:1,scaleY:1,rot:0};
    savePhotoAlign(); saveLayout(false); applyPhotoAlign();
  });
  bind("photo-fit-workspace", ()=>{
    // Fill work area with whole aerial: none + identity pan/scale/rot
    photoAlign={x:0,y:0,scale:1,scaleX:1,scaleY:1,rot:0};
    savePhotoAlign(); saveLayout(false); applyPhotoAlign();
    const h=document.getElementById("hint");
    if(h) h.textContent="Full aerial stretched to fill the work area · Move and Stretch to align docks";
  });
  const moveBtn=document.getElementById("btn-photo-move");
  if(moveBtn) moveBtn.onclick=()=> setPhotoMoveMode(!photoMoveMode);
  const doneChip=document.getElementById("photo-move-done");
  if(doneChip) doneChip.onclick=()=> setPhotoMoveMode(false);
  const alignBtn=document.getElementById("btn-dock-align");
  if(alignBtn) alignBtn.onclick=()=> setDockAlignMode(!dockAlignMode);
  const alignDone=document.getElementById("dock-align-done");
  if(alignDone) alignDone.onclick=()=> setDockAlignMode(false);
  const gcpBtn=document.getElementById("btn-gcp-align");
  if(gcpBtn){
    if(!IS_LAYOUT_SOURCE){ gcpBtn.hidden=true; }
    else gcpBtn.onclick=()=> setGcpMode(!gcpMode);
  }
  const gcpDone=document.getElementById("gcp-align-done");
  if(gcpDone) gcpDone.onclick=()=> setGcpMode(false);
  const gcpUndo=document.getElementById("gcp-undo-pair");
  if(gcpUndo) gcpUndo.onclick=()=> undoLastGcpPair();
  const gcpClear=document.getElementById("gcp-clear-pairs");
  if(gcpClear) gcpClear.onclick=()=> clearGcpPairs(true);
  const gcpApplyAll=document.getElementById("gcp-apply-all");
  if(gcpApplyAll) gcpApplyAll.onclick=()=> applyGcpToTargets("all");
  const gcpApplySel=document.getElementById("gcp-apply-selected");
  if(gcpApplySel) gcpApplySel.onclick=()=> applyGcpToTargets("selected");
  if(IS_LAYOUT_SOURCE){ loadGcpPairs(); updateGcpChip(); }
  try{ wireScaleUI(); }catch(e){ console.warn("scale UI", e); }
  const dockScaleMinus=document.getElementById("dock-align-scale-minus");
  if(dockScaleMinus) dockScaleMinus.onclick=()=> bumpDockLayoutScale(-0.05);
  const dockScalePlus=document.getElementById("dock-align-scale-plus");
  if(dockScalePlus) dockScalePlus.onclick=()=> bumpDockLayoutScale(0.05);
  document.querySelectorAll("[data-align-opacity]").forEach(b=>{
    b.onclick=()=>{
      const pct=+b.getAttribute("data-align-opacity");
      if(!(pct>=0)) return;
      photoMax=Math.max(0, Math.min(1, pct/100));
      const sl=document.getElementById("photo-op");
      if(sl) sl.value=String(Math.round(photoMax*100));
      saveLayout(false); applyDeepZoomLod();
    };
  });
  const labelSel=document.getElementById("label-size");
  if(labelSel){
    labelSel.value=labelSizeKey;
    labelSel.onchange=()=> setLabelSizeKey(labelSel.value);
  }
  document.querySelectorAll("[data-label-size]").forEach(b=>{
    b.onclick=()=> setLabelSizeKey(b.getAttribute("data-label-size"));
  });
  syncLabelSizeUI();
  applyDeepZoomLod();
  syncLabelFonts();
})();
document.getElementById("export-layout").onclick=async()=>{ensureStackOrder();const json=JSON.stringify({docks,marks,groups,layers,stackOrder},null,2);try{await navigator.clipboard.writeText(json);alert("Layout JSON copied.");}catch{prompt("Copy this layout JSON:",json);}};
document.getElementById("download-layout").onclick=()=>{ensureStackOrder();const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify({docks,marks,groups,layers,stackOrder},null,2)],{type:"application/json"}));a.download="laceys-layout.json";a.click();};
document.getElementById("import-layout").onclick=()=>document.getElementById("import-file").click();
document.getElementById("import-file").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const raw=JSON.parse(r.result);if(!raw.docks)throw 0;if(Array.isArray(raw.layers)) layers=raw.layers; localStorage.setItem(LAYOUT_STORE,JSON.stringify({docks:raw.docks,marks:raw.marks||[],groups:raw.groups||[],layers,stackOrder:Array.isArray(raw.stackOrder)?raw.stackOrder:[]})); saveLayersStore(); ({docks,marks,groups,layers,stackOrder}=loadLayout()); if(!Array.isArray(layers)) layers=[]; if(!Array.isArray(stackOrder)) stackOrder=[]; ensureStackOrder(); saveLayout(false);redraw();renderDockEditor();renderLayersEditor();renderChips();}catch{alert("Could not read that JSON file.");}};r.readAsText(f);};

function resetCruiserDock(){
  // MUST: deep-clone baked DEFAULT cruiser (locked, a/b sides, extras 801, placed 801-807)
  const src = (DEFAULT_DOCKS||[]).find(d=>d.id==='cruiser');
  if(!src){ alert('Built-in Cruiser dock not found.'); return; }
  const fresh = clone(src); // clone(DEFAULT_DOCKS.find(d=>d.id==='cruiser'))
  const i = docks.findIndex(d=>d.id==='cruiser');
  if(i>=0) docks[i]=fresh; else docks.push(fresh);
  selectedDock='cruiser'; selected=null; selectedMark=null;
  saveLayout(); // pushes undo
  redraw(); renderDockEditor(); updateSelHint();
  const h=document.getElementById('hint');
  if(h) h.textContent='Cruiser dock restored from original chart';
}
function restoreOriginalChart(){
  if(!confirm('Restore original chart layout? This resets all docks, marks, and groups to the baked defaults. Slip occupancy is kept. Photo align resets too.')) return;
  docks=clone(DEFAULT_DOCKS);
  marks=clone(DEFAULT_MARKS);
  groups=(typeof DEFAULT_GROUPS!=="undefined"&&Array.isArray(DEFAULT_GROUPS))?clone(DEFAULT_GROUPS):[];
  stackOrder=(typeof DEFAULT_STACK_ORDER!=="undefined"&&Array.isArray(DEFAULT_STACK_ORDER))?clone(DEFAULT_STACK_ORDER):[]; ensureStackOrder();
  layers=(typeof DEFAULT_LAYERS!=="undefined"&&Array.isArray(DEFAULT_LAYERS))?clone(DEFAULT_LAYERS):layers;
  photoAlign={x:0,y:0,scale:1,scaleX:1,scaleY:1,rot:0};
  try{ savePhotoAlign(); }catch(e){}
  multi.clear(); moveWholeChart=false; selected=null; selectedDock=null; selectedMark=null;
  if(typeof dockAlignMode!=='undefined' && dockAlignMode) setDockAlignMode(false);
  if(typeof photoMoveMode!=='undefined' && photoMoveMode) setPhotoMoveMode(false);
  if(typeof gcpMode!=='undefined' && gcpMode) setGcpMode(false);
  if(typeof scaleMeasureMode!=='undefined' && scaleMeasureMode) setScaleMeasureMode(false);
  saveLayout(); // undoable restore
  applyPhotoAlign();
  redraw(); renderDockEditor(); updateUndoBtns(); updateSelHint(); ensureMapVisible();
  const h=document.getElementById('hint');
  if(h) h.textContent='Original chart restored · slip occupancy kept';
}
function showLayoutTipBannerOnce(){
  try{
    if(localStorage.getItem('laceys-v67-layout-tip')) return;
  }catch(e){}
  const ban=document.getElementById('layout-tip-banner');
  if(!ban) return;
  ban.style.display='block';
  const d=document.getElementById('layout-tip-dismiss');
  if(d) d.onclick=()=>{
    ban.style.display='none';
    try{ localStorage.setItem('laceys-v67-layout-tip','1'); }catch(e){}
  };
}

document.getElementById("reset-layout").onclick=()=>{if(!confirm("Reset to the saved main Lacey's layout? This clears hand edits on this device."))return;localStorage.removeItem(LAYOUT_STORE);docks=clone(DEFAULT_DOCKS);marks=clone(DEFAULT_MARKS);groups=(typeof DEFAULT_GROUPS!=="undefined"&&Array.isArray(DEFAULT_GROUPS))?clone(DEFAULT_GROUPS):[];stackOrder=(typeof DEFAULT_STACK_ORDER!=="undefined"&&Array.isArray(DEFAULT_STACK_ORDER))?clone(DEFAULT_STACK_ORDER):[];ensureStackOrder();layers=(typeof DEFAULT_LAYERS!=="undefined"&&Array.isArray(DEFAULT_LAYERS))?clone(DEFAULT_LAYERS):layers;multi.clear();moveWholeChart=false;hist.length=0;future.length=0;lastSnap=snap();saveLayout(false);redraw();renderDockEditor();updateUndoBtns();updateSelHint();};

(function wireRestoreButtons(){
  const rc=document.getElementById('btn-reset-cruiser');
  if(rc) rc.onclick=()=>resetCruiserDock();
  const ro=document.getElementById('btn-restore-original');
  if(ro) ro.onclick=()=>restoreOriginalChart();
  // Align docks stays available but hidden in UI — do not auto-enter
  showLayoutTipBannerOnce();
})();
document.getElementById("add-walk").onclick=()=>{const m={id:uid("mainwalk"),kind:"bar",x:200,y:200,w:14,h:220,title:"Walkway",rot:0};marks.push(m);selectedMark=m.id;selectedDock=null;selected=null;saveLayout();showTab("layout");redraw();renderDockEditor();};
document.getElementById("add-box").onclick=()=>{const m={id:uid("box"),kind:"box",x:80,y:80,w:140,h:50,fill:"#2b6d8a",t1:"Building",t2:"",ink:"#fff",rot:0};marks.push(m);selectedMark=m.id;selectedDock=null;selected=null;saveLayout();showTab("layout");redraw();renderDockEditor();};
document.getElementById("add-label").onclick=()=>{const m={id:uid("label"),kind:"text",x:200,y:80,text:"Label",size:13,rot:0};marks.push(m);selectedMark=m.id;selectedDock=null;selected=null;saveLayout();showTab("layout");redraw();renderDockEditor();};
document.getElementById("add-dock").onclick=()=>{
  const name=prompt("Dock name?","New dock"); if(name==null||!String(name).trim()) return;
  const type=(prompt("Layout: ns (finger up/down), ew (finger left/right), or col (stack)?","ns")||"ns").toLowerCase();
  const aCount=Math.max(1,Math.min(40,+(prompt("How many slips on side A?","8")||8)));
  const bCount=Math.max(0,Math.min(40,+(prompt("How many slips on side B?","8")||0)));
  const start=+(prompt("Starting slip number?",String(nextSlipNumber()))||nextSlipNumber());
  const a=[],b=[]; let n=start; const used=new Set(slips.map(s=>String(s.num)));
  const take=()=>{while(used.has(String(n))) n++; const v=n; used.add(String(v)); n++; return v;};
  for(let i=0;i<aCount;i++) a.push(take());
  for(let i=0;i<bCount;i++) b.push(take());
  const d={id:uid("dock"),name:String(name).trim(),type:type==="ew"?"ew":type==="col"?"col":"ns",x:200,y:200,kind:"std",size:"Custom",locked:false,sw:type==="ew"?16:40,sh:type==="ew"?36:15,gap:3,w:40,h:16,a,b};
  docks.push(d); selectedDock=d.id; selected=null; selectedMark=null; saveLayout(); showTab("layout"); redraw(); renderDockEditor();
};
document.getElementById("add-slip-free").onclick=()=>{
  const num=prompt("Slip number?", String(nextSlipNumber())); if(num==null||!String(num).trim()) return;
  let dock=docks.find(x=>x.id===selectedDock);
  if(!dock){
    dock={id:uid("dock"),name:"Extra slips",type:"col",x:80,y:80,kind:"std",size:"Custom",locked:true,gap:22,w:40,h:16,a:[],b:[],extras:[]};
    docks.push(dock);
  }
  dock.extras=dock.extras||[];
  dock.extras.push({num:String(num).trim(),dx:0,dy:-28,w:dock.sw||dock.w||40,h:dock.sh||dock.h||16});
  dock.locked=false; selectedDock=dock.id; selected=String(num).trim(); selectedMark=null;
  saveLayout(); showTab("layout"); redraw(); renderDockEditor();
};


function flashSave(msg){
  const hint=document.getElementById("hint");
  const prev=hint?hint.textContent:"";
  if(hint){ hint.textContent=msg; hint.style.color="#b8f5c5"; }
  const b=document.getElementById("btn-save");
  if(b){ b.textContent="Saved"; b.classList.add("on"); }
  setTimeout(()=>{
    if(hint){ hint.textContent=prev; hint.style.color=""; }
    if(b){ b.textContent="Save"; b.classList.remove("on"); }
  }, 1800);
}


function ensureMapVisible(){
  try{
    buildSlips();
    const slipCount=(typeof slips!=="undefined" && Array.isArray(slips)) ? slips.length : 0;
    const dockCount=Array.isArray(docks) ? docks.length : 0;
    if(dockCount < 3 || slipCount < 20){
      docks=clone(DEFAULT_DOCKS);
      marks=clone(DEFAULT_MARKS);
      groups=[];
      try{
        localStorage.removeItem(LAYOUT_STORE);
        localStorage.removeItem("laceys-layout-v2");
        localStorage.removeItem("laceys-layout-v1");
      }catch(e){}
      saveLayout(false);
      buildSlips();
    }
    redraw();
  }catch(err){
    const b=document.getElementById("error-banner");
    if(b){ b.style.display="block"; b.textContent="Chart failed to draw: "+(err && err.message ? err.message : String(err)); }
    console.error(err);
  }
}

function printChart(){
  // Snapshot current SVG (includes layer colors / hidden slips as drawn)
  const clone=svg.cloneNode(true);
  clone.removeAttribute("style");
  clone.setAttribute("width",String(MAP_W));
  clone.setAttribute("height",String(MAP_H));
  clone.setAttribute("viewBox","0 0 "+MAP_W+" "+MAP_H);
  // Light paper-friendly water background (first big rect)
  const bgRect=clone.querySelector("rect");
  if(bgRect) bgRect.setAttribute("fill","#e8f2f1");
  // Soften white-ish label fills for print contrast if needed
  const html=`<!DOCTYPE html><html><head><meta charset="UTF-8"/>
<title>Lacey's Narrows · printable chart</title>
<style>
  @page{ size:landscape; margin:0.35in; }
  html,body{ margin:0; padding:0; background:#fff; }
  .wrap{ padding:8px 12px; }
  h1{ font:650 18px -apple-system,system-ui,sans-serif; margin:0 0 4px; color:#123; }
  .sub{ font:12px -apple-system,system-ui,sans-serif; color:#456; margin:0 0 8px; }
  svg{ width:100%; height:auto; max-height:7.2in; display:block; }
  .actions{ margin-top:10px; }
  @media print{ .actions{ display:none; } }
</style></head><body>
<div class="wrap">
  <h1>Lacey's Narrows</h1>
  <p class="sub">Greers Ferry Lake · Higden, AR · North up · Printed from live slip chart</p>
  ${clone.outerHTML}
  <div class="actions"><button onclick="window.print()">Print</button>
  <button onclick="window.close()">Close</button></div>
</div>
<script>window.onload=function(){ setTimeout(function(){ window.print(); }, 250); };<\/script>
</body></html>`;
  const w=window.open("", "_blank");
  if(!w){ alert("Allow pop-ups to open the printable chart."); return; }
  w.document.open();
  w.document.write(html);
  w.document.close();
}


const PUBLISHED_LAYOUT_KEY="laceys-published-layout-v1";
const PUBLISHED_LAYOUT_URLS=[
  "../laceys/published-layout.json",
  "./published-layout.json",
  "https://tiffany148.github.io/Greers-Ferry-Lake-Map-II-/laceys/published-layout.json"
];
const GH_PUBLISH_OWNER="tiffany148";
const GH_PUBLISH_REPO="Greers-Ferry-Lake-Map-II-";
const GH_PUBLISH_PATH="laceys/published-layout.json";
const GH_PUBLISH_BRANCH="main";
const GH_PUBLISH_TOKEN_KEY="laceys-gh-publish-token";
function buildPublishedPayload(){
  ensureStackOrder();
  return {
    docks: clone(docks),
    marks: clone(marks),
    groups: Array.isArray(groups)?clone(groups):[],
    layers: Array.isArray(layers)?clone(layers):[],
    stackOrder: Array.isArray(stackOrder)?clone(stackOrder):[],
    publishedAt: new Date().toISOString()
  };
}
function pruneOrphanLayerOpts(){
  try{
    const valid={};
    (layers||[]).forEach(L=>{
      valid[L.id]=new Set((L.options||[]).map(o=>o.id));
    });
    let changed=false;
    Object.keys(data||{}).forEach(slipId=>{
      const rec=data[slipId];
      if(!rec||!rec.layerOpts||typeof rec.layerOpts!=="object") return;
      Object.keys(rec.layerOpts).forEach(lid=>{
        const oid=rec.layerOpts[lid];
        if(!valid[lid] || (oid && !valid[lid].has(oid))){
          delete rec.layerOpts[lid];
          changed=true;
        }
      });
    });
    if(changed) save(data);
  }catch(e){}
}
function applyPublishedLayout(payload, opts){
  if(!payload||!Array.isArray(payload.docks)||!payload.docks.length) return false;
  const quiet=opts&&opts.quiet;
  docks=clone(payload.docks);
  marks=clone(payload.marks||[]);
  groups=Array.isArray(payload.groups)?clone(payload.groups):[];
  stackOrder=Array.isArray(payload.stackOrder)?clone(payload.stackOrder):[];
  if(Array.isArray(payload.layers)) layers=clone(payload.layers);
  ensureStackOrder();
  pruneOrphanLayerOpts();
  try{ saveLayersStore(); }catch(e){}
  saveLayout(false);
  try{ buildSlips(); }catch(e){}
  try{ redraw(); }catch(e){}
  try{ renderDockEditor(); }catch(e){}
  try{ renderLayersEditor(); }catch(e){}
  try{ renderChips(); }catch(e){}
  try{ updateUndoBtns(); }catch(e){}
  try{ updateSelHint(); }catch(e){}
  if(!quiet){
    try{ flashSave("Layout synced from main · "+(payload.publishedAt||"")); }catch(e){}
  }
  return true;
}
function writePublishedLocal(payload){
  const json=JSON.stringify(payload);
  try{ localStorage.setItem(PUBLISHED_LAYOUT_KEY, json); }catch(e){}
  if(window.laceysDesktop && typeof window.laceysDesktop.writePublishedLayout==="function"){
    try{ return Promise.resolve(window.laceysDesktop.writePublishedLayout(json)); }catch(e){ return Promise.resolve(false); }
  }
  return Promise.resolve(true);
}
function downloadPublishedLayoutFile(payload){
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:"application/json"}));
  a.download="published-layout.json";
  a.click();
  setTimeout(()=>{ try{ URL.revokeObjectURL(a.href); }catch(e){} }, 2000);
}
function publishLayoutAfterSave(){
  if(!IS_LAYOUT_SOURCE) return;
  const payload=buildPublishedPayload();
  writePublishedLocal(payload).then(function(){
    flashSave("Saved · layout shared to copies (Desktop auto / Web localStorage)");
  }).catch(function(){
    flashSave("Saved on this device");
  });
}
function getGhPublishToken(){
  try{ return localStorage.getItem(GH_PUBLISH_TOKEN_KEY)||""; }catch(e){ return ""; }
}
function setGhPublishToken(tok){
  try{
    if(tok) localStorage.setItem(GH_PUBLISH_TOKEN_KEY, tok);
    else localStorage.removeItem(GH_PUBLISH_TOKEN_KEY);
  }catch(e){}
}
function utf8ToBase64(str){
  const bytes=new TextEncoder().encode(str);
  let binary="";
  const chunk=0x8000;
  for(let i=0;i<bytes.length;i+=chunk){
    binary+=String.fromCharCode.apply(null, bytes.subarray(i, i+chunk));
  }
  return btoa(binary);
}
function updateGhTokenUi(){
  if(!IS_LAYOUT_SOURCE) return;
  const inp=document.getElementById("gh-publish-token");
  const st=document.getElementById("gh-publish-status");
  const has=!!getGhPublishToken();
  if(inp && !inp.value){
    /* leave blank; do not echo token */
  }
  if(st){
    st.textContent=has ? "Token saved on this device" : "No token saved — Publish will prompt or fall back to download";
  }
}
function wireGhPublishTokenUi(){
  if(!IS_LAYOUT_SOURCE){
    ["gh-publish-token-wrap","gh-publish-token-wrap-dock"].forEach(function(id){
      const el=document.getElementById(id);
      if(el) el.hidden=true;
    });
    return;
  }
  const saveBtn=document.getElementById("btn-gh-token-save");
  const clearBtn=document.getElementById("btn-gh-token-clear");
  const saveBtn2=document.getElementById("btn-gh-token-save-dock");
  const clearBtn2=document.getElementById("btn-gh-token-clear-dock");
  const dlBtn=document.getElementById("btn-download-published-layout");
  const dlBtn2=document.getElementById("btn-download-published-layout-dock");
  function saveFrom(inputId){
    const inp=document.getElementById(inputId);
    const tok=(inp && inp.value ? inp.value : "").trim();
    if(!tok){ flashSave("Paste a GitHub token first"); return; }
    setGhPublishToken(tok);
    if(inp) inp.value="";
    updateGhTokenUi();
    flashSave("GitHub publish token saved on this device");
  }
  function clearTok(){
    setGhPublishToken("");
    ["gh-publish-token","gh-publish-token-dock"].forEach(function(id){
      const inp=document.getElementById(id);
      if(inp) inp.value="";
    });
    updateGhTokenUi();
    flashSave("GitHub publish token cleared");
  }
  if(saveBtn) saveBtn.onclick=function(){ saveFrom("gh-publish-token"); };
  if(saveBtn2) saveBtn2.onclick=function(){ saveFrom("gh-publish-token-dock"); };
  if(clearBtn) clearBtn.onclick=clearTok;
  if(clearBtn2) clearBtn2.onclick=clearTok;
  function doDownload(){
    downloadPublishedLayoutFile(buildPublishedPayload());
    flashSave("Downloaded published-layout.json (backup)");
  }
  if(dlBtn) dlBtn.onclick=doDownload;
  if(dlBtn2) dlBtn2.onclick=doDownload;
  updateGhTokenUi();
}
async function publishLayoutToGitHub(payload){
  if(!IS_LAYOUT_SOURCE) return false;
  let token=getGhPublishToken();
  if(!token){
    try{
      const pasted=window.prompt("Paste a GitHub fine-grained PAT (Contents: Read and write on tiffany148/Greers-Ferry-Lake-Map-II- only). Leave blank to download instead.");
      if(pasted && pasted.trim()){
        token=pasted.trim();
        setGhPublishToken(token);
        updateGhTokenUi();
      }
    }catch(e){}
  }
  if(!token){
    const st=document.getElementById("gh-publish-status");
    if(st) st.textContent="No GitHub token — falling back to download";
    return false;
  }
  const apiUrl="https://api.github.com/repos/"+GH_PUBLISH_OWNER+"/"+GH_PUBLISH_REPO+"/contents/"+GH_PUBLISH_PATH+"?ref="+encodeURIComponent(GH_PUBLISH_BRANCH);
  const headers={
    "Authorization":"Bearer "+token,
    "Accept":"application/vnd.github+json",
    "X-GitHub-Api-Version":"2022-11-28"
  };
  let sha=null;
  try{
    const getRes=await fetch(apiUrl, {headers:headers, cache:"no-store"});
    if(getRes.status===200){
      const meta=await getRes.json();
      if(meta && meta.sha) sha=meta.sha;
    }else if(getRes.status===404){
      sha=null;
    }else if(getRes.status===401 || getRes.status===403){
      flashSave("GitHub token invalid or missing Contents write permission");
      try{ alert("GitHub publish failed: token invalid or missing Contents: Read and write on "+GH_PUBLISH_OWNER+"/"+GH_PUBLISH_REPO+"."); }catch(e){}
      const st=document.getElementById("gh-publish-status");
      if(st) st.textContent="Token invalid or missing Contents write (HTTP "+getRes.status+")";
      return false;
    }else{
      const st=document.getElementById("gh-publish-status");
      if(st) st.textContent="GitHub GET failed: HTTP "+getRes.status;
      flashSave("GitHub publish failed (GET "+getRes.status+")");
      return false;
    }
  }catch(err){
    const st=document.getElementById("gh-publish-status");
    if(st) st.textContent="GitHub network error (GET)";
    flashSave("GitHub publish network error");
    return false;
  }
  const json=JSON.stringify(payload);
  let contentB64;
  try{ contentB64=utf8ToBase64(json); }
  catch(e){
    try{ contentB64=btoa(unescape(encodeURIComponent(json))); }catch(e2){
      flashSave("Could not encode layout for GitHub");
      return false;
    }
  }
  const putBody={
    message:"Publish Lacey's layout "+(payload.publishedAt||new Date().toISOString()),
    content:contentB64,
    branch:GH_PUBLISH_BRANCH
  };
  if(sha) putBody.sha=sha;
  const putUrl="https://api.github.com/repos/"+GH_PUBLISH_OWNER+"/"+GH_PUBLISH_REPO+"/contents/"+GH_PUBLISH_PATH;
  try{
    const putRes=await fetch(putUrl, {
      method:"PUT",
      headers:Object.assign({"Content-Type":"application/json"}, headers),
      body:JSON.stringify(putBody)
    });
    if(putRes.ok){
      flashSave("Published to live copies on GitHub");
      setTimeout(function(){
        flashSave("Live copies update in about a minute (GitHub Pages).");
      }, 2000);
      const st=document.getElementById("gh-publish-status");
      if(st) st.textContent="Published to GitHub · Pages may lag 30–60s";
      return true;
    }
    if(putRes.status===401 || putRes.status===403){
      flashSave("GitHub token invalid or missing Contents write permission");
      try{ alert("GitHub publish failed: token invalid or missing Contents: Read and write on "+GH_PUBLISH_OWNER+"/"+GH_PUBLISH_REPO+"."); }catch(e){}
      const st=document.getElementById("gh-publish-status");
      if(st) st.textContent="Token invalid or missing Contents write (HTTP "+putRes.status+")";
      return false;
    }
    let detail="";
    try{ const j=await putRes.json(); detail=(j && j.message)?(" — "+j.message):""; }catch(e){}
    const st=document.getElementById("gh-publish-status");
    if(st) st.textContent="GitHub PUT failed: HTTP "+putRes.status+detail;
    flashSave("GitHub publish failed (PUT "+putRes.status+")");
    return false;
  }catch(err){
    const st=document.getElementById("gh-publish-status");
    if(st) st.textContent="GitHub network error (PUT)";
    flashSave("GitHub publish network error");
    return false;
  }
}
async function publishLayoutToCopies(){
  if(!IS_LAYOUT_SOURCE) return;
  const payload=buildPublishedPayload();
  try{ await writePublishedLocal(payload); }catch(e){}
  let ghOk=false;
  try{ ghOk=await publishLayoutToGitHub(payload); }catch(e){ ghOk=false; }
  if(ghOk){
    /* GitHub succeeded — download optional; keep backup button available */
    return;
  }
  downloadPublishedLayoutFile(payload);
  flashSave("Published · Desktop copies update on open. Web: upload published-layout.json into laceys/ on GitHub");
  try{
    alert("Published layout for live copies.\\n\\nDesktop: other modes update on open/focus.\\nWeb: set a GitHub publish token (Contents write on tiffany148/Greers-Ferry-Lake-Map-II-) for auto-upload, or upload the downloaded published-layout.json into the laceys/ folder on GitHub, then refresh share/view/layers.");
  }catch(e){}
}
async function fetchPublishedLayoutJson(){
  const bust="?t="+Date.now();
  for(const base of PUBLISHED_LAYOUT_URLS){
    try{
      const res=await fetch(base+bust, {cache:"no-store"});
      if(!res.ok) continue;
      const raw=await res.json();
      if(raw&&Array.isArray(raw.docks)&&raw.docks.length) return raw;
    }catch(e){}
  }
  return null;
}
async function pullPublishedLayout(opts){
  if(IS_LAYOUT_SOURCE) return false;
  const quiet=opts&&opts.quiet;
  let payload=null;
  // 1) Electron userData
  if(window.laceysDesktop && typeof window.laceysDesktop.readPublishedLayout==="function"){
    try{
      const raw=await window.laceysDesktop.readPublishedLayout();
      if(raw){
        payload=(typeof raw==="string")?JSON.parse(raw):raw;
      }
    }catch(e){}
  }
  // 2) localStorage broadcast (same browser)
  if(!payload){
    try{
      const ls=localStorage.getItem(PUBLISHED_LAYOUT_KEY);
      if(ls) payload=JSON.parse(ls);
    }catch(e){}
  }
  // 3) hosted / relative JSON
  if(!payload){
    payload=await fetchPublishedLayoutJson();
  }
  if(!payload||!Array.isArray(payload.docks)||!payload.docks.length) return false;
  // Prefer newer publishedAt if we already have something similar — always apply when present
  applyPublishedLayout(payload, {quiet:quiet});
  return true;
}
function wirePublishedLayoutListeners(){
  if(IS_LAYOUT_SOURCE) return;
  if(window.laceysDesktop && typeof window.laceysDesktop.onPublishedLayoutUpdated==="function"){
    try{
      window.laceysDesktop.onPublishedLayoutUpdated(function(data){
        try{
          const payload=(typeof data==="string")?JSON.parse(data):data;
          applyPublishedLayout(payload, {quiet:false});
        }catch(e){}
      });
    }catch(e){}
  }
  window.addEventListener("focus", function(){ pullPublishedLayout({quiet:true}); });
  document.addEventListener("visibilitychange", function(){
    if(document.visibilityState==="visible") pullPublishedLayout({quiet:true});
  });
  window.addEventListener("storage", function(ev){
    if(ev && ev.key===PUBLISHED_LAYOUT_KEY && ev.newValue){
      try{ applyPublishedLayout(JSON.parse(ev.newValue), {quiet:false}); }catch(e){}
    }
  });
}

function saveNow(){
  // Pull any OOB geometry back inside the chart before persist (undoable)
  const preClamp=snap();
  if(clampLayoutIntoMap()){
    hist.push(preClamp);
    if(hist.length>80) hist.shift();
    future.length=0;
    lastSnap=snap();
    updateUndoBtns();
    redraw();
    try{ renderDockEditor(); }catch(e){}
  }
  // Persist exact current docks/marks/groups/layers (deletes included)
  const s=snap();
  localStorage.setItem(LAYOUT_STORE, s);
  try{ localStorage.setItem("laceys-layout-v2", s); }catch(e){}
  saveLayersStore();
  lastSnap=s;
  if(IS_LAYOUT_SOURCE){
    publishLayoutAfterSave();
  }else{
    flashSave("Saved on this device · Download JSON for a backup copy");
  }
}

function saveLayersStore(){
  try{ localStorage.setItem("laceys-layers-v1", JSON.stringify(layers)); }catch(e){}
}
function renderLayersEditor(){
  const box=document.getElementById("layers-editor");
  if(!box) return;

  if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){
    if(!layers.length){
      box.innerHTML="<p class=\"hint\">No layers on this chart.</p>";
      return;
    }
    box.innerHTML="<p class=\"hint\">View only — pick a layer to color the map, and use 👁 to hide/show options.</p>"+layers.map(layer=>{
      const on=activeLayerId===layer.id;
      const layerHidden=!!layer.hidden;
      const opts=(layer.options||[]).map(o=>`
      <div class="opt" data-layer="${layer.id}" data-opt="${o.id}">
        <button type="button" class="btn eye ${o.hidden?"off":""}" data-hide-opt title="${o.hidden?"Show":"Hide"}">${o.hidden?"🙈":"👁"}</button>
        <span style="width:18px;height:18px;border-radius:4px;background:${o.color||"#ccc"};display:inline-block"></span>
        <span style="flex:1">${o.name||"Option"}</span>
      </div>`).join("");
      return `<div class="layer-card" data-layer-card="${layer.id}" style="${layerHidden?"opacity:.55":""}">
      <h3>
        <button type="button" class="btn eye ${layerHidden?"off":""}" data-hide-layer title="${layerHidden?"Show layer":"Hide layer"}">${layerHidden?"🙈":"👁"}</button>
        <span style="flex:1;font-weight:650">${layer.name||"Layer"}</span>
        <button type="button" class="btn ${on?"on":""}" data-use-layer>${on?"Coloring on":"View layer"}</button>
      </h3>
      <div class="opt" data-unassigned="${layer.id}">
        <span style="flex:1">Unassigned slips</span>
        <button type="button" class="btn eye ${layer.hideUnassigned?"off":""}" data-hide-unassigned>${layer.hideUnassigned?"🙈 Hidden":"👁 Visible"}</button>
      </div>
      ${opts}
    </div>`;
    }).join("");
    box.querySelectorAll("[data-use-layer]").forEach(btn=>{
      btn.onclick=()=>{
        const id=btn.closest("[data-layer-card]").dataset.layerCard;
        const layer=layers.find(l=>l.id===id);
        if(layer && layer.hidden){ layer.hidden=false; }
        activeLayerId = activeLayerId===id ? null : id;
        layerOptFilter="All";
        saveLayersStore();
        renderLayersEditor(); renderChips(); redraw();
      };
    });
    box.querySelectorAll("[data-hide-layer]").forEach(btn=>{
      btn.onclick=()=>{
        const id=btn.closest("[data-layer-card]").dataset.layerCard;
        const layer=layers.find(l=>l.id===id); if(!layer) return;
        layer.hidden=!layer.hidden;
        activeLayerId=id;
        layerOptFilter="All";
        saveLayersStore(); renderLayersEditor(); renderChips(); redraw();
      };
    });
    box.querySelectorAll("[data-hide-unassigned]").forEach(btn=>{
      btn.onclick=()=>{
        const id=btn.closest("[data-unassigned]").dataset.unassigned;
        const layer=layers.find(l=>l.id===id); if(!layer) return;
        layer.hideUnassigned=!layer.hideUnassigned;
        if(activeLayerId!==id){ activeLayerId=id; layerOptFilter="All"; }
        saveLayersStore(); renderLayersEditor(); renderChips(); redraw();
      };
    });
    box.querySelectorAll("[data-hide-opt]").forEach(btn=>{
      btn.onclick=()=>{
        const row=btn.closest(".opt");
        const layer=layers.find(l=>l.id===row.dataset.layer); if(!layer) return;
        const opt=(layer.options||[]).find(o=>o.id===row.dataset.opt); if(!opt) return;
        opt.hidden=!opt.hidden;
        if(activeLayerId!==layer.id){ activeLayerId=layer.id; layerOptFilter="All"; }
        saveLayersStore(); renderLayersEditor(); renderChips(); redraw();
      };
    });
    return;
  }
  if(!layers.length){
    box.innerHTML="<p class=\"hint\">No custom layers yet. Add one to color-code slips (Power, Lease, Season, …).</p>";
    return;
  }
  box.innerHTML=layers.map(layer=>{
    const on=activeLayerId===layer.id;
    const opts=(layer.options||[]).map((o,idx)=>`
      <div class="opt" data-layer="${layer.id}" data-opt="${o.id}">
        <button type="button" class="btn eye ${o.hidden?"off":""}" data-hide-opt title="${o.hidden?"Show":"Hide"}">${o.hidden?"🙈":"👁"}</button>
        <input type="color" value="${o.color||"#e4dcc8"}" data-k="color"/>
        <input type="text" value="${(o.name||"").replace(/"/g,"&quot;")}" data-k="name" placeholder="Option name" style="flex:1;min-width:100px"/>
        <button type="button" class="btn" data-del-opt>Remove</button>
      </div>`).join("");
    const layerHidden=!!layer.hidden;
    return `<div class="layer-card" data-layer-card="${layer.id}" style="${layerHidden?"opacity:.55":""}">
      <h3>
        <button type="button" class="btn eye ${layerHidden?"off":""}" data-hide-layer title="${layerHidden?"Show layer":"Hide layer"}">${layerHidden?"🙈 Hide":"👁 Show"}</button>
        <input type="text" value="${(layer.name||"").replace(/"/g,"&quot;")}" data-layer-name style="flex:1;min-width:120px"/>
        <button type="button" class="btn ${on?"on":""}" data-use-layer>${on?"Coloring on":"Use to color"}</button>
        <button type="button" class="btn" data-del-layer>Delete layer</button>
      </h3>
      <div class="opt" data-unassigned="${layer.id}">
        <span style="flex:1">Unassigned slips</span>
        <button type="button" class="btn eye ${layer.hideUnassigned?"off":""}" data-hide-unassigned>${layer.hideUnassigned?"🙈 Hidden":"👁 Visible"}</button>
      </div>
      ${opts}
      <div class="st"><button type="button" class="btn" data-add-opt>+ Option</button></div>
    </div>`;
  }).join("");

  box.querySelectorAll("[data-layer-name]").forEach(inp=>{
    inp.onchange=()=>{
      const id=inp.closest("[data-layer-card]").dataset.layerCard;
      const layer=layers.find(l=>l.id===id); if(!layer) return;
      layer.name=inp.value.trim()||"Layer";
      saveLayersStore(); saveLayout(false); renderChips();
    };
  });
  box.querySelectorAll("[data-use-layer]").forEach(btn=>{
    btn.onclick=()=>{
      const id=btn.closest("[data-layer-card]").dataset.layerCard;
      const layer=layers.find(l=>l.id===id);
      if(layer && layer.hidden){ layer.hidden=false; }
      activeLayerId = activeLayerId===id ? null : id;
      layerOptFilter="All";
      saveLayersStore(); saveLayout(false);
      renderLayersEditor(); renderChips(); redraw();
    };
  });
  box.querySelectorAll("[data-hide-layer]").forEach(btn=>{
    btn.onclick=()=>{
      const id=btn.closest("[data-layer-card]").dataset.layerCard;
      const layer=layers.find(l=>l.id===id); if(!layer) return;
      layer.hidden=!layer.hidden;
      activeLayerId=id;
      layerOptFilter="All";
      saveLayersStore(); saveLayout(false); renderLayersEditor(); renderChips(); redraw();
    };
  });
  box.querySelectorAll("[data-hide-unassigned]").forEach(btn=>{
    btn.onclick=()=>{
      const id=btn.closest("[data-unassigned]").dataset.unassigned;
      const layer=layers.find(l=>l.id===id); if(!layer) return;
      layer.hideUnassigned=!layer.hideUnassigned;
      if(activeLayerId!==id){ activeLayerId=id; layerOptFilter="All"; }
      saveLayersStore(); saveLayout(false); renderLayersEditor(); renderChips(); redraw();
    };
  });
  box.querySelectorAll("[data-hide-opt]").forEach(btn=>{
    btn.onclick=()=>{
      const row=btn.closest(".opt");
      const layer=layers.find(l=>l.id===row.dataset.layer); if(!layer) return;
      const opt=(layer.options||[]).find(o=>o.id===row.dataset.opt); if(!opt) return;
      opt.hidden=!opt.hidden;
      if(activeLayerId!==layer.id){ activeLayerId=layer.id; layerOptFilter="All"; }
      saveLayersStore(); saveLayout(false); renderLayersEditor(); renderChips(); redraw();
    };
  });
  box.querySelectorAll("[data-del-layer]").forEach(btn=>{
    btn.onclick=()=>{
      const id=btn.closest("[data-layer-card]").dataset.layerCard;
      if(!confirm("Delete this layer? Slip assignments for it will be ignored.")) return;
      layers=layers.filter(l=>l.id!==id);
      if(activeLayerId===id) activeLayerId=null;
      saveLayersStore(); saveLayout(); renderLayersEditor(); renderChips(); redraw();
    };
  });
  box.querySelectorAll("[data-add-opt]").forEach(btn=>{
    btn.onclick=()=>{
      const id=btn.closest("[data-layer-card]").dataset.layerCard;
      const layer=layers.find(l=>l.id===id); if(!layer) return;
      layer.options=layer.options||[];
      const colors=["#5aa0c4","#6dad6a","#e3c35c","#e39a7a","#c9896a","#9b7bb8","#d2b48c"];
      layer.options.push({id:uid("opt"), name:"Option "+(layer.options.length+1), color:colors[layer.options.length%colors.length]});
      saveLayersStore(); saveLayout(); renderLayersEditor(); renderChips(); redraw();
    };
  });
  box.querySelectorAll(".opt").forEach(row=>{
    const layerId=row.dataset.layer, optId=row.dataset.opt;
    row.querySelectorAll("[data-k]").forEach(inp=>{
      const apply=()=>{
        const layer=layers.find(l=>l.id===layerId); if(!layer) return;
        const opt=(layer.options||[]).find(o=>o.id===optId); if(!opt) return;
        if(inp.dataset.k==="color") opt.color=inp.value;
        else opt.name=inp.value.trim()||"Option";
        saveLayersStore(); saveLayout(false); renderChips(); redraw();
      };
      inp.onchange=apply; inp.oninput=()=>{ if(inp.dataset.k==="color"){ apply(); } };
    });
    const del=row.querySelector("[data-del-opt]");
    if(del) del.onclick=()=>{
      const layer=layers.find(l=>l.id===layerId); if(!layer) return;
      layer.options=(layer.options||[]).filter(o=>o.id!==optId);
      saveLayersStore(); saveLayout(); renderLayersEditor(); renderChips(); redraw();
    };
  });
}
document.getElementById("add-layer").onclick=()=>{ if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){ blockEdit(); return; }
  const name=prompt("Layer name?","Power");
  if(name==null) return;
  layers.push({
    id:uid("layer"),
    name:String(name).trim()||"Layer",
    options:[
      {id:uid("opt"), name:"Option A", color:"#5aa0c4"},
      {id:uid("opt"), name:"Option B", color:"#6dad6a"},
      {id:uid("opt"), name:"Option C", color:"#e3c35c"}
    ]
  });
  saveLayersStore(); saveLayout(); showTab("layers"); renderLayersEditor(); renderChips(); redraw();
};
document.getElementById("btn-undo").onclick=()=>undo();
document.getElementById("btn-redo").onclick=()=>redo();
document.getElementById("btn-save").onclick=()=>{ if(typeof VIEW_ONLY!=="undefined" && VIEW_ONLY){ saveLayersStore(); flashSave("Layer view saved on this device"); return; } saveNow(); };
document.getElementById("btn-print").onclick=()=>printChart();
const _fixBlank=document.getElementById("btn-reset-blank");
if(_fixBlank) _fixBlank.onclick=()=>{
  if(!confirm("Restore the built-in Lacey\'s dock layout? (clears blank/corrupt offline save on this file)")) return;
  try{ localStorage.removeItem(LAYOUT_STORE); localStorage.removeItem("laceys-layout-v2"); localStorage.removeItem("laceys-layout-v1"); }catch(e){}
  docks=clone(DEFAULT_DOCKS); marks=clone(DEFAULT_MARKS); groups=(typeof DEFAULT_GROUPS!=="undefined"&&Array.isArray(DEFAULT_GROUPS))?clone(DEFAULT_GROUPS):[]; stackOrder=(typeof DEFAULT_STACK_ORDER!=="undefined"&&Array.isArray(DEFAULT_STACK_ORDER))?clone(DEFAULT_STACK_ORDER):[]; ensureStackOrder(); layers=(typeof DEFAULT_LAYERS!=="undefined"&&Array.isArray(DEFAULT_LAYERS))?clone(DEFAULT_LAYERS):[];
  multi.clear(); moveWholeChart=false; hist.length=0; future.length=0; lastSnap=snap(); saveLayout(false); ensureMapVisible(); renderDockEditor(); renderChips(); updateUndoBtns(); alert("Layout restored.");
};
const _btnSaveLayout=document.getElementById("btn-save-layout"); if(_btnSaveLayout) _btnSaveLayout.onclick=()=>saveNow();
function wireMultiButtons(){
  const toggle=()=>setMultiPick(!multiPick);
  const b1=document.getElementById("btn-multi"); if(b1) b1.onclick=toggle;
  const b2=document.getElementById("btn-multi-hdr"); if(b2) b2.onclick=toggle;
  const clear=document.getElementById("btn-multi-clear");
  if(clear) clear.onclick=()=>{ multi.clear(); moveWholeChart=false; updateSelHint(); redraw(); renderDockEditor(); };
  const done=document.getElementById("btn-multi-done");
  if(done) done.onclick=()=>{
    setMultiPick(false);
    if(multi.size>1){
      moveWholeChart=true;
      document.getElementById("hint").textContent="Grouped · drag selected to move · tap to add/remove · Scale −/+ or type Slip W/H · Lock as dock when done";
      renderDockEditor();
    }
  };
  const editSel=document.getElementById("btn-multi-edit");
  if(editSel) editSel.onclick=()=>{
    if(multi.size<1){ alert("Nothing selected yet."); return; }
    setMultiPick(true);
    document.getElementById("hint").textContent="Add/remove · tick list or tap the map · Done when the set is right";
  };
  const move=document.getElementById("btn-multi-move");
  if(move) move.onclick=()=>{
    if(multi.size<1){ alert("Pick at least one item in the list first."); return; }
    setMultiPick(false);
    moveWholeChart = multi.size>0;
    document.getElementById("hint").textContent = multi.size>1
      ? ("Drag selected pieces to move all "+multi.size+" · tap to add/remove · Scale −/+ works · Lock as dock when finished")
      : "Drag on the map to move the selected piece";
    updateSelHint();
    renderDockEditor();
  };
  const mlock=document.getElementById("btn-multi-lock");
  if(mlock) mlock.onclick=()=>{
    if(multi.size<1){ alert("Pick slips or a dock first."); return; }
    setMultiPick(false);
    lockSelectionAsDock();
  };
  const mUnlock=document.getElementById("btn-multi-unlock");
  if(mUnlock) mUnlock.onclick=()=>{
    if(multi.size<1 && !selectionKeys().length){ alert("Select a dock or slips first."); return; }
    ungroupUnlockThisDock();
  };
  const msDown=document.getElementById("btn-multi-scale-down");
  if(msDown) msDown.onclick=()=>{
    if(multi.size<1){ alert("Pick slips or docks first."); return; }
    scaleSelectionByFactor(0.9);
  };
  const msUp=document.getElementById("btn-multi-scale-up");
  if(msUp) msUp.onclick=()=>{
    if(multi.size<1){ alert("Pick slips or docks first."); return; }
    scaleSelectionByFactor(1.1);
  };
  wireGeomFields({x:"multi-x",y:"multi-y",w:"multi-sw",h:"multi-sh"});
  try{ syncMultiGeomInputs(); }catch(e){}
}
wireMultiButtons();
document.getElementById("btn-select-all").onclick=()=>{ if(!editing){ if(blockEdit()) return; document.getElementById("edit-toggle").click(); } multiPick=false; selectAllLayout(); };
document.getElementById("btn-group-all").onclick=()=>{ if(!editing){ if(blockEdit()) return; document.getElementById("edit-toggle").click(); } multiPick=false; groupAllLayout(); };
document.getElementById("btn-group").onclick=()=>{
  if(multi.size<2){ alert("Turn on Multi-select and tap at least two docks, slips, or labels first (or Shift-click on desktop)."); return; }
  const name=prompt("Group name?","Group "+(groups.length+1));
  if(name==null) return;
  groups.push({id:uid("grp"),name:String(name).trim()||"Group",members:[...multi]});
  // Keep selection + exit multi-pick so the group is immediately draggable on the map
  multiPick=false;
  moveWholeChart=true;
  updateSelHint();
  const h=document.getElementById("hint");
  if(h) h.textContent="Grouped · drag selected to move · tap to add/remove · Scale −/+ or type Slip W/H · Lock as dock when done";
  saveLayout(); redraw(); updateSelChip(); renderDockEditor();
};
const _lockAs=document.getElementById("btn-lock-as-dock");
if(_lockAs) _lockAs.onclick=()=>{ if(!editing){ if(blockEdit()) return; document.getElementById("edit-toggle").click(); } lockSelectionAsDock(); };
const _unlockSl=document.getElementById("btn-unlock-slips");
if(_unlockSl) _unlockSl.onclick=()=>{ if(!editing){ if(blockEdit()) return; document.getElementById("edit-toggle").click(); } unlockSelectionSlips(); };
document.getElementById("btn-ungroup").onclick=()=>{
  if(!editing){ if(blockEdit()) return; document.getElementById("edit-toggle").click(); }
  ungroupUnlockThisDock();
};
document.getElementById("btn-dup").onclick=()=>{
  if(selectedDock){
    const d=docks.find(x=>x.id===selectedDock); if(!d) return;
    const copy=clone(d); copy.id=uid("dock"); copy.name=(d.name||"Dock")+" copy"; copy.x+=40; copy.y+=40;
    docks.push(copy); ensureStackOrder(); stackMove(["dock:"+copy.id],"front"); selectedDock=copy.id; saveLayout(); redraw(); renderDockEditor(); return;
  }
  if(selectedMark){
    const m=marks.find(x=>x.id===selectedMark); if(!m) return;
    const copy=clone(m); copy.id=uid(m.kind||"mark"); copy.x+=30; copy.y+=30;
    marks.push(copy); ensureStackOrder(); stackMove(["mark:"+copy.id],"front"); selectedMark=copy.id; saveLayout(); redraw(); renderDockEditor(); return;
  }
  alert("Select a dock or label first.");
};
updateUndoBtns(); updateSelHint();
document.addEventListener("keydown",e=>{
  if((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==="z"){ e.preventDefault(); if(e.shiftKey) redo(); else undo(); }
  if((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==="y"){ e.preventDefault(); redo(); }
});

const _strip=document.getElementById("strip-cover"); if(_strip) _strip.addEventListener("click",()=>{
  if(!confirm("Remove oversized / covering pieces (keeps your dock layout)?")) return;
  if(sanitizeLayout()){ saveLayout(); redraw(); renderDockEditor(); alert("Cleared oversized covers."); }
  else alert("Nothing oversized found. Select the orange piece and Delete it.");
});

/* ---- view-only / layers-edit-only hard guards ---- */
if((typeof VIEW_ONLY!=="undefined" && VIEW_ONLY) || (typeof LAYERS_EDIT_ONLY!=="undefined" && LAYERS_EDIT_ONLY) || (typeof SHARE_FOLLOW_MAIN!=="undefined" && SHARE_FOLLOW_MAIN)){
  editing=false;
  document.body.classList.remove("editing");
  const et=document.getElementById("edit-toggle"); if(et){ et.hidden=true; et.onclick=()=>{ blockEdit(); }; }
  const etm=document.getElementById("edit-toggle-mobile"); if(etm){ etm.hidden=true; etm.onclick=()=>{ blockEdit(); }; }
  const ets=document.getElementById("edit-toggle-sticky"); if(ets){ ets.hidden=true; ets.onclick=()=>{ blockEdit(); }; }
  ["btn-photo-move","btn-dock-align","btn-gcp-align","photo-nudge-l","photo-nudge-r","photo-nudge-u","photo-nudge-d",
   "photo-reset-align","photo-fit-workspace","btn-reset-cruiser","btn-restore-original","reset-layout","import-layout",
   "add-dock","add-slip-free","add-walk","add-box","add-label","btn-dup","btn-multi","btn-select-all","btn-lock-as-dock","btn-unlock-slips","btn-multi-lock",
   "btn-group-all","btn-group","btn-ungroup","strip-cover","btn-save-layout","btn-reset-blank",
   "export-layout","download-layout"].forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.addEventListener("click", function(ev){ if(blockEdit()){ ev.stopImmediatePropagation(); ev.preventDefault(); } }, true);
    if(VIEW_ONLY || LAYERS_EDIT_ONLY || SHARE_FOLLOW_MAIN){ el.disabled=true; el.style.opacity=".45"; }
  });
  ["photo-scale-x","photo-scale-y","photo-scale-x-num","photo-scale-y-num","photo-rot"].forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.addEventListener("input", function(ev){ if(blockEdit()){ ev.stopImmediatePropagation(); ev.preventDefault(); } }, true);
    el.addEventListener("change", function(ev){ if(blockEdit()){ ev.stopImmediatePropagation(); ev.preventDefault(); } }, true);
    if(VIEW_ONLY || LAYERS_EDIT_ONLY || SHARE_FOLLOW_MAIN) el.disabled=true;
  });
  if(VIEW_ONLY){
    const boat=document.getElementById("boat"); if(boat) boat.readOnly=true;
    const notes=document.getElementById("notes"); if(notes) notes.readOnly=true;
    document.querySelectorAll("#pane-slip .st button").forEach(b=>{ b.disabled=true; b.style.opacity=".45"; });
    const al=document.getElementById("add-layer");
    if(al){ al.addEventListener("click", function(ev){ if(blockEdit()){ ev.stopImmediatePropagation(); ev.preventDefault(); } }, true); al.disabled=true; al.style.opacity=".45"; }
  }
  if(LAYERS_EDIT_ONLY){
    let ban=document.getElementById("layers-only-banner");
    if(!ban){
      ban=document.createElement("div");
      ban.id="layers-only-banner";
      ban.style.cssText="margin:8px 16px;padding:8px 12px;border-radius:10px;background:#1a4a5c;color:#eef6f8;font-size:13px";
      ban.textContent="Layers-only chart — assign slip colors; dock positions are locked.";
      const err=document.getElementById("error-banner");
      if(err && err.parentNode) err.parentNode.insertBefore(ban, err.nextSibling);
      else document.body.insertBefore(ban, document.body.firstChild);
    }
    // Hide layout pane tools tab content noise but keep Layers tab
    const layoutTab=document.querySelector('.tabs button[data-tab="layout"]');
    if(layoutTab) layoutTab.style.display="none";
  }
  if(SHARE_FOLLOW_MAIN){
    let ban=document.getElementById("share-follow-banner");
    if(!ban){
      ban=document.createElement("div");
      ban.id="share-follow-banner";
      ban.style.cssText="margin:8px 16px;padding:8px 12px;border-radius:10px;background:#1a3a5c;color:#eef6f8;font-size:13px";
      ban.textContent="Share chart — layout follows MAIN (locked). Slip occupancy stays editable here.";
      const err=document.getElementById("error-banner");
      if(err && err.parentNode) err.parentNode.insertBefore(ban, err.nextSibling);
      else document.body.insertBefore(ban, document.body.firstChild);
    }
    const layoutTab=document.querySelector('.tabs button[data-tab="layout"]');
    if(layoutTab) layoutTab.style.display="none";
  }
}

/* ---- published layout sync boot ---- */
(function(){
  ["btn-publish-layout","btn-publish-layout-dock"].forEach(function(id){
    const pubBtn=document.getElementById(id);
    if(!pubBtn) return;
    if(IS_LAYOUT_SOURCE){
      pubBtn.onclick=function(){ publishLayoutToCopies(); };
    }else{
      pubBtn.hidden=true;
    }
  });
  try{ wireGhPublishTokenUi(); }catch(e){}
  wirePublishedLayoutListeners();
  if(!IS_LAYOUT_SOURCE){
    pullPublishedLayout({quiet:true}).then(function(ok){
      if(ok){ try{ ensureMapVisible(); }catch(e){} }
    }).catch(function(){});
  }
})();

